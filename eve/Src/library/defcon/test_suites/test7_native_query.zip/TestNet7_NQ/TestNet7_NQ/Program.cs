using System;
using System.Collections.Generic;
using System.Text;
using EiffelSoftware.Library.Base.Kernel;
using RootCluster;
using Db4objects.Db4o;

namespace TestNet_NQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            store();
            Array arrPar1 = retrieveByEiffelNQ();
            Array arrPar2 = retrieveByNQ();
        }

        private void store()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                Parallelogram par = RootCluster.Create.Parallelogram.MakeWith_4Vertices(makeVertices(4));
                db.Set(par);
            }
            finally
            {
                db.Close();
            }
        }

        // Use the ParallelogramPredicate defined in test7_net_native_query.dll
        private Array retrieveByEiffelNQ()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                RootCluster.QueryPredicate.ParallelogramPredicate parPredicate = RootCluster.QueryPredicate.Create.ParallelogramPredicate.DefaultCreate();
                IObjectSet result = db.Query(parPredicate);
                Parallelogram[] arr = new Parallelogram[result.Count];
                result.CopyTo(arr, 0);
                return arr;
            }
            finally
            {
                db.Close();
            }
        }

        // Use the delegate
        private Array retrieveByNQ()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                IList<Parallelogram> result = db.Query<Parallelogram>(delegate(Parallelogram par)
                {
                    return par.Height1() > 0;
                });
                Parallelogram[] arr = new Parallelogram[result.Count];
                result.CopyTo(arr, 0);
                return arr;
            }
            finally
            {
                db.Close();
            }
        }

        private ArrayPoint makeVertices(int count)
        {
            ArrayPoint arr = EiffelSoftware.Library.Base.Kernel.Create.ArrayPoint.Make(0, count - 1, null);
            Point p;
            Random rand = new Random();
            for (int i = 0; i < count; i++)
            {
                p = RootCluster.Create.Point.MakeWithXY(rand.Next(1, 100), rand.Next(1, 100));
                ((ToSpecialPoint)arr).Put(p, i);
            }
            return arr;
        } 
    }
}
