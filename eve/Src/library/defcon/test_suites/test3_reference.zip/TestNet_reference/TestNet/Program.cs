using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using EiffelSoftware.Library.Base.Kernel;
using System.Reflection;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;

namespace TestNet
{
    class Program
    {
        private const int ROOT_ID = 123;
        private const int TREE_LEVEL = 8;
        private Random rand;

        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            rand = new Random();
            TreeNode root = makeTree(0);
            //printTree(root, 0);

            // get meta data using reflection mechanism            
            reflect(typeof(Any));
            reflect(typeof(RootCluster.TreeNode));
            reflect(typeof(RootCluster.Impl.TreeNode));
            reflect(typeof(RootCluster.Create.TreeNode));

            // store the tree
            storeTree(root);
            // retrieve the tree
            TreeNode res_root = retrieveTree();
            // compare the retrieved tree with the original one
            if (res_root != null)
            {
                printTree(res_root, 0);
                Console.WriteLine("The retrieved tree is " + (res_root.IsDeepEqual(root) ? "" : "not") + " equal to the original one.");
            }

            // update the tree
            root.Left().Left().Right().Left().Parent().SetId(200); 
            updateTree();
            // retrieve the updated the tree
            TreeNode res_updated_root = retrieveTree();
            // compare the retrieved tree with the updated one
            if (res_updated_root != null)
            {
                Console.WriteLine("The tree is " + (res_updated_root.IsDeepEqual(root) ? "" : "not") + " updated in the database.");
            }

            // delete the tree
            deleteTree();
        }

        private TreeNode makeTree(int level)
        {
            if (level > TREE_LEVEL)
            {
                return null;
            }
            TreeNode node;
            if (level == 0)
            {
                node = RootCluster.Create.TreeNode.MakeId(ROOT_ID);
            }
            else
            {
                node = RootCluster.Create.TreeNode.MakeId(rand.Next(1, 100));
            }
            node.SetLeft(makeTree(level + 1));
            node.SetRight(makeTree(level + 1));
            return node;
        }

        private void printTree(TreeNode node, int level)
        { 
            string indent = "";
            for (int i = level; i > 0; i--)
            {
                indent = indent + "    ";
            }
            Console.WriteLine(indent + node.Id());
            if (node.Left() != null)
            {
                printTree(node.Left(), level + 1);
            }
            if (node.Right() != null)
            {
                printTree(node.Right(), level + 1);
            }
        }

        private void storeTree(TreeNode root)
        {               
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(root);
            }
            finally
            {
                db.Close();
            }
        }

        private TreeNode retrieveTree()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).CascadeOnActivate(true);  // The whole tree is activated.
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).ObjectField("$$left").CascadeOnActivate(true);  // The tree is activated to the 5. level, which is default.
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).ObjectField("$$right").CascadeOnActivate(true);
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).MinimumActivationDepth(6);  // The whole tree is activated.
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).MaximumActivationDepth(3);  // The tree is activated to the 3. level.
            //config.ActivationDepth(2);  // The tree is activated to the 2. level.
            IObjectContainer db = Db4oFactory.OpenFile(config, "testnet.yap");
            try
            {
                TreeNode node = RootCluster.Create.TreeNode.MakeId(ROOT_ID);
                IObjectSet os = db.Get(node);
                if (os.HasNext())
                {
                    TreeNode root = os.Next() as TreeNode;
                    if (root != null)
                    {
                        //db.Deactivate(root.Left().Left().Left().Left(), 4); // root.Left().Left() is deactivated and root.Left() remains activated after the call.
                        return root;
                    }
                    else
                    {
                        return null;
                    }                       
                }
                else
                {
                    return null;
                }
            }
            finally
            {
                db.Close();
            }
        }

        private void updateTree()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).CascadeOnActivate(true);
            config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).MaximumActivationDepth(1);
            //config.UpdateDepth(3);
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).CascadeOnUpdate(true);
            config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).ObjectField("$$left").CascadeOnUpdate(true);
            config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).ObjectField("$$right").CascadeOnUpdate(true);
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).UpdateDepth(3);
            IObjectContainer db = Db4oFactory.OpenFile(config, "testnet.yap");
            try
            {
                TreeNode node = RootCluster.Create.TreeNode.MakeId(ROOT_ID);
                IObjectSet os = db.Get(node);
                if (os.HasNext())
                {
                    TreeNode root = os.Next() as TreeNode;
                    if (root != null)
                    {
                        // modify the tree node
                        // 1. approach
                        //root.Left().Left().Right().Left().Parent().SetId(200);                        

                        // 2. approach
                        db.Activate(root.Left(), 1);
                        db.Activate(root.Left().Left(), 1);
                        db.Activate(root.Left().Left().Right(), 1);
                        db.Activate(root.Left().Left().Right().Left(), 1);
                        root.Left().Left().Right().Left().Parent().SetId(200); 

                        // update the tree node in the database
                        db.Set(root);
                        //db.Ext().Set(root, 4);
                        //db.Set(root.Left().Left().Right().Left().Parent());
                    }
                } 
            }
            finally
            {
                db.Close();
            }
        }

        private void deleteTree()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            //config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).CascadeOnDelete(true);
            config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).ObjectField("$$left").CascadeOnDelete(true);
            config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).ObjectField("$$right").CascadeOnDelete(true);
            IObjectContainer db = Db4oFactory.OpenFile(config, "testnet.yap");
            try
            {
                TreeNode node = RootCluster.Create.TreeNode.MakeId(ROOT_ID);
                IObjectSet os = db.Get(node);
                if (os.HasNext())
                {
                    db.Delete(os.Next());
                }
            }
            finally
            {
                db.Close();
            }
        }

        private void reflect(object o)
        {
            Type tp;
            if (o is Type) {
                tp = o as Type;
            } else {
                tp = o.GetType();
            }
            Console.WriteLine("Type: " + tp);
            Console.WriteLine("Name: " + tp.Name);
            Console.WriteLine("Base type: " + tp.BaseType);
            Console.WriteLine("IsClass: " + tp.IsClass);
            Console.WriteLine("IsInterface: " + tp.IsInterface);
            Console.WriteLine("IsAbstract: " + tp.IsAbstract);
            Console.WriteLine("IsEnum: " + tp.IsEnum);
            Console.WriteLine("IsValueType: " + tp.IsValueType);
            Console.WriteLine("ReflectedType: " + tp.ReflectedType);
            Console.WriteLine("UnderlyingSystemType: " + tp.UnderlyingSystemType);
            Console.Write("Interfaces: ");
            Type[] interfaces = tp.GetInterfaces();
            foreach (Type t in interfaces)
            {
                Console.Write(t.Name + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Constructors: ");
            ConstructorInfo[] constructors = tp.GetConstructors();
            foreach (ConstructorInfo c in constructors)
            {
                Console.WriteLine("\t" + c + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Methods: ");
            MethodInfo[] methods = tp.GetMethods();
            foreach (MethodInfo m in methods) {
                Console.WriteLine("\t" + m + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Fields: ");
            FieldInfo[] fields = tp.GetFields();
            foreach (FieldInfo f in fields)
            {
                Console.Write("\t" + f + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Properties: ");
            PropertyInfo[] properties = tp.GetProperties();
            foreach (PropertyInfo p in properties)
            {
                Console.Write("\t" + p + ", ");
            }
            Console.WriteLine();
        } 
    }
}







 



