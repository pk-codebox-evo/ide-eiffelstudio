using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using EiffelSoftware.Library.Base.Kernel;
using System.Reflection;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using System.IO;

namespace TestNet
{
    class Program
    {
        TextWriter tw;

        static void Main(string[] args)
        {
            Program p = new Program();
            p.reflectMetadata();
            p.test();         
        }

        private void reflectMetadata()
        {
            tw = new StreamWriter("metadata.txt");

            reflect(typeof(EiffelSoftware.Runtime.EIFFEL_TYPE_INFO));
            reflect(typeof(Any));

            reflect(typeof(RootCluster.Figure));
            reflect(typeof(RootCluster.Impl.Figure));

            reflect(typeof(RootCluster.Polygon));
            reflect(typeof(RootCluster.ReferencePolygon));
            reflect(typeof(RootCluster.Impl.ReferencePolygon));
            reflect(typeof(RootCluster.Create.Polygon));
            reflect(typeof(RootCluster.Create.ReferencePolygon));

            reflect(typeof(RootCluster.Symmetry));
            reflect(typeof(RootCluster.Impl.Symmetry));

            reflect(typeof(RootCluster.Parallelogram));
            reflect(typeof(RootCluster.ReferenceParallelogram));
            reflect(typeof(RootCluster.Impl.ReferenceParallelogram));
            reflect(typeof(RootCluster.Create.Parallelogram));
            reflect(typeof(RootCluster.Create.ReferenceParallelogram));

            reflect(typeof(RootCluster.Rectangle));
            reflect(typeof(RootCluster.ReferenceRectangle));
            reflect(typeof(RootCluster.Impl.ReferenceRectangle));
            reflect(typeof(RootCluster.Create.Rectangle));
            reflect(typeof(RootCluster.Create.ReferenceRectangle));

            reflect(typeof(RootCluster.Rhombus));
            reflect(typeof(RootCluster.ReferenceRhombus));
            reflect(typeof(RootCluster.Impl.ReferenceRhombus));
            reflect(typeof(RootCluster.Create.Rhombus));
            reflect(typeof(RootCluster.Create.ReferenceRhombus));

            reflect(typeof(RootCluster.Square));
            reflect(typeof(RootCluster.ReferenceSquare));
            reflect(typeof(RootCluster.Impl.ReferenceSquare));
            reflect(typeof(RootCluster.Create.Square));
            reflect(typeof(RootCluster.Create.ReferenceSquare));        
                       
            tw.Close();
        }

        private void test()
        {
            Square sq = RootCluster.Create.Square.MakeWith_4Vertices(makeVertices(4));
            store(sq);
            Square defaultSq = RootCluster.Create.Square.DefaultCreate();
            Array arrSq = retrieve(defaultSq);  // 1. returns all the direct instances of RootCluster.Square

            Rectangle rec = RootCluster.Create.Rectangle.MakeWith_4Vertices(makeVertices(4));
            store(rec);
            Rectangle defaultRec = RootCluster.Create.Rectangle.DefaultCreate();
            Array arrRec = retrieve(defaultRec); // 2. returns all the direct instances of RootCluster.Rectangle

            Rhombus rh = RootCluster.Create.Rhombus.MakeWith_4Vertices(makeVertices(4));
            store(rh);
            Rhombus defaultRh = RootCluster.Create.Rhombus.DefaultCreate();
            Array arrRh = retrieve(defaultRh);  // 3. returns all the direct instances of RootCluster.Rhombus

            Parallelogram par = RootCluster.Create.Parallelogram.MakeWith_4Vertices(makeVertices(4));
            store(par);
            Parallelogram defaultPar = RootCluster.Create.Parallelogram.DefaultCreate();
            Array arrPar = retrieve(defaultPar); // 4. returns all the direct instances of RootCluster.Parallelogram

            Polygon pol = RootCluster.Create.Polygon.MakeWithVertices(makeVertices(7));
            store(pol);
            Polygon defaultPol = RootCluster.Create.Polygon.DefaultCreate();
            Array arrPol = retrieve(defaultPol); // 5. returns all the direct instances of RootCluster.Polygon
            
            Array arrRootSq = retrieve(typeof(RootCluster.Square)); // = 1
            Array arrRootRec = retrieve(typeof(RootCluster.Rectangle)); // = 2
            Array arrRootRh = retrieve(typeof(RootCluster.Rhombus));  // = 3
            Array arrRootPar = retrieve(typeof(RootCluster.Parallelogram));  // = 4
            Array arrRootPol = retrieve(typeof(RootCluster.Polygon)); // = 5
            Array arrRootFig = retrieve(typeof(RootCluster.Figure));  // = 1+2+3+4+5.
            Array arrRootSym = retrieve(typeof(RootCluster.Symmetry)); // = 1+2+3+4. 
        }

        private void store(object obj)
        {               
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(obj);
            }
            finally
            {
                db.Close();
            }
        }

        private Array retrieve(object defaultObj)
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {                
                IObjectSet os = db.Get(defaultObj);
                Array arr = Array.CreateInstance(defaultObj.GetType(), os.Count);
                os.CopyTo(arr, 0);
                return arr;
            }
            finally
            {
                db.Close();
            }
        }

        private Array retrieve(Type tp)
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                IObjectSet os = db.Get(tp);
                Array arr = Array.CreateInstance(tp, os.Count);
                os.CopyTo(arr, 0);
                return arr;
            }
            finally
            {
                db.Close();
            }
        }

        private ArrayPoint makeVertices(int count)
        {
            ArrayPoint arr = EiffelSoftware.Library.Base.Kernel.Create.ArrayPoint.Make(0, count - 1, null);
            Point p;
            Random rand = new Random();
            for (int i = 0; i < count; i++)
            {
                p = RootCluster.Create.Point.MakeWithXY(rand.Next(1, 100), rand.Next(1, 100));
                ((ToSpecialPoint)arr).Put(p, i);
            }
            return arr;
        }
        
        private void reflect(object o)
        {
            Type tp;
            if (o is Type) {
                tp = o as Type;
            } else {
                tp = o.GetType();
            }
 
            tw.WriteLine("Type: " + tp);
            tw.WriteLine("Name: " + tp.Name);
            tw.WriteLine("Base type: " + tp.BaseType);
            tw.WriteLine("IsClass: " + tp.IsClass);
            tw.WriteLine("IsInterface: " + tp.IsInterface);
            tw.WriteLine("IsAbstract: " + tp.IsAbstract);
            tw.WriteLine("IsEnum: " + tp.IsEnum);
            tw.WriteLine("IsValueType: " + tp.IsValueType);
            tw.WriteLine("ReflectedType: " + tp.ReflectedType);
            tw.WriteLine("UnderlyingSystemType: " + tp.UnderlyingSystemType);
            tw.Write("Interfaces: ");
            Type[] interfaces = tp.GetInterfaces();
            foreach (Type t in interfaces)
            {
                tw.Write(t.Name + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Constructors: ");
            ConstructorInfo[] constructors = tp.GetConstructors(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (ConstructorInfo c in constructors)
            {
                tw.WriteLine("\t" + c.Attributes + " " + c + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Methods: ");
            MethodInfo[] methods = tp.GetMethods(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (MethodInfo m in methods) {
                tw.WriteLine("\t" + m.Attributes + " " + m + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Fields: ");
            FieldInfo[] fields = tp.GetFields(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (FieldInfo f in fields)
            {
                tw.Write("\t" + f.Attributes + " " + f + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Properties: ");
            PropertyInfo[] properties = tp.GetProperties(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (PropertyInfo p in properties)
            {
                tw.Write("\t" + p.Attributes + " " + p + ", ");
            }
            tw.WriteLine();
        } 
    }
}







 



