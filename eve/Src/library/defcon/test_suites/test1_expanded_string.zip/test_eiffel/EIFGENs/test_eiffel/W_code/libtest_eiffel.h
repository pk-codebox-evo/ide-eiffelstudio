#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

RT_IL EIF_INTEGER_32 __stdcall Faunysz(void);
RT_IL EIF_BOOLEAN __stdcall Faucywe(void);
RT_IL EIF_BOOLEAN __stdcall Faucays(void);
RT_IL EIF_BOOLEAN __stdcall Faudlt0(void);
RT_IL EIF_BOOLEAN __stdcall Faud8rn(void);
RT_IL EIF_BOOLEAN __stdcall Fauewo9(void);
RT_IL EIF_INTEGER_32 __stdcall Fauqjjg(void);
RT_IL EIF_INTEGER_32 __stdcall Fauf6ki(void);
RT_IL EIF_INTEGER_32 __stdcall Fauguh4(void);
RT_IL EIF_INTEGER_32 __stdcall Fauhhfr(void);
RT_IL EIF_INTEGER_32 __stdcall Faukp3v(void);
RT_IL EIF_BOOLEAN __stdcall Faium6x(EIF_POINTER, EIF_POINTER);
RT_IL EIF_INTEGER_32 __stdcall Fcnu0wc(EIF_POINTER, EIF_POINTER, EIF_INTEGER_32);
RT_IL void __stdcall Fcnxmmu(EIF_POINTER);
RT_IL void __stdcall Fcnudyq(EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
RT_IL EIF_POINTER __stdcall Fcnvotz(EIF_INTEGER_32);
RT_IL EIF_POINTER __stdcall Fcnsf4v(EIF_POINTER, EIF_INTEGER_32);
RT_IL EIF_POINTER __stdcall Fcnwbrl(EIF_INTEGER_32, EIF_INTEGER_32);
RT_IL EIF_POINTER __stdcall Fcnwzo7(EIF_POINTER, EIF_INTEGER_32);
RT_IL void __stdcall Fcns22h(EIF_POINTER, EIF_POINTER, EIF_INTEGER_32);
RT_IL void __stdcall Fcntq_3(EIF_POINTER, EIF_POINTER, EIF_INTEGER_32);
RT_IL EIF_INTEGER_32 __stdcall Fawkgs3(EIF_POINTER);
RT_IL EIF_INTEGER_32 __stdcall Fb1hm0l(EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#include "io.h"
#include <string.h>
#include "eif_eiffel.h"
#include <stdlib.h>
#include "eif_macros.h"
#include "eif_built_in.h"
