#include "eif_eiffel.h"
#include "libtest_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_FAIUM6X

static int inline_Faium6x (EIF_POINTER arg1, EIF_POINTER arg2)
{
EIF_BOOLEAN Result = EIF_FALSE;
#ifdef EIF_WINDOWS
		/* To check this, we use `CreateFileA' to open both file, and then using the information
		 * returned by `GetFileInformationByHandle' we can check whether or not they are indeed
		 * the same.
		 * Note: it is important to use the A version of CreateFileA because arguments
		 * are ASCII strings, not unicode. */
	BY_HANDLE_FILE_INFORMATION l_path1_info, l_path2_info;
	HANDLE l_path2_file = CreateFileA ((LPCSTR) arg2, GENERIC_READ, FILE_SHARE_READ, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	HANDLE l_path1_file = CreateFileA ((LPCSTR) arg1, GENERIC_READ, FILE_SHARE_READ, NULL,
			OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if ((l_path2_file == INVALID_HANDLE_VALUE) || (l_path1_file == INVALID_HANDLE_VALUE)) {
			/* We do not need the handles anymore, simply close them. Since Microsoft
			 * API accepts INVALID_HANDLE_VALUE we don't check the validity of arguments. */
		CloseHandle(l_path2_file);
		CloseHandle(l_path1_file);
	} else {
		BOOL success = GetFileInformationByHandle (l_path2_file, &l_path2_info);
		success = success && GetFileInformationByHandle (l_path1_file, &l_path1_info);
			/* We do not need the handles anymore, simply close them. */
		CloseHandle(l_path2_file);
		CloseHandle(l_path1_file);
		if (success) {
				/* Check that `path2' and `path1' do not represent the same file. */
			if
				((l_path2_info.dwVolumeSerialNumber == l_path1_info.dwVolumeSerialNumber) &&
				(l_path2_info.nFileIndexLow == l_path1_info.nFileIndexLow) &&
				(l_path2_info.nFileIndexHigh == l_path1_info.nFileIndexHigh))
			{
				Result = EIF_TRUE;
			}
		}
	}
#else
	struct stat buf1, buf2;
	int status;
	#ifdef HAS_LSTAT
	status = lstat(arg1, &buf1);
	if (status == 0) {
			/* We found a file, now let's check if it is not a symbolic link. If it is, we use `stat'
		 	 * to ensure the validity of the link. */
		if ((buf1.st_mode & S_IFLNK) == S_IFLNK) {
			status = stat (arg1, &buf1);
		}
	}
	
	if (status == 0) {
		status = lstat(arg2, &buf2);
		if (status == 0) {
				/* We found a file, now let's check if it is not a symbolic link. If it is, we use `stat'
			 	 * to ensure the validity of the link. */
			if ((buf2.st_mode & S_IFLNK) == S_IFLNK) {
				status = stat (arg2, &buf2);
			}
		}
	}
	#else
	status = stat (arg1, &buf1);
	if (status == 0) {
		status = stat (arg2, &buf2);
	}
	#endif
	if (status == 0) {
			/* Both files are present, check they represent the same one. */
		if ((buf1.st_dev == buf2.st_dev) && (buf1.st_ino == buf2.st_ino)) {
			Result = EIF_TRUE;
		}
	}
#endif
	return Result;
;
}
#define INLINE_FAIUM6X
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* PLATFORM *//* real_bytes */

RT_IL EIF_INTEGER_32 __stdcall Faunysz (void)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)eif_builtin_PLATFORM_real_bytes;
	return Result;
}
/* PLATFORM *//* is_dotnet */

RT_IL EIF_BOOLEAN __stdcall Faucywe (void)
{
	EIF_BOOLEAN Result;
	Result = (EIF_BOOLEAN)eif_builtin_PLATFORM_is_dotnet;
	return Result;
}
/* PLATFORM *//* is_thread_capable */

RT_IL EIF_BOOLEAN __stdcall Faucays (void)
{
	EIF_BOOLEAN Result;
	Result = (EIF_BOOLEAN)eif_builtin_PLATFORM_is_thread_capable;
	return Result;
}
/* PLATFORM *//* is_windows */

RT_IL EIF_BOOLEAN __stdcall Faudlt0 (void)
{
	EIF_BOOLEAN Result;
	Result = (EIF_BOOLEAN)eif_builtin_PLATFORM_is_windows;
	return Result;
}
/* PLATFORM *//* is_unix */

RT_IL EIF_BOOLEAN __stdcall Faud8rn (void)
{
	EIF_BOOLEAN Result;
	Result = (EIF_BOOLEAN)eif_builtin_PLATFORM_is_unix;
	return Result;
}
/* PLATFORM *//* is_vms */

RT_IL EIF_BOOLEAN __stdcall Fauewo9 (void)
{
	EIF_BOOLEAN Result;
	Result = (EIF_BOOLEAN)eif_builtin_PLATFORM_is_vms;
	return Result;
}
/* PLATFORM *//* pointer_bytes */

RT_IL EIF_INTEGER_32 __stdcall Fauqjjg (void)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)eif_builtin_PLATFORM_pointer_bytes;
	return Result;
}
/* PLATFORM *//* boolean_bytes */

RT_IL EIF_INTEGER_32 __stdcall Fauf6ki (void)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)eif_builtin_PLATFORM_boolean_bytes;
	return Result;
}
/* PLATFORM *//* character_bytes */

RT_IL EIF_INTEGER_32 __stdcall Fauguh4 (void)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)eif_builtin_PLATFORM_character_bytes;
	return Result;
}
/* PLATFORM *//* wide_character_bytes */

RT_IL EIF_INTEGER_32 __stdcall Fauhhfr (void)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)eif_builtin_PLATFORM_wide_character_bytes;
	return Result;
}
/* PLATFORM *//* integer_bytes */

RT_IL EIF_INTEGER_32 __stdcall Faukp3v (void)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)eif_builtin_PLATFORM_integer_bytes;
	return Result;
}

/* FILE_COMPARER *//* c_same_files */

RT_IL EIF_BOOLEAN __stdcall Faium6x (EIF_POINTER arg1, EIF_POINTER arg2)
{
	EIF_BOOLEAN Result;
	Result = EIF_TEST(inline_Faium6x ((EIF_POINTER) arg1, (EIF_POINTER) arg2));
	return Result;
}

/* POINTER_REF *//* c_memcmp */

RT_IL EIF_INTEGER_32 __stdcall Fcnu0wc (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)memcmp((void *) arg1, (void *) arg2, (size_t) arg3);
	return Result;
}
/* POINTER_REF *//* c_free */

RT_IL void __stdcall Fcnxmmu (EIF_POINTER arg1)
{
	free((void *) arg1);
}
/* POINTER_REF *//* c_memset */

RT_IL void __stdcall Fcnudyq (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	memset((void *) arg1, (int) arg2, (size_t) arg3);
}
/* POINTER_REF *//* c_malloc */

RT_IL EIF_POINTER __stdcall Fcnvotz (EIF_INTEGER_32 arg1)
{
	EIF_POINTER Result;
	Result = (EIF_POINTER)malloc((size_t) arg1);
	return Result;
}
/* POINTER_REF *//* c_offset_pointer */

RT_IL EIF_POINTER __stdcall Fcnsf4v (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	EIF_POINTER Result;
	Result = (EIF_POINTER)RTPOF((arg1), (arg2));
	return Result;
}
/* POINTER_REF *//* c_calloc */

RT_IL EIF_POINTER __stdcall Fcnwbrl (EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	EIF_POINTER Result;
	Result = (EIF_POINTER)calloc((size_t) arg1, (size_t) arg2);
	return Result;
}
/* POINTER_REF *//* c_realloc */

RT_IL EIF_POINTER __stdcall Fcnwzo7 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	EIF_POINTER Result;
	Result = (EIF_POINTER)realloc((void *) arg1, (size_t) arg2);
	return Result;
}
/* POINTER_REF *//* c_memcpy */

RT_IL void __stdcall Fcns22h (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	memcpy((void *) arg1, (const void *) arg2, (size_t) arg3);
}
/* POINTER_REF *//* c_memmove */

RT_IL void __stdcall Fcntq_3 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	memmove((void *) arg1, (const void *) arg2, (size_t) arg3);
}

/* C_STRING *//* c_strlen */

RT_IL EIF_INTEGER_32 __stdcall Fawkgs3 (EIF_POINTER arg1)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)strlen((char*) arg1);
	return Result;
}

/* FILE *//* get_fd */

RT_IL EIF_INTEGER_32 __stdcall Fb1hm0l (EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	EIF_INTEGER_32 Result;
	Result = (EIF_INTEGER_32)_open_osfhandle((EIF_INTEGER) arg1, (EIF_INTEGER) arg2);
	return Result;
}


#ifdef __cplusplus
}
#endif

