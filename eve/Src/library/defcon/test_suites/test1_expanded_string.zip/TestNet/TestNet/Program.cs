using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using RootCluster.Create;
using RootCluster.Impl;
using EiffelSoftware.Library.Base.Kernel;
using System.Reflection;
using Db4objects.Db4o;

namespace TestNet
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.testValue();
            p.testString();
        }

        private void testValue()
        {
            RootCluster.ValueTestClass v1 = storeValues();
            RootCluster.ValueTestClass v2 = getValues();
            if (v1 != null && v2 != null)
            {
                Console.WriteLine(v1.Equals(v2));
            }
        }

        private RootCluster.ValueTestClass storeValues()
        {
            // Store an instance of ValueTestClass
            RootCluster.ValueTestClass vtc = RootCluster.Create.ValueTestClass.Make();
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(vtc);
            }
            finally
            {
                db.Close();
            }

            // Reflect fields of vtc
            reflectFields(vtc);
            return vtc;
        }

        private RootCluster.ValueTestClass getValues()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                RootCluster.ValueTestClass vtc = RootCluster.Create.ValueTestClass.DefaultCreate();
                IObjectSet os = db.Get(vtc);
                
                // Reflect fields of retrieved instances of ValueTestClass
                RootCluster.ValueTestClass v;
                foreach (object o in os)
                {
                    reflectFields(o);
                    v = o as RootCluster.ValueTestClass;
                    return v;
                }
                return null;
            }
            finally
            {
                db.Close();
            }

        }

        private void reflectFields(object o)
        {
            Type tp = o.GetType();
            FieldInfo[] fields = tp.GetFields();
            foreach (FieldInfo f in fields)
            {
                Console.WriteLine(f.Name + "=" + f.GetValue(o) + " (FieldType: " + f.FieldType + ")");
            }
            Console.WriteLine();
        }

        private void testString()
        {
            RootCluster.StringTestClass s1 = storeStrings();
            RootCluster.StringTestClass s2 = getStrings();
        }

        private RootCluster.StringTestClass storeStrings()
        {
            // Store an instance of StringTestClass
            RootCluster.StringTestClass stc = RootCluster.Create.StringTestClass.Make();
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(stc);
            }
            finally
            {
                db.Close();
            }

            // Reflect fields of stc
            reflectFields(stc);
            return stc;
        }

        private RootCluster.StringTestClass getStrings()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                RootCluster.StringTestClass stc = RootCluster.Create.StringTestClass.DefaultCreate();
                IObjectSet os = db.Get(stc);

                // Reflect fields of retrieved instances of StringTestClass
                RootCluster.StringTestClass s;
                foreach (object o in os)
                {
                    reflectFields(o);
                    s = o as RootCluster.StringTestClass;
                    return s;
                }
                return null;
            }
            finally
            {
                db.Close();
            }
        }
    }
}

