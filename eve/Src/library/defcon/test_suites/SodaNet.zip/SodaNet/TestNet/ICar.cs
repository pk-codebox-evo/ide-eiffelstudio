using System;
using System.Collections.Generic;
using System.Text;

namespace TestNet
{
    interface ICar
    {
        void PrintOut();
    }
}
