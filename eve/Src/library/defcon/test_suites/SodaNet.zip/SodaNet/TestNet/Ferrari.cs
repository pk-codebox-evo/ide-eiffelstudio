using System;
using System.Collections.Generic;
using System.Text;

namespace TestNet
{
    class Ferrari : ICar
    {
        private string name;

        public Ferrari(string n)
        {
            name = n;
        }

        public void PrintOut()
        {
            Console.WriteLine("Ferrari: " + name);
        }

    }
}
