using System;
using System.Collections.Generic;
using System.Text;
using Db4objects.Db4o;
using System.IO;
using Db4objects.Db4o.Query;

namespace TestNet
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            File.Delete("testnet.yap");
            storeCars();
            retrieveCars();            
        }

        private void storeCars()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                Ferrari f1 = new Ferrari("F450");
                db.Set(f1);
                Ferrari f2 = new Ferrari("F430");
                db.Set(f2);
                Bmw b1 = new Bmw("Serie 5");
                db.Set(b1);
                Bmw b2 = new Bmw("Serie 7");
                db.Set(b2);
            }
            finally
            {
                db.Close();
            }
        }

        private void retrieveCars()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                IQuery query = db.Query();
                query.Constrain(typeof(ICar));
                query.Descend("name").Constrain("F450");
                print(query.Execute());
            }
            finally
            {
                db.Close();
            }
        } 

        private void print(IObjectSet os)
        {
            ICar c;
            foreach (object o in os)
            {
                c = o as ICar;
                if (c != null)
                {
                    c.PrintOut();
                }
            }
        }
    }
}







 



