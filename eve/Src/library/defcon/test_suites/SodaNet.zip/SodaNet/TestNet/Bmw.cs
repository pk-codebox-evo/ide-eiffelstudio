using System;
using System.Collections.Generic;
using System.Text;

namespace TestNet
{
    class Bmw : ICar
    {
        private string name;

        public Bmw(string n)
        {
            name = n;
        }

        public void PrintOut()
        {
            Console.WriteLine("Bmw: " + name);
        }
    }
}
