using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Rectangle : IParallelogram
    {
        private int height1;
        private int height2;

        public Rectangle(int h1, int h2)
        {
            height1 = h1;
            height2 = h2;
        }

        public void PrintOut()
        {
            Console.WriteLine("Rectangle (" + height1 + ", " + height2 + ")");
        }
    }
}
