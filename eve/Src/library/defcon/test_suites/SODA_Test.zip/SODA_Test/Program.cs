using System;
using System.Collections.Generic;
using System.Text;
using Db4objects.Db4o;
using Db4objects.Db4o.Query;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Start();
        }

        private void Start()
        {
            Store();
            Retrieve();
            Console.ReadLine();
        }

        private void Store()
        {
            IObjectContainer oc = Db4oFactory.OpenFile("test.yap");
            try
            {
                oc.Store(new Parallelogram(10, 10));
                oc.Store(new Parallelogram(20, 20));
                oc.Store(new Rectangle(10, 10));
                oc.Store(new Rectangle(30, 30));
            }
            finally
            {
                oc.Close();
            }
        }

        private void Retrieve()
        {
            IObjectContainer oc = Db4oFactory.OpenFile("test.yap");
            try
            {
                Console.WriteLine("------- All IParallelogram instances ---------");
                IObjectSet os1 = oc.QueryByExample(typeof(IParallelogram));
                Output(os1);

                Console.WriteLine("------- height1 = 10 -------");
                IQuery q1 = oc.Query();
                q1.Constrain(typeof(IParallelogram));
                q1.Descend("height1").Constrain(10);
                IObjectSet os2 = q1.Execute();
                Output(os2);

                Console.WriteLine("------- height1 = 10 and height2 = 10 -------");
                IQuery q2 = oc.Query();
                q2.Constrain(typeof(IParallelogram));
                IConstraint icon1 = q2.Descend("height1").Constrain(10);
                IConstraint icon2 = q2.Descend("height2").Constrain(10);
                IConstraint icon = icon1.And(icon2);
                IObjectSet os3 = q2.Execute();
                Output(os3);

                Console.WriteLine("------- height1 = 10 or height2 = 10 -------");
                IQuery q3 = oc.Query();
                q3.Constrain(typeof(IParallelogram));
                IConstraint icon3 = q3.Descend("height1").Constrain(10);
                IConstraint icon4 = q3.Descend("height2").Constrain(10);
                IConstraint icon5 = icon3.Or(icon4);
                IObjectSet os4 = q3.Execute();
                Output(os4);

                Console.WriteLine("------- height1 != 10 --------");
                IQuery q4 = oc.Query();
                q4.Constrain(typeof(IParallelogram));
                IConstraint icon6 = q4.Descend("height1").Constrain(10).Not();
                IObjectSet os5 = q4.Execute();
                Output(os5);
            }
            finally
            {
                oc.Close();
            }
        }

        private void Output(IObjectSet os)
        {
            Console.WriteLine(os.Count + " instances found");
            IParallelogram p;
            while (os.HasNext())
            {
                p = (IParallelogram)os.Next();
                p.PrintOut();
            }
        }
    }
}
