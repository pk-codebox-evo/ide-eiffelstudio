using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Parallelogram : IParallelogram
    {
        private int height1;
        private int height2;

        public Parallelogram(int h1, int h2)
        {
            height1 = h1;
            height2 = h2;
        }

        public void PrintOut()
        {
            Console.WriteLine("Parallelogram (" + height1 + ", " + height2 + ")");
        }
    }
}
