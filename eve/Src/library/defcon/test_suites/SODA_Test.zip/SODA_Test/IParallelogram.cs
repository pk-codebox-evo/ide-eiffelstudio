using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    interface IParallelogram
    {
        void PrintOut();
    }
}
