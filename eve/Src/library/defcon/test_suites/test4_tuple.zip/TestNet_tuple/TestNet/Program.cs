using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using EiffelSoftware.Library.Base.Kernel;
using System.Reflection;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;

namespace TestNet
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            // get meta data using reflection mechanism            
            reflect(typeof(Any));
            reflect(typeof(RootCluster.Point)); // struct
            reflect(typeof(RootCluster.ReferencePoint)); // interface
            reflect(typeof(RootCluster.Impl.ReferencePoint)); // class
            reflect(typeof(RootCluster.Create.Point));
            reflect(typeof(RootCluster.Create.ReferencePoint));

            reflect(typeof(RootCluster.Rectangle));  // interface
            reflect(typeof(RootCluster.ValueRectangle));  // struct
            reflect(typeof(RootCluster.Impl.Rectangle)); // class
            reflect(typeof(RootCluster.Create.Rectangle));
            reflect(typeof(RootCluster.Create.ValueRectangle));

            reflect(typeof(RootCluster.TreeNode));  // interface
            reflect(typeof(RootCluster.Impl.TreeNode));  // class
            reflect(typeof(RootCluster.Create.TreeNode));

            reflect(typeof(RootCluster.TupleTestClass)); // interface
            reflect(typeof(RootCluster.Impl.TupleTestClass)); // class
            reflect(typeof(RootCluster.Create.TupleTestClass));

            
            TupleTestClass t = RootCluster.Create.TupleTestClass.Make();
            storeTuple(t);            
            TupleTestClass rest = retrieveTuple();            
            if (rest != null)
            {                
                Console.WriteLine("The retrieved tuples are " + (rest.IsEqualTo(t) ? "" : "not") + " equal to the original ones.");
            }

            deleteTuple();
        } 

        private void storeTuple(TupleTestClass t)
        {               
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(t);
            }
            finally
            {
                db.Close();
            }
        }

        private TupleTestClass retrieveTuple()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            config.ObjectClass(typeof(RootCluster.Impl.TreeNode)).CascadeOnActivate(true);
            IObjectContainer db = Db4oFactory.OpenFile(config, "testnet.yap");
            try
            {
                TupleTestClass t = RootCluster.Create.TupleTestClass.DefaultCreate();
                IObjectSet os = db.Get(t);
                if (os.HasNext())
                {
                    TupleTestClass rest = os.Next() as TupleTestClass;
                    if (rest != null)
                    {
                        return rest;
                    }
                    else
                    {
                        return null;
                    }                       
                }
                else
                {
                    return null;
                }
            }
            finally
            {
                db.Close();
            }
        }

        private void deleteTuple()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                object o = new object();
                IObjectSet os = db.Get(o);
                foreach (object obj in os)
                {
                    db.Delete(obj);
                }
            }
            finally
            {
                db.Close();
            }
        }

        private void reflect(object o)
        {
            Type tp;
            if (o is Type) {
                tp = o as Type;
            } else {
                tp = o.GetType();
            }
            Console.WriteLine("Type: " + tp);
            Console.WriteLine("Name: " + tp.Name);
            Console.WriteLine("Base type: " + tp.BaseType);
            Console.WriteLine("IsClass: " + tp.IsClass);
            Console.WriteLine("IsInterface: " + tp.IsInterface);
            Console.WriteLine("IsAbstract: " + tp.IsAbstract);
            Console.WriteLine("IsEnum: " + tp.IsEnum);
            Console.WriteLine("IsValueType: " + tp.IsValueType);
            Console.WriteLine("ReflectedType: " + tp.ReflectedType);
            Console.WriteLine("UnderlyingSystemType: " + tp.UnderlyingSystemType);
            Console.Write("Interfaces: ");
            Type[] interfaces = tp.GetInterfaces();
            foreach (Type t in interfaces)
            {
                Console.Write(t.Name + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Constructors: ");
            ConstructorInfo[] constructors = tp.GetConstructors();
            foreach (ConstructorInfo c in constructors)
            {
                Console.WriteLine("\t" + c + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Methods: ");
            MethodInfo[] methods = tp.GetMethods();
            foreach (MethodInfo m in methods) {
                Console.WriteLine("\t" + m + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Fields: ");
            FieldInfo[] fields = tp.GetFields();
            foreach (FieldInfo f in fields)
            {
                Console.Write("\t" + f + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Properties: ");
            PropertyInfo[] properties = tp.GetProperties();
            foreach (PropertyInfo p in properties)
            {
                Console.Write("\t" + p + ", ");
            }
            Console.WriteLine();
        } 
    }
}







 



