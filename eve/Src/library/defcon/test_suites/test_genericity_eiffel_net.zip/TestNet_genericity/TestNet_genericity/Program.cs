using System;
using System.Collections.Generic;
using System.Text;
using Db4objects.Db4o;
using RootCluster;
using System.IO;

namespace TestNet_genericity
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            File.Delete("testgenericity.yap");
            store();
            retrieve();
        }

        private void store()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testgenericity.yap");
            try
            {
                RootCluster.Test t = RootCluster.Create.Test.Make();
                GlistReference glist = t.MakePointList();
                db.Set(glist);
            }
            finally
            {
                db.Close();
            }
        }

        private void retrieve()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testgenericity.yap");
            try
            {
                RootCluster.Test t = RootCluster.Create.Test.Make();
                GlistReference glist = t.InitializePointList();
                IObjectSet result = db.Get(glist);
                GlistReference resultg;
                while (result.HasNext())
                {
                    resultg = result.Next() as GlistReference;
                    if (resultg != null)
                    {
                        while (resultg != null && resultg.Item() != null)
                        {
                            ((Point)resultg.Item()).Output();
                            Console.Write(", ");
                            resultg = resultg.Next();
                        }
                        Console.WriteLine();
                    }
                }
            }
            finally
            {
                db.Close();
            }
        }
    }
}
