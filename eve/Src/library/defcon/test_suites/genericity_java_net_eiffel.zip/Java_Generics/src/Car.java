
public class Car {
	public String Name;
	
	public Car(String n) {
		Name = n;
	}
	
	public String toString() {
		return "Car: " + Name;
	}
}
