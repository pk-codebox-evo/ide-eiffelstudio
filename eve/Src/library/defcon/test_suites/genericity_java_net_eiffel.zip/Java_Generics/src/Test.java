import com.db4o.*;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import java.io.*;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Test t = new Test();
		t.test();
	}
	
	private void test() {
		(new File("test_generics_java.yap")).delete();
		store();
		retrieve();
		testConformance();
	}
	
	private void store() {
		ObjectContainer db = Db4o.openFile("test_generics_java.yap");
		try {	
			// GList<int> not allowed
			
			GList<Integer> gl1 = new GList<Integer>();
			gl1.put(4);
			db.set(gl1);
			
			GList<Car> gl3 = new GList<Car>();
			gl3.put(new Car("car1"));
			db.set(gl3);
			
			GList<Ferrari> gl4 = new GList<Ferrari>();
			gl4.put(new Ferrari("F450"));
			db.set(gl4);
			
			GSublist<Integer> gslint = new GSublist<Integer>();
			gslint.put(7);
			db.set(gslint);
			
			GSublist<Car> gslcar = new GSublist<Car>();
			gslcar.put(new Car("subcar4"));
			db.set(gslcar);
			
			GSublist<Ferrari> gslf = new GSublist<Ferrari>();
			gslf.put(new Ferrari("SubF340"));
			db.set(gslf);
		} finally {
			db.close();
		}
	}
	
	private void retrieve() {
		ObjectContainer db = Db4o.openFile("test_generics_java.yap");
		try {
			GList<Integer> gl1 = new GList<Integer>();
			ObjectSet<GList<Integer>> os1 = db.get(gl1);
			for (GList<Integer> g : os1) {
				System.out.println("GList<Integer>: " + g.toString());				
			} 
			
			GList<Car> gl3 = new GList<Car>();
			ObjectSet<GList<Car>> os3 = db.get(gl3);
			for (GList<Car> g : os3) {
				System.out.println("GList<Car>: " + g.toString());
			} 
			
			GList<Ferrari> gl4 = new GList<Ferrari>();
			ObjectSet<GList<Ferrari>> os4 = db.get(gl4);
			for (GList<Ferrari> g : os4) {
				System.out.println("GList<Ferrari>: " + g.toString());
			} 
			
			GSublist<Integer> gslint = new GSublist<Integer>();
			ObjectSet<GSublist<Integer>> osgslint = db.get(gslint);
			for (GSublist<Integer> g : osgslint) {
				System.out.println("GSublist<Integer>: " + g.toString());
			}
			
			GSublist<Car> gslcar = new GSublist<Car>();
			ObjectSet<GSublist<Car>> osgslcar = db.get(gslcar);
			for (GSublist<Car> g : osgslcar) {
				System.out.println("GSublist<Car>: " + g.toString());
			}
			
			GSublist<Ferrari> gslf = new GSublist<Ferrari>();
			ObjectSet<GSublist<Ferrari>> osgslf = db.get(gslf);
			for (GSublist<Ferrari> g : osgslf) {
				System.out.println("GSublist<Ferrari>: " + g.toString());
			}
		} finally {
			db.close();
		}
	}
		
	private void testConformance() {
		GList<Integer> glint = new GList<Integer>();
		GList<Car> glcar = new GList<Car>();
		GList<Ferrari> glf = new GList<Ferrari>();
		GSublist<Integer> gslint = new GSublist<Integer>();
		GSublist<Car> gslcar = new GSublist<Car>();
		GSublist<Ferrari> gslf = new GSublist<Ferrari>();
		
		System.out.println("Type of GList<Integer>: " + glint.getClass().getName());
		System.out.println("Type of GList<Car>: " + glcar.getClass().getName());
		System.out.println("Type of GList<Ferrari>: " + glf.getClass().getName());
		System.out.println("Type of GSublist<Integer>: " + gslint.getClass().getName());
		System.out.println("Type of GSublist<Car>: " + gslcar.getClass().getName());
		System.out.println("Type of GSublist<Ferrari>: " + gslf.getClass().getName());
		
		//glcar = glf;  // Type mismatch: cannot convert from GList<Ferrari> to GList<Car>
		glint = gslint;  // OK
		glcar = gslcar;  // OK
		//glcar = gslf; // Type mismatch: cannot convert from GSublist<Ferrari> to GList<Car>
	}
}
