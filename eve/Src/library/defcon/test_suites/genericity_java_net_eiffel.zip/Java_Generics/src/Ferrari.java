
public class Ferrari
extends Car
{
	public Ferrari(String n) 
	{		
		super(n);
	}
	
	public String toString() {
		return "Ferrari: " + Name;
	}
}
