
public class GList<E> {
	public E item;
	public GList<E> next;
	
	public GList () {
		
	}
	
	public void put(E a_item) {
		if (item == null) {
			item = a_item;
		} else {
			if (next == null) {
				next = new GList<E>();
				next.item = a_item;
			} else {
				next.put(a_item);
			}
		}
	}
	
	public String toString() {
		if (item == null) {
			return "";
		}
		if (next == null) {
			return item.toString();
		}		
		return item.toString() + ", " + next.toString();
	}
}
