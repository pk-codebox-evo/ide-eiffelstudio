
public class GSublist<E> 
extends GList<E>
{
	public int count;
	public GSublist<E> nextSublist;
	
	public GSublist() {
		super();
		count = 0;
	}
	
	public void put(E a_item) {
		if (item == null) {
			item = a_item;
		} else {
			if (nextSublist == null) {
				nextSublist = new GSublist<E>();
				nextSublist.item = a_item;
			} else {
				nextSublist.put(a_item);
			}
		}
	}
	
	public String toString() {
		if (item == null) {
			return "";
		}
		if (nextSublist == null) {
			return item.toString();
		}		
		return item.toString() + ", " + nextSublist.toString();
	}
}
