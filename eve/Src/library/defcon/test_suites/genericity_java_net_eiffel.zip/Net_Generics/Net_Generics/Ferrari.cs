using System;
using System.Collections.Generic;
using System.Text;

namespace net_generics
{
    class Ferrari : Car
    {
        public Ferrari(string n)
            : base(n)
        {

        }

        public override string ToString()
        {
            return "Ferrari: " + Name;
        }
    }
}
