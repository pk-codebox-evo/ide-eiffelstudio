using System;
using System.Collections.Generic;
using System.Text;

namespace net_generics
{
    class Car
    {
        public string Name;

        public Car(string n)
        {
            Name = n;
        }

        public override string ToString()
        {
            return "Car: " + Name;
        }
    }
}
