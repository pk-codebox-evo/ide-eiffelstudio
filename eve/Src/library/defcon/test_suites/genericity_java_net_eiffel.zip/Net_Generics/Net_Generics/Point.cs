using System;
using System.Collections.Generic;
using System.Text;

namespace net_generics
{
    struct Point
    {
        private int x;
        private int y;

        public Point(int a, int b)
        {
            x = a;
            y = b;
        }

        public override string ToString()
        {
            return "Point (" + x + ", " + y + ")";
        }
    }
}
