using System;
using System.Collections.Generic;
using System.Text;
using Db4objects.Db4o;
using System.IO;

namespace net_generics
{
    class Program
    {
        public static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
            Console.ReadLine();
        }

        private void test()
        {
            File.Delete("test_generics_net.yap");
            store();
            retrieve();
            testConformance();
        }

        private void store()
        {
            IObjectContainer db = Db4oFactory.OpenFile("test_generics_net.yap");
            try
            {
                GList<int> gint = new GList<int>();
                gint.Put(1);
                db.Set(gint);

                GList<Int32> gint32 = new GList<Int32>();
                gint32.Put(4);
                db.Set(gint32);

                GList<Car> gcar = new GList<Car>();
                gcar.Put(new Car("car1")); 
                db.Set(gcar);  

                GList<Ferrari> gf = new GList<Ferrari>();
                gf.Put(new Ferrari("F450"));
                db.Set(gf);

                GList<Point> gp = new GList<Point>();
                gp.Put(new Point(1, 2));
                db.Set(gp);

                GSublist<Car> gscar = new GSublist<Car>();
                gscar.Put(new Car("subcar4")); 
                db.Set(gscar);

                GSublist<Ferrari> gsf = new GSublist<Ferrari>();
                gsf.Put(new Ferrari("SubF340"));
                db.Set(gsf);

                GSublist<Point> gsp = new GSublist<Point>();
                gsp.Put(new Point(3, 4));
                db.Set(gsp);
            }
            finally
            {
                db.Close();
            }
        }

        private void retrieve()
        {
            IObjectContainer db = Db4oFactory.OpenFile("test_generics_net.yap");
            try
            {
                Console.WriteLine("retrieved instances of GList<int>:");
                IObjectSet osint = db.Get(new GList<int>());
                while (osint.HasNext())
                {
                    Console.WriteLine(osint.Next());
                }
                Console.WriteLine();

                Console.WriteLine("retrieved instances of GList<Int32>:");
                IObjectSet osint32 = db.Get(new GList<Int32>());
                while (osint32.HasNext())
                {
                    Console.WriteLine(osint32.Next());
                }
                Console.WriteLine();

                Console.WriteLine("retrieved instances of GList<Car>:");
                IObjectSet oscar = db.Get(new GList<Car>());
                while (oscar.HasNext())
                {
                    Console.WriteLine(oscar.Next());
                }
                Console.WriteLine();

                Console.WriteLine("retrieved instances of GList<Ferrari>:");
                IObjectSet osf = db.Get(new GList<Ferrari>());
                while (osf.HasNext())
                {
                    Console.WriteLine(osf.Next());
                }
                Console.WriteLine();

                Console.WriteLine("retrieved instances of GList<Point>:");
                IObjectSet osp = db.Get(new GList<Point>());
                while (osp.HasNext())
                {
                    Console.WriteLine(osp.Next());
                }
                Console.WriteLine();

                Console.WriteLine("retrieved instances of GSublist<Car>:");
                IObjectSet ossublistcar = db.Get(new GSublist<Car>());
                while (ossublistcar.HasNext())
                {
                    Console.WriteLine(ossublistcar.Next());
                }
                Console.WriteLine();

                Console.WriteLine("retrieved instances of GSublist<Ferrari>:");
                IObjectSet ossublistf = db.Get(new GSublist<Ferrari>());
                while (ossublistf.HasNext())
                {
                    Console.WriteLine(ossublistf.Next());
                }
                Console.WriteLine();

                Console.WriteLine("retrieved instances of GSublist<Point>:");
                IObjectSet ossublistp = db.Get(new GSublist<Point>());
                while (ossublistp.HasNext())
                {
                    Console.WriteLine(ossublistp.Next());
                }
                Console.WriteLine();
            }
            finally
            {
                db.Close();
            }
        }

        private void testConformance()
        {
            GList<Car> cars = new GList<Car>();
            GList<Ferrari> fs = new GList<Ferrari>();
            GList<Point> ps = new GList<Point>();
            GSublist<Car> sublistcars = new GSublist<Car>();
            GSublist<Ferrari> sublistfs = new GSublist<Ferrari>();
            GSublist<Point> sublistps = new GSublist<Point>();

            Console.WriteLine("Type of GList<int>: " + typeof(GList<int>).FullName);
            Console.WriteLine("Type of GList<Int32>: " + typeof(GList<Int32>).FullName);
            Console.WriteLine("Type of GList<Car>: " + typeof(GList<Car>).FullName);
            Console.WriteLine("Type of GList<Ferrari>: " + typeof(GList<Ferrari>).FullName);
            Console.WriteLine("Type of GList<Point>: " + typeof(GList<Point>).FullName);
            Console.WriteLine("Type of GSublist<Car>: " + typeof(GSublist<Car>).FullName);
            Console.WriteLine("Type of GSublist<Ferrari>: " + typeof(GSublist<Ferrari>).FullName);
            Console.WriteLine("Type of GSublist<Point>: " + typeof(GSublist<Point>).FullName);

            //cars = (GList<Car>)fs; // Error	1	Cannot (implicitly) convert type 'net_generics.GList<net_generics.Ferrari>' to 'net_generics.GList<net_generics.Car>'
            cars = sublistcars;  // OK
            fs = sublistfs; // OK
            //cars = (GList<Car>)sublistfs;  // Error	1	Cannot (implicitly) convert type 'net_generics.GSublist<net_generics.Ferrari>' to 'net_generics.GList<net_generics.Car>'
            ps = sublistps; // OK
        }
    }
}
