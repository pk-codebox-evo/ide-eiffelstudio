using System;
using System.Collections.Generic;
using System.Text;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using System.IO;

namespace TestTreeNode
{
    class Program
    {
        private const int ROOT_ID = 123;
        private const int TREE_LEVEL = 8;
        private Random rand;

        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            File.Delete("test_treenode.yap");  
         
            rand = new Random();
            TreeNode root = makeTree(0);
            printTree(root, 0);

            // store and retrieve the tree, and then compare the two trees
            storeTree(root);            
            TreeNode res_root = retrieveTree();            
            if (res_root != null)
            {
                Console.WriteLine("The retrieved tree is " + (res_root.DeepEquals(root) ? "" : "not ") + "equal to the original one.");
            }

            // store and retrieve the updated tree, and then compare the two trees
            root.Left.Left.Right.ID = 200;
            updateTree();            
            TreeNode res_updated_root = retrieveTree();
            if (res_updated_root != null)
            {
                Console.WriteLine("The tree is " + (res_updated_root.DeepEquals(root) ? "" : "not ") + "updated in the database.");
            }

            // delete the tree
            deleteTree();
        }

        private TreeNode makeTree(int level)
        {
            if (level > TREE_LEVEL)
            {
                return null;
            }
            TreeNode node;
            if (level == 0)
            {
                node = new TreeNode(ROOT_ID);
            }
            else
            {
                node = new TreeNode(rand.Next(1, 100));
            }
            node.Left = makeTree(level + 1);
            node.Right = makeTree(level + 1);
            return node;
        }

        private void printTree(TreeNode node, int level)
        {
            string indent = "";
            for (int i = level; i > 0; i--)
            {
                indent = indent + "    ";
            }
            Console.WriteLine(indent + node.ID);
            if (node.Left != null)
            {
                printTree(node.Left, level + 1);
            }
            if (node.Right != null)
            {
                printTree(node.Right, level + 1);
            }
        }

        private void storeTree(TreeNode root)
        {
            IObjectContainer db = Db4oFactory.OpenFile("test_treenode.yap");
            try
            {
                db.Set(root);
            }
            finally
            {
                db.Close();
            }
        }

        private TreeNode retrieveTree()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            config.ObjectClass(typeof(TreeNode)).CascadeOnActivate(true);  // starting from the root node, the whole tree is activated
            //config.ObjectClass(typeof(TreeNode)).ObjectField("_left").CascadeOnActivate(true);  // The tree is activated to the 5. level, which is default.
            //config.ObjectClass(typeof(TreeNode)).ObjectField("_right").CascadeOnActivate(true);
            IObjectContainer db = Db4oFactory.OpenFile(config, "test_treenode.yap");
            try
            {
                TreeNode node = new TreeNode(ROOT_ID);
                IObjectSet os = db.Get(node);
                if (os.HasNext())
                {
                    TreeNode root = os.Next() as TreeNode;
                    return root;
                }
                else
                {
                    return null;
                }
            }
            finally
            {
                db.Close();
            }
        }

        // Set root.Left.Left.Right.ID to 200 and store the update in the database.
        private void updateTree()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            config.ObjectClass(typeof(TreeNode)).CascadeOnActivate(true);          
            // settings for the update depth
            config.ObjectClass(typeof(TreeNode)).CascadeOnUpdate(true); // OK, the node is updated 
            //config.ObjectClass(typeof(TreeNode)).ObjectField("_left").CascadeOnUpdate(true);  // OK, the node is updated
            //config.ObjectClass(typeof(TreeNode)).ObjectField("_right").CascadeOnUpdate(true);
            //config.UpdateDepth(3); // requires depth >= 3
            //config.ObjectClass(typeof(TreeNode)).UpdateDepth(3);  // requires depth >= 3
            IObjectContainer db = Db4oFactory.OpenFile(config, "test_treenode.yap");
            try
            {
                TreeNode node = new TreeNode(ROOT_ID);
                IObjectSet os = db.Get(node);
                if (os.HasNext())  // suppose there is only one tree in the database
                {
                    TreeNode root = os.Next() as TreeNode;
                    if (root != null)
                    {
                        root.Left.Left.Right.ID = 200;                         
                        db.Set(root);  // requires the update depth >= 3
                        //db.Ext().Set(root, 4);  // requires depth>=4
                    }
                }
            }
            finally
            {
                db.Close();
            }
        }

        private void deleteTree()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            config.ObjectClass(typeof(TreeNode)).CascadeOnDelete(true);  // OK, starting from the root node, the whole tree can be deleted
            //config.ObjectClass(typeof(TreeNode)).ObjectField("_left").CascadeOnDelete(true);  // OK, starting from the root node, the whole tree can be deleted
            //config.ObjectClass(typeof(TreeNode)).ObjectField("_right").CascadeOnDelete(true);
            IObjectContainer db = Db4oFactory.OpenFile(config, "test_treenode.yap");
            try
            {
                TreeNode node = new TreeNode(ROOT_ID);
                IObjectSet os = db.Get(node);
                if (os.HasNext())  // suppose there is only one tree in the database
                {
                    db.Delete(os.Next());
                }
            }
            finally
            {
                db.Close();
            }
        }
 
    }
}


