using System;
using System.Collections.Generic;
using System.Text;

namespace TestTreeNode
{
    class TreeNode
    {
        private int _id;
        private TreeNode _left, _right, _parent;
 
        public TreeNode(int i) {
            _id = i;
        }

        public int ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public TreeNode Left
        {
            get
            {
                return _left;
            }
            set
            {
                _left = value;
                if (value != null)
                {
                    _left.Parent = this;
                }
            }
        }

        public TreeNode Right
        {
            get
            {
                return _right;
            }
            set
            {
                _right = value;
                if (value != null)
                {
                    _right.Parent = this;
                }
            }
        }

        public TreeNode Parent
        {
            get
            {
                return _parent;
            }
            set
            {
                _parent = value;
            }
        }

        public bool DeepEquals(TreeNode node)
        {
            if (node == null)
            {
                return false;
            }
            if (ID != node.ID)
            {
                return false;
            }
            if (Left != null)
            {
                if (!Left.DeepEquals(node.Left))
                {
                    return false;
                }
            }
            if (Right != null) 
            {
                if (!Right.DeepEquals(node.Right))
                {
                    return false;
                }
            }
            return true;
        }
    }
}

