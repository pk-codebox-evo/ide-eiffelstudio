public class TreeNode {
	private int _id;
	private TreeNode _left, _right, _parent;

	public TreeNode(int i) {
		_id = i;
	}

	public void SetID(int i) {
		_id = i;
	}

	public int GetID() {
		return _id;
	}

	public void SetLeft(TreeNode l) {
		_left = l;
		if (_left != null) {
			_left.SetParent(this);
		}
	}

	public TreeNode GetLeft() {
		return _left;
	}

	public void SetRight(TreeNode r) {
		_right = r;
		if (_right != null) {
			_right.SetParent(this);
		}
	}

	public TreeNode GetRight() {
		return _right;
	}

	public void SetParent(TreeNode p) {
		_parent = p;
	}

	public TreeNode GetParent() {
		return _parent;
	}

	public boolean DeepEquals(TreeNode node) {
		if (node == null) {
			return false;
		}
		if (_id != node.GetID()) {
			return false;
		}
		if (_left != null) {
			if (!_left.DeepEquals(node.GetLeft())) {
				return false;
			}
		}
		if (_right != null) {
			if (!_right.DeepEquals(node.GetRight())) {
				return false;
			}
		}
		return true;
	}
}
