import java.util.*;
import com.db4o.*;
import com.db4o.config.*;
import java.io.*;

public class Test {

	private final static int ROOT_ID = 123;
	private final static int TREE_LEVEL = 8;
	private Random rand;

	public static void main(String[] args) {
		Test t = new Test();
		t.test();
	}

	private void test() {
		new File("test_treenode.yap").delete();

		rand = new Random();
		TreeNode root = makeTree(0);
		printTree(root, 0);

		// store and retrieve the tree, and then compare the two trees
		storeTree(root);
		TreeNode res_root = retrieveTree();
		if (res_root != null) {
			System.out.println("The retrieved tree is "
					+ (res_root.DeepEquals(root) ? "" : "not ")
					+ "equal to the original one.");
		}

		// store and retrieve the updated tree, and then compare the two trees
		root.GetLeft().GetLeft().GetRight().SetID(200);
		updateTree();
		TreeNode res_updated_root = retrieveTree();
		if (res_updated_root != null) {
			System.out.println("The tree is "
					+ (res_updated_root.DeepEquals(root) ? "" : "not ")
					+ "updated in the database.");
		}

		// delete the tree
		deleteTree();
	}

	private TreeNode makeTree(int level) {
		if (level > TREE_LEVEL) {
			return null;
		}
		TreeNode node;
		if (level == 0) {
			node = new TreeNode(ROOT_ID);
		} else {
			node = new TreeNode(rand.nextInt(100));
		}
		node.SetLeft(makeTree(level + 1));
		node.SetRight(makeTree(level + 1));
		return node;
	}

	private void printTree(TreeNode node, int level) {
		String indent = "";
		for (int i = level; i > 0; i--) {
			indent = indent + "    ";
		}
		System.out.println(indent + node.GetID());
		if (node.GetLeft() != null) {
			printTree(node.GetLeft(), level + 1);
		}
		if (node.GetRight() != null) {
			printTree(node.GetRight(), level + 1);
		}
	}

	private void storeTree(TreeNode root) {
		ObjectContainer db = Db4o.openFile("test_treenode.yap");
		try {
			db.set(root);
		} finally {
			db.close();
		}
	}

	private TreeNode retrieveTree() {
		Configuration config = Db4o.newConfiguration();
		config.objectClass(TreeNode.class).cascadeOnActivate(true); // starting from the root, the whole is activated
		//config.objectClass(TreeNode.class).objectField("_left").cascadeOnActivate(true); // The tree is activated to the 5. level, which is default.
		//config.objectClass(TreeNode.class).objectField("_right").cascadeOnActivate(true);
		ObjectContainer db = Db4o.openFile(config, "test_treenode.yap");
		try {
			TreeNode node = new TreeNode(ROOT_ID);
			ObjectSet os = db.get(node);
			if (os.hasNext()) {
				TreeNode root = (TreeNode) os.next();
				return root;
			} else {
				return null;
			}
		} finally {
			db.close();
		}
	}

	// Set root.Left.Left.Right.ID to 200 and store the update in the database.
	private void updateTree() {
		Configuration config = Db4o.newConfiguration();
		config.objectClass(TreeNode.class).cascadeOnActivate(true);
		// settings for the update depth
		config.objectClass(TreeNode.class).cascadeOnUpdate(true); // OK, the node is updated
		//config.objectClass(TreeNode.class).objectField("_left").cascadeOnUpdate(true); // OK, the node is updated
		//config.objectClass(TreeNode.class).objectField("_right").cascadeOnUpdate(true);
		//config.updateDepth(3); // requires depth >= 3
		//config.objectClass(TreeNode.class).updateDepth(3); // requires depth >= 3
		ObjectContainer db = Db4o.openFile(config, "test_treenode.yap");
		try {
			TreeNode node = new TreeNode(ROOT_ID);
			ObjectSet os = db.get(node);
			if (os.hasNext()) // suppose there is only one tree in the database
			{
				TreeNode root = (TreeNode) os.next();
				if (root != null) {
					root.GetLeft().GetLeft().GetRight().SetID(200);
					db.set(root); // requires the update depth >= 3
					//db.ext().set(root, 4); // requires depth>=4
				}
			}
		} finally {
			db.close();
		}
	}

	private void deleteTree() {
		Configuration config = Db4o.newConfiguration();
		config.objectClass(TreeNode.class).cascadeOnDelete(true); // OK, starting from the root node, the whole tree can be deleted
		//config.objectClass(TreeNode.class).objectField("_left").cascadeOnDelete(true); // OK, starting from the root node, the whole tree can be deleted
		//config.objectClass(TreeNode.class).objectField("_right").cascadeOnDelete(true);
		ObjectContainer db = Db4o.openFile(config, "test_treenode.yap");
		try {
			TreeNode node = new TreeNode(ROOT_ID);
			ObjectSet os = db.get(node);
			if (os.hasNext()) // suppose there is only one tree in the database
			{
				db.delete(os.next());
			}
		} finally {
			db.close();
		}
	}

}
