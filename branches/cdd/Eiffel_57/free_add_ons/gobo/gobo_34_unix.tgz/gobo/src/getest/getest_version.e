indexing

	description:

		"Version of getest"

	copyright: "Copyright (c) 2000-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/01 14:06:30 $"
	revision: "$Revision: 1.11 $"

class GETEST_VERSION

inherit

	KL_GOBO_VERSION

end
