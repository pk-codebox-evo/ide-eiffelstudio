indexing

	description:

		"Version of gelex"

	copyright: "Copyright (c) 1999-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/01 14:06:27 $"
	revision: "$Revision: 1.12 $"

class GELEX_VERSION

inherit

	KL_GOBO_VERSION

end
