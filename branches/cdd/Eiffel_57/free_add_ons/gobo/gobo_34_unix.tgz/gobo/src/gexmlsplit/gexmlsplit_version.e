indexing

	description:

		"Version of gexmlsplit"

	copyright: "Copyright (c) 2002-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/01 14:06:31 $"
	revision: "$Revision: 1.6 $"

class GEXMLSPLIT_VERSION

inherit

	KL_GOBO_VERSION

end
