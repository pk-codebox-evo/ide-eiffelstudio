indexing

	description:

		"Variable resolvers"

	library: "Gobo Eiffel Ant"
	copyright: "Copyright (c) 2004, Sven Ehrke and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/09/26 15:17:19 $"
	revision: "$Revision: 1.1 $"

deferred class GEANT_VARIABLE_RESOLVER

inherit

	KL_VALUES [STRING, STRING]

feature -- Status report

	has (k: STRING): BOOLEAN is
			-- Is there an item associated with `k'?
		require
			k_not_void: k /= Void 
			k_not_empty: not k.is_empty
		deferred
		end

end
