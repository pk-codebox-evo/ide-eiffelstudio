indexing

	description:

		"Version of gelint"

	copyright: "Copyright (c) 2002-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/01 14:06:29 $"
	revision: "$Revision: 1.6 $"

class GELINT_VERSION

inherit

	KL_GOBO_VERSION

end
