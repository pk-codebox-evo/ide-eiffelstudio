indexing

	description:

		"Version of gepp"

	copyright: "Copyright (c) 1999-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/01 14:06:29 $"
	revision: "$Revision: 1.12 $"

class GEPP_VERSION

inherit

	KL_GOBO_VERSION

end
