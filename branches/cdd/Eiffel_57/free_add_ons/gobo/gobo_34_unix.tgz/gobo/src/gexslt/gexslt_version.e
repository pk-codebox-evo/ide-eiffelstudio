indexing

	description:

		"Version of gexslt"

	copyright: "Copyright (c) 2004, Colin Adams and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/01 14:06:32 $"
	revision: "$Revision: 1.2 $"

class GEXSLT_VERSION

inherit

	KL_GOBO_VERSION

end
