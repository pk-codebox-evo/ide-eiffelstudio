indexing

	description:

		"Geant argument elements"

	library: "Gobo Eiffel Ant"
	copyright: "Copyright (c) 2002, Sven Ehrke and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/09/10 15:14:20 $"
	revision: "$Revision: 1.1 $"

class GEANT_ARGUMENT_ELEMENT

inherit

	GEANT_NAME_VALUE_ELEMENT

creation

	make

end
