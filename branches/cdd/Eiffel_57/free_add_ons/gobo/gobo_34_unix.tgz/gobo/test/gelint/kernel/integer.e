indexing

	description:

		"Dummy class INTEGER used by gelint tests."

	library:    "Gobo Eiffel Tools Library"
	author:     "Eric Bezault <ericb@gobosoft.com>"
	copyright:  "Copyright (c) 2001, Eric Bezault and others"
	license:    "Eiffel Forum License v2 (see forum.txt)"
	date:       "$Date: 2003/02/07 13:25:07 $"
	revision:   "$Revision: 1.2 $"

expanded class INTEGER

end -- class INTEGER
