indexing

	description:

		"Test 'geyacc'"

	copyright: "Copyright (c) 2001-2002, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 13:24:37 $"
	revision: "$Revision: 1.5 $"

deferred class TEST_GEYACC

inherit

	TOOL_TEST_CASE

feature -- Access

	program_name: STRING is "geyacc"
			-- Program name

feature -- Test

	test_geyacc is
			-- Test 'geyacc'.
		do
			compile_program
		end

end
