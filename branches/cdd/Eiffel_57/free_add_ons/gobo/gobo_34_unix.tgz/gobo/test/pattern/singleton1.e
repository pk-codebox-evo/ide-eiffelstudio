indexing

	description:

		"Singleton1"

	library: "Gobo Eiffel Pattern Library"
	copyright: "Copyright (c) 2003, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/03/13 10:08:30 $"
	revision: "$Revision: 1.4 $"

class SINGLETON1

inherit

	ANY -- Needed for SE 2.1.

	SHARED_SINGLETON1

creation

	make

feature {NONE} -- Initialization

	make is
			-- Create a singleton object.
		require
			singleton1_not_created: not singleton1_created
		do
			singleton1_cell.put (Current)
		end

invariant

	singleton1_created: singleton1_created
	singleton_pattern: Current = singleton1

end
