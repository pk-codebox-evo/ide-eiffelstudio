indexing

	description:

		"Dummy class CHARACTER used by gelint tests."

	library:    "Gobo Eiffel Tools Library"
	author:     "Eric Bezault <ericb@gobosoft.com>"
	copyright:  "Copyright (c) 2001, Eric Bezault and others"
	license:    "Eiffel Forum License v2 (see forum.txt)"
	date:       "$Date: 2003/02/07 13:25:06 $"
	revision:   "$Revision: 1.2 $"

expanded class CHARACTER

end -- class CHARACTER
