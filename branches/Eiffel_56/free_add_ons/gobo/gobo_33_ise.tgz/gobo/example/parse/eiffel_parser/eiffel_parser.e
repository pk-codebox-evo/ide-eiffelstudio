indexing

	description:

		"Eiffel parsers"

	copyright: "Copyright (c) 1999-2003, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/04/18 15:52:30 $"
	revision: "$Revision: 1.7 $"

class EIFFEL_PARSER

inherit

	YY_NEW_PARSER_SKELETON
		rename
			make as make_parser_skeleton
		redefine
			report_error
		end

	EIFFEL_SCANNER
		rename
			make as make_eiffel_scanner
		end

	KL_SHARED_EXCEPTIONS
	KL_SHARED_ARGUMENTS

creation

	make, execute, benchmark


feature {NONE} -- Implementation

	yy_build_parser_tables is
			-- Build parser tables.
		do
			yytranslate := yytranslate_template
			yyr1 := yyr1_template
			yytypes1 := yytypes1_template
			yytypes2 := yytypes2_template
			yydefact := yydefact_template
			yydefgoto := yydefgoto_template
			yypact := yypact_template
			yypgoto := yypgoto_template
			yytable := yytable_template
			yycheck := yycheck_template
		end

	yy_create_value_stacks is
			-- Create value stacks.
		do
		end

	yy_init_value_stacks is
			-- Initialize value stacks.
		do
			yyvsp1 := -1
		end

	yy_clear_value_stacks is
			-- Clear objects in semantic value stacks so that
			-- they can be collected by the garbage collector.
		do
			if yyvs1 /= Void then
				yyvs1.clear_all
			end
		end

	yy_push_last_value (yychar1: INTEGER) is
			-- Push semantic value associated with token `last_token'
			-- (with internal id `yychar1') on top of corresponding
			-- value stack.
		do
			yyvsp1 := yyvsp1 + 1
			if yyvsp1 >= yyvsc1 then
				if yyvs1 = Void then
					debug ("GEYACC")
						std.error.put_line ("Create yyvs1")
					end
					create yyspecial_routines1
					yyvsc1 := yyInitial_yyvs_size
					yyvs1 := yyspecial_routines1.make (yyvsc1)
				else
					debug ("GEYACC")
						std.error.put_line ("Resize yyvs1")
					end
					yyvsc1 := yyvsc1 + yyInitial_yyvs_size
					yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
				end
			end
			yyvs1.put (last_any_value, yyvsp1)
		end

	yy_push_error_value is
			-- Push semantic value associated with token 'error'
			-- on top of corresponding value stack.
		local
			yyval1: ANY
		do
			yyvsp1 := yyvsp1 + 1
			if yyvsp1 >= yyvsc1 then
				if yyvs1 = Void then
					debug ("GEYACC")
						std.error.put_line ("Create yyvs1")
					end
					create yyspecial_routines1
					yyvsc1 := yyInitial_yyvs_size
					yyvs1 := yyspecial_routines1.make (yyvsc1)
				else
					debug ("GEYACC")
						std.error.put_line ("Resize yyvs1")
					end
					yyvsc1 := yyvsc1 + yyInitial_yyvs_size
					yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
				end
			end
			yyvs1.put (yyval1, yyvsp1)
		end

	yy_pop_last_value (yystate: INTEGER) is
			-- Pop semantic value from stack when in state `yystate'.
		local
			yy_type_id: INTEGER
		do
			yy_type_id := yytypes1.item (yystate)
			inspect yy_type_id
			when 1 then
				yyvsp1 := yyvsp1 - 1
			else
				debug ("GEYACC")
					std.error.put_string ("Error in parser: unknown type id: ")
					std.error.put_integer (yy_type_id)
					std.error.put_new_line
				end
				abort
			end
		end

feature {NONE} -- Semantic actions

	yy_do_action (yy_act: INTEGER) is
			-- Execute semantic action.
		local
			yyval1: ANY
		do
			inspect yy_act
when 1 then
--|#line 71 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 71")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 2 then
--|#line 72 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 72")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 3 then
--|#line 75 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 75")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 8
	yyvsp1 := yyvsp1 -7
	yyvs1.put (yyval1, yyvsp1)
end
when 4 then
--|#line 77 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 77")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 5 then
--|#line 80 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 80")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 6 then
--|#line 85 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 85")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 7 then
--|#line 86 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 86")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 8 then
--|#line 89 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 89")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 9 then
--|#line 90 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 90")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 10 then
--|#line 91 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 91")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 11 then
--|#line 94 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 94")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 12 then
--|#line 95 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 95")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 13 then
--|#line 96 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 96")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 14 then
--|#line 97 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 97")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 15 then
--|#line 100 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 100")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 16 then
--|#line 101 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 101")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 17 then
--|#line 104 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 104")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 18 then
--|#line 105 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 105")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 19 then
--|#line 108 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 108")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 20 then
--|#line 109 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 109")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 21 then
--|#line 112 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 112")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 22 then
--|#line 113 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 113")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 23 then
--|#line 118 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 118")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 24 then
--|#line 121 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 121")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 25 then
--|#line 122 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 122")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 26 then
--|#line 123 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 123")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 27 then
--|#line 124 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 124")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 28 then
--|#line 129 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 129")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 29 then
--|#line 130 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 130")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 30 then
--|#line 133 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 133")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 31 then
--|#line 134 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 134")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 32 then
--|#line 135 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 135")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 33 then
--|#line 138 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 138")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 34 then
--|#line 139 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 139")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 35 then
--|#line 141 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 141")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 36 then
--|#line 144 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 144")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 37 then
--|#line 149 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 149")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 38 then
--|#line 150 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 150")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 39 then
--|#line 155 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 155")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 40 then
--|#line 158 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 158")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 41 then
--|#line 159 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 159")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 42 then
--|#line 160 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 160")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 43 then
--|#line 161 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 161")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 44 then
--|#line 163 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 163")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 45 then
--|#line 164 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 164")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 46 then
--|#line 175 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 175")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 47 then
--|#line 176 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 176")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 48 then
--|#line 177 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 177")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 49 then
--|#line 178 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 178")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 50 then
--|#line 179 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 179")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 51 then
--|#line 182 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 182")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 52 then
--|#line 183 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 183")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 53 then
--|#line 186 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 186")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 54 then
--|#line 188 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 188")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 55 then
--|#line 189 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 189")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 56 then
--|#line 190 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 190")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 57 then
--|#line 191 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 191")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 58 then
--|#line 197 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 197")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 6
	yyvsp1 := yyvsp1 -5
	yyvs1.put (yyval1, yyvsp1)
end
when 59 then
--|#line 201 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 201")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 60 then
--|#line 205 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 205")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 61 then
--|#line 208 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 208")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 62 then
--|#line 211 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 211")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 63 then
--|#line 216 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 216")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 64 then
--|#line 217 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 217")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 65 then
--|#line 220 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 220")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 66 then
--|#line 221 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 221")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 67 then
--|#line 226 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 226")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 68 then
--|#line 229 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 229")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 69 then
--|#line 230 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 230")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 70 then
--|#line 233 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 233")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 71 then
--|#line 234 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 234")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 72 then
--|#line 235 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 235")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 73 then
--|#line 238 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 238")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 74 then
--|#line 239 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 239")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 75 then
--|#line 240 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 240")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 76 then
--|#line 243 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 243")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 77 then
--|#line 246 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 246")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 78 then
--|#line 247 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 247")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 79 then
--|#line 250 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 250")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 80 then
--|#line 251 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 251")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 81 then
--|#line 252 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 252")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 82 then
--|#line 257 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 257")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 83 then
--|#line 260 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 260")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 84 then
--|#line 261 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 261")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 85 then
--|#line 264 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 264")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 86 then
--|#line 265 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 265")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 87 then
--|#line 266 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 266")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 88 then
--|#line 271 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 271")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 89 then
--|#line 274 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 274")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 90 then
--|#line 275 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 275")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 91 then
--|#line 278 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 278")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 92 then
--|#line 281 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 281")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 93 then
--|#line 282 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 282")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 94 then
--|#line 285 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 285")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 95 then
--|#line 288 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 288")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 96 then
--|#line 289 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 289")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 97 then
--|#line 294 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 294")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 98 then
--|#line 295 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 295")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 99 then
--|#line 298 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 298")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 100 then
--|#line 299 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 299")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 101 then
--|#line 302 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 302")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 102 then
--|#line 304 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 304")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 103 then
--|#line 309 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 309")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 104 then
--|#line 310 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 310")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 105 then
--|#line 311 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 311")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 106 then
--|#line 316 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 316")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 107 then
--|#line 317 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 317")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 108 then
--|#line 320 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 320")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 109 then
--|#line 321 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 321")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 110 then
--|#line 324 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 324")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 111 then
--|#line 329 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 329")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 112 then
--|#line 330 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 330")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 113 then
--|#line 331 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 331")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 114 then
--|#line 334 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 334")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 115 then
--|#line 335 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 335")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 116 then
--|#line 336 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 336")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 117 then
--|#line 341 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 341")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 118 then
--|#line 344 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 344")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 119 then
--|#line 347 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 347")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 120 then
--|#line 348 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 348")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 121 then
--|#line 351 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 351")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 122 then
--|#line 352 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 352")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 123 then
--|#line 353 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 353")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 124 then
--|#line 358 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 358")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 125 then
--|#line 359 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 359")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 126 then
--|#line 362 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 362")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 127 then
--|#line 363 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 363")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 128 then
--|#line 368 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 368")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 129 then
--|#line 369 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 369")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 130 then
--|#line 370 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 370")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 131 then
--|#line 373 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 373")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 132 then
--|#line 374 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 374")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 133 then
--|#line 375 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 375")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 134 then
--|#line 376 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 376")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 135 then
--|#line 379 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 379")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 136 then
--|#line 380 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 380")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 137 then
--|#line 381 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 381")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 138 then
--|#line 382 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 382")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 139 then
--|#line 383 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 383")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 140 then
--|#line 384 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 384")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 141 then
--|#line 385 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 385")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 142 then
--|#line 386 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 386")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 143 then
--|#line 387 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 387")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 144 then
--|#line 388 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 388")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 145 then
--|#line 389 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 389")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 146 then
--|#line 390 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 390")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 147 then
--|#line 391 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 391")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 148 then
--|#line 392 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 392")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 149 then
--|#line 393 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 393")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 150 then
--|#line 394 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 394")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 151 then
--|#line 395 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 395")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 152 then
--|#line 396 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 396")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 153 then
--|#line 401 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 401")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 154 then
--|#line 402 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 402")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 155 then
--|#line 405 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 405")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 156 then
--|#line 406 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 406")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 157 then
--|#line 407 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 407")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 158 then
--|#line 410 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 410")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 159 then
--|#line 411 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 411")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 160 then
--|#line 412 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 412")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 161 then
--|#line 415 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 415")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 162 then
--|#line 418 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 418")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 163 then
--|#line 419 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 419")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 164 then
--|#line 422 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 422")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 165 then
--|#line 423 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 423")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 166 then
--|#line 428 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 428")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 7
	yyvsp1 := yyvsp1 -6
	yyvs1.put (yyval1, yyvsp1)
end
when 167 then
--|#line 436 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 436")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 168 then
--|#line 437 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 437")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 169 then
--|#line 438 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 438")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 170 then
--|#line 439 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 439")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 171 then
--|#line 442 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 442")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 172 then
--|#line 443 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 443")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 173 then
--|#line 448 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 448")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 174 then
--|#line 449 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 449")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 175 then
--|#line 454 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 454")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 176 then
--|#line 455 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 455")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 177 then
--|#line 456 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 456")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 178 then
--|#line 459 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 459")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 179 then
--|#line 460 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 460")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 180 then
--|#line 461 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 461")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 181 then
--|#line 464 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 464")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 182 then
--|#line 465 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 465")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 183 then
--|#line 468 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 468")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 184 then
--|#line 469 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 469")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 185 then
--|#line 470 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 470")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 186 then
--|#line 473 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 473")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 187 then
--|#line 474 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 474")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 188 then
--|#line 475 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 475")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 189 then
--|#line 478 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 478")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 190 then
--|#line 482 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 482")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 191 then
--|#line 488 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 488")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 192 then
--|#line 489 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 489")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 193 then
--|#line 494 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 494")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 194 then
--|#line 495 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 495")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 195 then
--|#line 496 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 496")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 196 then
--|#line 497 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 497")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 197 then
--|#line 498 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 498")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 198 then
--|#line 499 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 499")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 199 then
--|#line 500 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 500")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 200 then
--|#line 503 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 503")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 201 then
--|#line 506 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 506")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 202 then
--|#line 509 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 509")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 203 then
--|#line 510 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 510")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 204 then
--|#line 513 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 513")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 205 then
--|#line 514 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 514")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 206 then
--|#line 515 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 515")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 207 then
--|#line 520 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 520")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 208 then
--|#line 521 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 521")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 209 then
--|#line 524 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 524")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 210 then
--|#line 525 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 525")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 211 then
--|#line 528 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 528")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 212 then
--|#line 529 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 529")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 213 then
--|#line 530 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 530")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 214 then
--|#line 531 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 531")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 215 then
--|#line 532 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 532")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 216 then
--|#line 533 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 533")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 217 then
--|#line 534 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 534")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 218 then
--|#line 535 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 535")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 219 then
--|#line 536 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 536")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 220 then
--|#line 537 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 537")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 221 then
--|#line 539 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 539")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 222 then
--|#line 544 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 544")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 223 then
--|#line 545 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 545")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 224 then
--|#line 548 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 548")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 225 then
--|#line 549 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 549")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 226 then
--|#line 554 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 554")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 6
	yyvsp1 := yyvsp1 -5
	yyvs1.put (yyval1, yyvsp1)
end
when 227 then
--|#line 555 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 555")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 228 then
--|#line 558 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 558")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 229 then
--|#line 563 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 563")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 230 then
--|#line 566 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 566")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 231 then
--|#line 567 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 567")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 232 then
--|#line 572 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 572")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 7
	yyvsp1 := yyvsp1 -6
	yyvs1.put (yyval1, yyvsp1)
end
when 233 then
--|#line 575 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 575")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 234 then
--|#line 576 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 576")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 235 then
--|#line 579 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 579")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 236 then
--|#line 580 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 580")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 237 then
--|#line 581 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 581")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 238 then
--|#line 586 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 586")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 239 then
--|#line 589 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 589")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 240 then
--|#line 590 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 590")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 241 then
--|#line 591 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 591")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 242 then
--|#line 594 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 594")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 243 then
--|#line 595 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 595")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 244 then
--|#line 596 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 596")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 245 then
--|#line 599 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 599")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 246 then
--|#line 600 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 600")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 247 then
--|#line 603 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 603")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 248 then
--|#line 604 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 604")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 249 then
--|#line 607 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 607")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 250 then
--|#line 613 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 613")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 9
	yyvsp1 := yyvsp1 -8
	yyvs1.put (yyval1, yyvsp1)
end
when 251 then
--|#line 617 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 617")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 252 then
--|#line 618 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 618")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 253 then
--|#line 619 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 619")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 254 then
--|#line 620 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 620")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 255 then
--|#line 625 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 625")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 256 then
--|#line 628 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 628")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 257 then
--|#line 629 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 629")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 258 then
--|#line 632 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 632")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 259 then
--|#line 633 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 633")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 260 then
--|#line 634 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 634")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 261 then
--|#line 639 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 639")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 262 then
--|#line 644 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 644")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 263 then
--|#line 645 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 645")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 264 then
--|#line 646 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 646")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 265 then
--|#line 647 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 647")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 266 then
--|#line 648 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 648")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 267 then
--|#line 649 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 649")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 268 then
--|#line 652 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 652")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 269 then
--|#line 653 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 653")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 7
	yyvsp1 := yyvsp1 -6
	yyvs1.put (yyval1, yyvsp1)
end
when 270 then
--|#line 655 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 655")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 5
	yyvsp1 := yyvsp1 -4
	yyvs1.put (yyval1, yyvsp1)
end
when 271 then
--|#line 656 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 656")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 7
	yyvsp1 := yyvsp1 -6
	yyvs1.put (yyval1, yyvsp1)
end
when 272 then
--|#line 665 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 665")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 273 then
--|#line 666 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 666")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 274 then
--|#line 671 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 671")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 275 then
--|#line 672 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 672")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 276 then
--|#line 675 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 675")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 277 then
--|#line 676 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 676")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 278 then
--|#line 677 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 677")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 279 then
--|#line 680 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 680")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 280 then
--|#line 681 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 681")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 281 then
--|#line 684 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 684")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 282 then
--|#line 685 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 685")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 283 then
--|#line 686 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 686")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 284 then
--|#line 690 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 690")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 285 then
--|#line 693 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 693")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 286 then
--|#line 694 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 694")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 287 then
--|#line 699 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 699")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 288 then
--|#line 700 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 700")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 289 then
--|#line 701 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 701")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 290 then
--|#line 702 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 702")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 291 then
--|#line 703 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 703")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 292 then
--|#line 704 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 704")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 293 then
--|#line 705 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 705")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 294 then
--|#line 706 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 706")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 295 then
--|#line 707 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 707")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 296 then
--|#line 708 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 708")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 297 then
--|#line 709 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 709")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 298 then
--|#line 710 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 710")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 299 then
--|#line 711 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 711")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 300 then
--|#line 712 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 712")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 301 then
--|#line 713 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 713")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 302 then
--|#line 714 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 714")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 303 then
--|#line 715 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 715")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 304 then
--|#line 716 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 716")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 305 then
--|#line 717 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 717")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 306 then
--|#line 718 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 718")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 307 then
--|#line 719 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 719")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 308 then
--|#line 720 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 720")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 309 then
--|#line 721 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 721")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 310 then
--|#line 722 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 722")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 311 then
--|#line 723 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 723")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 312 then
--|#line 724 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 724")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 313 then
--|#line 725 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 725")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 314 then
--|#line 726 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 726")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 315 then
--|#line 727 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 727")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 316 then
--|#line 728 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 728")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 317 then
--|#line 729 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 729")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 318 then
--|#line 730 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 730")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 319 then
--|#line 731 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 731")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 320 then
--|#line 732 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 732")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 321 then
--|#line 733 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 733")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 322 then
--|#line 734 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 734")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 323 then
--|#line 735 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 735")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 324 then
--|#line 737 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 737")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 325 then
--|#line 738 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 738")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 326 then
--|#line 739 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 739")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 327 then
--|#line 746 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 746")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 328 then
--|#line 747 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 747")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 329 then
--|#line 748 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 748")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 330 then
--|#line 749 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 749")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 331 then
--|#line 750 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 750")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 4
	yyvsp1 := yyvsp1 -3
	yyvs1.put (yyval1, yyvsp1)
end
when 332 then
--|#line 751 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 751")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 333 then
--|#line 752 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 752")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 334 then
--|#line 755 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 755")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 335 then
--|#line 758 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 758")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 336 then
--|#line 759 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 759")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 337 then
--|#line 762 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 762")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 338 then
--|#line 763 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 763")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 339 then
--|#line 764 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 764")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 340 then
--|#line 767 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 767")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 341 then
--|#line 768 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 768")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 342 then
--|#line 769 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 769")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 343 then
--|#line 774 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 774")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 344 then
--|#line 775 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 775")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 345 then
--|#line 776 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 776")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 346 then
--|#line 779 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 779")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 0
	yyvsp1 := yyvsp1 + 1
	if yyvsp1 >= yyvsc1 then
		if yyvs1 = Void then
			debug ("GEYACC")
				std.error.put_line ("Create yyvs1")
			end
			create yyspecial_routines1
			yyvsc1 := yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.make (yyvsc1)
		else
			debug ("GEYACC")
				std.error.put_line ("Resize yyvs1")
			end
			yyvsc1 := yyvsc1 + yyInitial_yyvs_size
			yyvs1 := yyspecial_routines1.resize (yyvs1, yyvsc1)
		end
	end
	yyvs1.put (yyval1, yyvsp1)
end
when 347 then
--|#line 780 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 780")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 348 then
--|#line 781 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 781")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 3
	yyvsp1 := yyvsp1 -2
	yyvs1.put (yyval1, yyvsp1)
end
when 349 then
--|#line 784 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 784")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 350 then
--|#line 785 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 785")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 351 then
--|#line 786 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 786")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 352 then
--|#line 787 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 787")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 353 then
--|#line 788 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 788")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 354 then
--|#line 789 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 789")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 355 then
--|#line 792 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 792")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 356 then
--|#line 793 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 793")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 357 then
--|#line 796 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 796")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 358 then
--|#line 797 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 797")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 359 then
--|#line 798 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 798")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 360 then
--|#line 801 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 801")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 361 then
--|#line 802 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 802")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 362 then
--|#line 803 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 803")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 2
	yyvsp1 := yyvsp1 -1
	yyvs1.put (yyval1, yyvsp1)
end
when 363 then
--|#line 806 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 806")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
when 364 then
--|#line 807 "eiffel_parser.y"
debug ("GEYACC")
	std.error.put_line ("Executing parser user-code from file 'eiffel_parser.y' at line 807")
end


if yy_parsing_status = yyContinue then
	yyssp := yyssp - 1
	yyvs1.put (yyval1, yyvsp1)
end
			else
				debug ("GEYACC")
					std.error.put_string ("Error in parser: unknown rule id: ")
					std.error.put_integer (yy_act)
					std.error.put_new_line
				end
				abort
			end
		end

	yy_do_error_action (yy_act: INTEGER) is
			-- Execute error action.
		do
			inspect yy_act
			when 574 then
					-- End-of-file expected action.
				report_eof_expected_error
			else
					-- Default action.
				report_error ("parse error")
			end
		end

feature {NONE} -- Table templates

	yytranslate_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			    0,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,  123,    2,    2,  125,    2,    2,    2,
			  121,  122,  106,  104,  116,  105,  124,  107,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,  115,  114,
			  100,   98,  101,  126,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,  117,    2,  118,  110,    2,    2,    2,    2,    2,

			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,  119,    2,  120,  127,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,

			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
			    2,    2,    2,    2,    2,    2,    1,    2,    3,    4,
			    5,    6,    7,    8,    9,   10,   11,   12,   13,   14,
			   15,   16,   17,   18,   19,   20,   21,   22,   23,   24,
			   25,   26,   27,   28,   29,   30,   31,   32,   33,   34,
			   35,   36,   37,   38,   39,   40,   41,   42,   43,   44,

			   45,   46,   47,   48,   49,   50,   51,   52,   53,   54,
			   55,   56,   57,   58,   59,   60,   61,   62,   63,   64,
			   65,   66,   67,   68,   69,   70,   71,   72,   73,   74,
			   75,   76,   77,   78,   79,   80,   81,   82,   83,   84,
			   85,   86,   87,   88,   89,   90,   91,   92,   93,   94,
			   95,   96,   97,   99,  102,  103,  108,  109,  111,  112,
			  113, yyDummy>>)
		end

	yyr1_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			    0,  128,  128,  129,  129,  138,  130,  130,  139,  139,
			  139,  140,  140,  140,  140,  142,  142,  143,  143,  145,
			  145,  141,  141,  131,  147,  147,  147,  147,  132,  132,
			  148,  148,  148,  149,  149,  149,  151,  133,  133,  137,
			  153,  153,  153,  153,  153,  153,  154,  154,  154,  154,
			  154,  155,  155,  156,  156,  156,  156,  156,  157,  158,
			  159,  160,  161,  162,  162,  171,  171,  167,  163,  163,
			  173,  173,  173,  174,  174,  174,  175,  177,  177,  178,
			  178,  178,  176,  180,  180,  179,  179,  179,  169,  165,
			  165,  168,  164,  164,  170,  166,  166,  134,  134,  181,

			  181,  182,  182,  152,  152,  152,  135,  135,  183,  183,
			  184,  185,  185,  185,  186,  186,  186,  187,  189,  192,
			  192,  193,  193,  193,  188,  188,  195,  195,  172,  172,
			  172,  196,  196,  196,  196,  197,  197,  197,  197,  197,
			  197,  197,  197,  197,  197,  197,  197,  197,  197,  197,
			  197,  197,  197,  190,  190,  198,  198,  198,  199,  199,
			  199,  200,  201,  201,  191,  191,  194,  205,  205,  205,
			  205,  209,  209,  204,  204,  203,  203,  203,  206,  206,
			  206,  136,  136,  210,  210,  210,  211,  211,  211,  212,
			  212,  207,  207,  202,  202,  202,  202,  202,  202,  202,

			  150,  215,  216,  216,  217,  217,  217,  208,  208,  218,
			  218,  219,  219,  219,  219,  219,  219,  219,  219,  219,
			  219,  219,  220,  220,  230,  230,  228,  228,  232,  222,
			  233,  233,  223,  235,  235,  234,  234,  234,  224,  236,
			  236,  236,  237,  237,  237,  238,  238,  239,  239,  239,
			  225,  240,  240,  240,  240,  226,  241,  241,  242,  242,
			  242,  227,  221,  221,  221,  221,  221,  221,  221,  221,
			  221,  221,  243,  243,  231,  231,  244,  244,  244,  245,
			  245,  246,  246,  246,  246,  229,  229,  213,  213,  213,
			  213,  213,  213,  213,  213,  213,  213,  213,  213,  213,

			  213,  213,  213,  213,  213,  213,  213,  213,  213,  213,
			  213,  213,  213,  213,  213,  213,  213,  213,  213,  213,
			  213,  213,  213,  213,  213,  213,  213,  250,  250,  250,
			  250,  250,  250,  250,  251,  252,  252,  253,  253,  253,
			  254,  254,  254,  249,  249,  249,  248,  248,  248,  146,
			  146,  146,  146,  146,  146,  247,  247,  214,  214,  214,
			  255,  255,  255,  144,  144, yyDummy>>)
		end

	yytypes1_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1, yyDummy>>)
		end

	yytypes2_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
			    1,    1,    1,    1,    1,    1,    1,    1, yyDummy>>)
		end

	yydefact_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			    1,    6,    8,    2,   24,    0,    0,  355,  356,  364,
			  354,  353,  363,  360,  357,  350,    7,    9,   11,   15,
			   19,   17,   20,  351,  349,  352,   27,   26,   25,   28,
			    0,  361,  358,  362,  359,   21,   10,   12,    0,    0,
			   30,   37,    0,   21,    0,   13,   22,   19,   18,   16,
			   33,    0,    0,   97,   23,   14,    0,   31,   29,    0,
			   38,   83,   97,   83,  106,    4,   98,   99,  201,   34,
			  202,   33,   85,   84,  103,  106,    0,   46,   39,   51,
			  103,   83,  181,  107,  108,  100,  103,   35,  204,  200,
			   32,   86,    0,  104,  102,  181,   40,   79,   79,   64,

			   79,   70,   97,   97,   52,   53,   54,   55,   56,   57,
			   68,   92,   89,   95,    0,  101,  111,  183,    0,  109,
			    0,    0,    0,    0,    0,  193,  205,    0,   82,    0,
			    0,    5,    0,    0,  128,   80,   91,   94,   63,    0,
			   88,   67,   71,   73,   79,   97,    0,   49,   97,    0,
			   47,   92,   69,   89,   93,   95,   90,    0,   96,   62,
			    0,  126,  110,  112,  114,  153,  124,    0,    0,    0,
			    0,  346,    0,    0,    0,    0,    0,    0,  274,  288,
			  289,    0,  346,  296,  295,  294,  293,  292,  274,  182,
			  184,  186,  189,  287,  324,  262,  291,  325,  333,    3,

			   36,  195,  196,  197,  194,    0,    0,  199,  198,  203,
			    0,   87,  105,  131,  134,  133,  132,  129,  152,  150,
			  149,  147,  151,  148,  146,  145,  144,  143,  142,  141,
			  140,  139,  138,  137,  136,  135,  130,    0,    0,    0,
			   72,   74,   78,   76,   77,    0,   50,   42,    0,   48,
			   41,   89,   95,    0,   61,  127,  113,  115,  155,    0,
			  117,  164,  335,  332,  274,    0,    0,  347,    0,  322,
			  300,  301,  299,  298,    0,  276,    0,  266,    0,  329,
			    0,  328,  343,    0,  190,  272,  327,  185,  187,    0,
			    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,

			    0,    0,    0,    0,    0,    0,    0,    0,  206,   81,
			    0,   65,   75,   45,   44,   95,    0,   60,  116,  162,
			    0,  156,  158,    0,  125,    0,  119,  337,  334,  290,
			    0,  326,    0,    0,    0,  279,    0,  277,    0,    0,
			  274,  263,  264,  344,    0,  297,  188,  302,  307,  309,
			  308,  306,  305,  304,  303,  315,  314,  313,  312,  311,
			  310,    0,  316,  318,    0,  317,  321,  274,    0,    0,
			   59,  154,  157,  159,    0,    0,  165,   37,  118,  342,
			    0,  340,    0,  338,    0,  330,  274,  331,  348,  224,
			    0,  283,  282,  281,  280,  275,    0,  274,  267,  323,

			    0,  319,  320,  273,   66,   58,  160,  163,  161,  122,
			  175,  121,  120,  123,    0,  336,    0,  265,  268,    0,
			  228,    0,  278,  270,  345,  183,  173,  341,  339,    0,
			  274,  284,    0,  183,  176,  155,    0,  269,  225,  271,
			  177,  174,  207,    0,  207,  167,  178,    0,    0,    0,
			  220,    0,  286,    0,  219,    0,    0,  207,  256,  183,
			    0,  285,  169,  208,  209,  211,  212,  213,  214,  215,
			  216,  217,  218,  221,    0,  171,  168,  183,  191,    0,
			    0,    0,    0,  286,  285,  224,  239,    0,  181,  258,
			  207,    0,  224,  210,  231,  230,    0,    0,  170,  183,

			  179,  207,    0,    0,    0,    0,    0,  227,  242,  233,
			  207,  251,  259,    0,    0,  261,  223,  229,  172,  180,
			  192,  166,  224,    0,    0,  248,  247,  249,    0,  243,
			  245,  242,  207,    0,  235,  252,    0,  257,    0,  255,
			  222,  224,    0,  207,    0,    0,  234,  238,    0,  233,
			  274,  253,    0,  260,  226,  244,  240,  246,  207,    0,
			    0,    0,    0,    0,  241,  207,    0,  232,  254,  207,
			  236,  207,    0,  237,  250,    0,    0, yyDummy>>)
		end

	yydefgoto_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			    1,    3,    4,   29,   41,   53,   75,   82,  118,   65,
			   76,   16,   17,   36,   18,   19,  264,   21,   22,   30,
			   51,   57,  125,   87,   94,   78,   79,  103,  104,  105,
			  106,  107,  108,  109,  110,  151,  153,  155,  157,  111,
			  154,  156,  158,  138,  135,  141,  142,  143,   73,  243,
			  136,   92,   74,   66,   67,   83,   84,  162,  163,  164,
			  165,  260,  261,  326,  378,  412,  413,  166,  217,  236,
			  320,  321,  322,  323,  126,  426,  436,  446,  478,  502,
			  462,  498,  189,  190,  191,  192,   23,   70,   89,  127,
			  463,  464,  465,  193,  467,  468,  469,  470,  471,  472,

			  473,  474,  420,  285,  194,  496,  549,  533,  509,  528,
			  529,  530,  536,  490,  513,  195,  336,  381,  394,  196,
			  268,  344,  197,  198,  328,  382,  383,   25, yyDummy>>)
		end

	yypact_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			 -32768,   65,  461, -32768,  225,  370,  358, -32768, -32768, -32768,
			 -32768, -32768, -32768, -32768, -32768, -32768, -32768,  887, -32768,  376,
			  392, -32768, -32768, -32768, -32768, -32768, -32768, -32768, -32768,  388,
			  482, -32768, -32768, -32768, -32768,  476,  386, -32768,  461,  461,
			  123,  448,  123, -32768,  306, -32768, -32768, -32768, -32768,  376,
			  475,  238,  484,  179, -32768, -32768,  457, -32768, -32768,  123,
			 -32768,  319,   26,  319,  440, -32768,   36, -32768, -32768,  419,
			  372,  475,  123, -32768,  123,  440,  450, -32768, -32768,  318,
			  123,  319,  308,  440, -32768, -32768,  123, -32768,  174, -32768,
			 -32768, -32768,   90, -32768,  355,  308, -32768,  268,  268,  268,

			  268,  319,  321,   68, -32768, -32768, -32768, -32768, -32768, -32768,
			  446,  394,  379,  361,  445,  355,  222, 1001,  444, -32768,
			   -9,  457,  147,  457,   45, -32768, -32768,  218, -32768,  123,
			  123, -32768,  175, 1322, -32768, -32768,  320,  320,  346,  441,
			  320, -32768,   76, -32768,  199,   26,  431, -32768,   26,  428,
			 -32768,  394, -32768,  379, -32768,  361, -32768,  413, -32768, -32768,
			  268, -32768, -32768,    7, -32768,  -54, -32768,  268,  267, 1001,
			  174, 1001, 1001, 1001, 1001, 1001, 1001,  325,  212,  155,
			  138,  322, 1001, -32768, -32768, -32768, -32768, -32768,  201, -32768,
			  918, -32768, 1285, -32768, -32768,  257, -32768, -32768, -32768, -32768,

			 -32768, -32768, -32768, -32768, -32768,  435,  433, -32768, -32768, -32768,
			  174, -32768, -32768, -32768, -32768, -32768, -32768, -32768, -32768, -32768,
			 -32768, -32768, -32768, -32768, -32768, -32768, -32768, -32768, -32768, -32768,
			 -32768, -32768, -32768, -32768, -32768, -32768, -32768,  268,  268,  268,
			  319, -32768, -32768, -32768,  320,  406, -32768, -32768,  404, -32768,
			 -32768,  379,  361,  400, -32768, -32768,  222, -32768,  123,  222,
			 -32768,  310,  305, -32768,  143, 1256,  304, 1285,  207, -32768,
			 -32768, -32768, -32768, -32768,  174,  720,  174,  298,  123, -32768,
			  123, -32768,  123,   -4, -32768, -32768, -32768, 1001, -32768, 1001,
			 1001, 1001, 1001, 1001, 1001, 1001, 1001, 1001, 1001, 1001,

			 1001, 1001, 1001,  876, 1001,  845, 1001,  123, -32768, -32768,
			  399, -32768, -32768, -32768, -32768,  361,  387, -32768, -32768, -32768,
			  290,   11, -32768,  168, -32768,  174,  371,  701, -32768,  118,
			  -14, -32768, 1001,  289,   22, 1285,  144, -32768,  287,  123,
			  265,  257,  257, -32768,  111, -32768, -32768, -32768,  -19,  -19,
			  -19,  -19,  -19,  416,  416,  295,  295,  295,  295,  295,
			  295, 1001, 1334,  692, 1001,  692, 1320,  265,  268,  369,
			 -32768, -32768,  123, -32768,  123,  174, -32768,  443, -32768,  267,
			  174, -32768,    2, -32768,  123, -32768,  265, -32768, 1285,  -49,
			 1001, -32768, -32768, -32768, -32768, -32768,  720,  265,  257, -32768,

			  123, 1334,  692, -32768, -32768, -32768, -32768, -32768, -32768, -32768,
			  340, -32768, -32768, -32768,  271, -32768,  701,  257,  266,  123,
			 -32768, 1227, -32768,  264, -32768,  635,  339,  -14, -32768,  123,
			  265, -32768,  123, 1001, -32768,  123,  323,  257, -32768,  257,
			 -32768, -32768,  959,  373,  959, -32768,  350,  174, 1001,  174,
			 -32768,   15,   62,  252, -32768, 1001, 1001,  959,  246, 1001,
			   80, 1115, -32768,  959, -32768, -32768, -32768, -32768, -32768, -32768,
			 -32768, -32768, -32768, -32768,  237,  343, -32768,  569,  311,  234,
			 1198,  233,  174, -32768, -32768,  -49, 1180, 1162,  308,  337,
			  959,  312,  -49, -32768, -32768, -32768, 1001,  331, -32768, 1001,

			 -32768,  959,  307,   80,  180,  263,  112, -32768,   73,   29,
			  959,  140, -32768,  -17,  196, -32768, -32768, 1285, -32768, -32768,
			 -32768, -32768,  -49,   80,   62, -32768, -32768, -32768,  -31, -32768,
			  150,   73,  959,  124,  114, 1001,   57, -32768,   95, -32768,
			 -32768,  -49,   73,  959,   73,  -36, -32768, -32768, 1001,  187,
			  148, 1285, 1001, -32768, -32768, -32768, -32768, -32768,  959, 1108,
			 1001,   38, 1001,  990, -32768,  959, 1090, -32768, 1285,  959,
			 -32768,  959,   24, -32768, -32768,   35, -32768, yyDummy>>)
		end

	yypgoto_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			 -32768, -32768, -32768, -32768, -32768,  183,  505,  479,  -93, -32768,
			   96, -32768, -32768,  517,  176,  514,   -2,  513,  173, -32768,
			 -32768,  472,  568, -32768,  240, -32768, -32768, -32768, -32768, -32768,
			 -32768, -32768, -32768, -32768, -32768, -32768,  395, -114, -151,  426,
			  460,  459,  458, -32768,  -16, -32768, -32768, -124,  -95, -32768,
			  102, -32768,  128, -32768,  465, -32768,  451, -32768, -32768, -133,
			 -32768, -32768, -32768, -32768, -32768, -32768, -32768,  269, -32768, -32768,
			   84, -32768, -309, -32768, -141, -32768, -32768, -32768, -32768, -32768,
			 -384, -32768, -270, -32768, -179,   -3, -123, -32768, -32768, -32768,
			 -32768,   55, -32768,   54, -32768, -32768, -32768, -32768, -32768, -32768,

			 -32768, -392, -325, -171, -32768, -32768, -32768,  -34, -32768,  -15,
			  -29,  -30, -32768, -32768, -32768, -275, -32768, -266, -32768,    6,
			  330, -32768, -32768, -154, -32768, -32768,   94, -32768, yyDummy>>)
		end

	yytable_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			   20,  208,  131,  341,  253,  342,  144,  277,   24,  337,
			  345,  288,  373,   12,  263,   20,    9,   12,  241,  200,
			    9,   12,  558,   24,    9,  279,  281,  543,   12,  266,
			  257,    9,   68,   20,  286,  576,   47,   47,   50,  252,
			   54,   24,   20,  160,   24,   24,  133,  144,   63,   14,
			   24,   12,  574,  386,    9,  532,  132,   71,   63,  485,
			  476,  133,  259,  406,  398,  575,  567,  258,  492,  308,
			   91,  132,   93,  488,   68,  419,  525,   14,   93,   12,
			  542,  483,    9,  139,   93,  542,   12,  392,  391,    9,
			   63,  290,  289,  531,   61,  134,  134,  134,  134,  538,

			  161,  316,  553,    2,   61,  537,  514,  130,  346,  417,
			  286,  522,  332,  167,  134,  188,  312,  520,  416,  552,
			  203,  256,  207,  318,  415,  372,  534,  211,  212,   12,
			  422,  541,    9,  333,  482,  338,   61,  315,  453,  524,
			  178,  548,  134,  390,  255,  144,  483,  161,  546,  206,
			  205,  262,  547,   12,  437,  434,    9,  439,  134,  556,
			  507,  134,  544,  440,  369,  134,  265,  516,  267,  269,
			  270,  271,  272,  273,  564,  385,  387,  206,  205,  267,
			   68,  570,  148,  124,  376,  572,  278,  573,  188,  491,
			  240,   80,  449,   37,  448,   72,  403,  540,  146,  149,

			  137,   63,  140,  535,  123,   12,  129,  500,    9,  116,
			  128,   45,  202,  532,  560,  418,  554,  242,  122,   62,
			   55,  309,  310,  311,  539,  263,  423,  400,   12,  519,
			  121,    9,  523,  399,  408,  134,  134,  134,  133,  414,
			  161,  245,  384,  161,  248,  167,  244,   61,  132,   28,
			  216,  215,  495,  494,  134,   27,  319,  134,  160,  438,
			  396,  133,  280,  562,  275,  167,  395,  214,  213,  275,
			  167,  132,  335,  387,   12,  167,  340,    9,  340,  278,
			  343,   26,  167,  375,  374,  188,  347,  348,  349,  350,
			  351,  352,  353,  354,  355,  356,  357,  358,  359,  360,

			  362,  363,  365,  366,  384,  367,  479,  133,  481,   15,
			   14,   13,   12,   11,   10,    9,  284,  132,  393,  319,
			  115,  -43,  275,  332,  335,  331,  120,   68,  167,  388,
			  386,  276,  134,  275,  210,  521,  209,  340,  518,    8,
			  515,  506,  -43,   63,  512,  -43,  102,  445,  444,  101,
			  117,  -43,  404,  505,   59,  443,   58,  503,  401,  -43,
			  497,  402,   34,   33,  501,    7,  134,  489,  100,   99,
			  319,  442,  407,   98,   32,   31,  280,  -43,   97,  477,
			  475,  307,  340,   24,  435,  526,  275,  421,  432,   61,
			  429,  427,  425,  335,  167,  511,  286,  405,  424,  296,

			  295,  294,  293,  292,  291,  290,  289,  397,  526,  389,
			    6,    5,  371,  335,  377,  370,   98,  430,  368,  526,
			   46,  526,  339,  188,  330,  325,  327,  340,  317,  100,
			  340,  188,  314,  319,  313,  145,  237,   34,   72,   32,
			  461,  254,  461,  282,  274,  480,   15,   14,   13,  484,
			   11,   10,  486,  487,   97,  461,  250,  188,  484,  247,
			  239,  461,  238,   68,   15,   14,   13,   12,   11,   10,
			    9,  130,  199,  159,   81,  188,    8,  101,   96,   15,
			   14,   13,   12,   11,   10,    9,   56,   86,  461,   88,
			   52,   60,   38,  517,    8,   52,  466,  188,  466,  461,

			   46,  484,    7,   42,  409,   40,  340,   39,  461,    8,
			  428,  466,  283,  555,  557,  561,  545,  466,  493,  441,
			    7,  484,  294,  293,  292,  291,  290,  289,  324,  340,
			  461,   85,  551,  550,  119,    7,  152,  114,  113,  112,
			  340,  461,  340,   90,  466,  559,  251,    6,    5,  563,
			  411,   48,   44,   49,   95,  466,  461,  566,   64,  568,
			  410,    0,  527,  461,  466,    6,    5,  461,    0,  461,
			    0,    0,  187,  186,  185,   12,  184,  183,    9,    0,
			    6,    5,  182,    0,    0,  527,  466,    0,    0,    0,
			   43,    0,    0,    0,    0,    0,  527,  466,  527,    0,

			    0,    0,    8,    0,    0,    0,    0,    0,    0,    0,
			    0,    0,  466,    0,    0,    0,    0,    0,    0,  466,
			    0,    0,    0,  466,   69,  466,  181,  499,    7,    0,
			   77,    0,    0,    0,  180,  179,  178,  177,  187,  186,
			  185,   12,  184,  183,    9,    0,    0,    0,  182,    0,
			    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
			    0,  433,    0,    0,    0,    0,    0,    0,    8,    0,
			  147,  150,    0,  176,  175,    0,    0,    0,    0,    0,
			  174,  173,  172,    0,    0,    0,  171,    0,  170,  201,
			  169,  204,  181,    0,    7,  168,  167,    0,    0,    0,

			  180,  179,  178,  177,  187,  186,  185,   12,  184,  183,
			    9,    0,    0,  246,  182,    0,  249,    0,    0,    0,
			    0,    0,    0,  187,  186,  185,   12,  184,  183,    9,
			    0,    0,    0,  182,    8,    0,    0,    0,    0,  176,
			  175,    0,    0,    0,    0,    0,  174,  173,  172,    0,
			    0,    0,  171,    8,  170,    0,  169,    0,  181,    0,
			    7,  168,  167,    0,    0,    0,  180,  179,  178,  177,
			    0,    0,    0,    0,    0,    0,    0,  181,    0,    7,
			    0,    0,    0,    0,    0,  180,  179,  178,  177,  303,
			  302,  301,  300,  299,  298,  297,  296,  295,  294,  293,

			  292,  291,  290,  289,    0,  176,  175,    0,    0,    0,
			    0,    0,  174,  173,  172,    0,    0,    0,  171,    0,
			  380,    0,  169,    0,  176,  175,  334,  379,  167,    0,
			    0,  174,  173,  172,    0,    0,    0,  171,    0,  170,
			    0,  169,    0,    0,    0,  334,  168,  167,  187,  186,
			  185,   12,  184,  183,    9,    0,    0,    0,  182,    0,
			    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
			    0,  364,    0,    0,    0,    0,    0,    0,    8,  187,
			  186,  185,   12,  184,  183,    9,    0,    0,    0,  182,
			   15,   14,   13,   12,   11,   10,    9,    0,    0,    0,

			    0,    0,  181,    0,    7,    0,    0,    0,    0,    8,
			  180,  179,  178,  177,    0,    0,    0,    0,    0,    0,
			    8,  187,  186,  185,   12,  184,  183,    9,    0,    0,
			    0,  182,    0,  181,  361,    7,    0,    0,    0,    0,
			    0,  180,  179,  178,  177,    0,    7,    0,    0,  176,
			  175,    8,    0,    0,    0,    0,  174,  173,  172,    0,
			    0,    0,  171,    0,  170,   12,  169,    0,    9,  460,
			    0,  168,  167,    0,    0,  181,    0,    7,    0,  459,
			  176,  175,  458,  180,  179,  178,  177,  174,  173,  172,
			    0,    6,    5,  171,  457,  170,  456,  169,    0,    0,

			  455,   35,  168,  167,  187,  186,  185,   12,  184,  183,
			    9,    0,    0,  454,  182,    0,    0,    0,    0,    0,
			    0,    0,  176,  175,  453,  452,  178,  451,    0,  174,
			  173,  172,  287,    0,    8,  171,  569,  170,    0,  169,
			    0,    0,    0,    0,  168,  167,    0,    0,    0,    0,
			    0,    0,    0,    0,    0,    0,    0,    0,  181,    0,
			    7,    0,    0,    0,    0,    0,  180,  179,  178,  177,
			    0,    0,    0,  450,    0,    0,    0,    0,  449,    0,
			  448,    0,  447,    0,  306,  305,  304,  303,  302,  301,
			  300,  299,  298,  297,  296,  295,  294,  293,  292,  291,

			  290,  289,    0,    0,    0,  176,  175,    0,    0,    0,
			    0,    0,  174,  173,  172,    0,    0,    0,  171,    0,
			  170, -274,  169,    0, -274, -274,    0,  168,  167,    0,
			    0,    0,    0,    0,    0, -274,    0,    0, -274,    0,
			    0, -274, -274, -274, -274,    0,    0,    0,  571,    0,
			 -274,    0, -274,    0,    0,    0, -274, -274,    0,    0,
			    0,    0,    0,    0,    0,    0,  565,    0, -274, -274,
			    0,    0,    0,    0,    0,    0,    0, -274, -274, -274,
			 -274, -274, -274, -274,  306,  305,  304,  303,  302,  301,
			  300,  299,  298,  297,  296,  295,  294,  293,  292,  291,

			  290,  289,  306,  305,  304,  303,  302,  301,  300,  299,
			  298,  297,  296,  295,  294,  293,  292,  291,  290,  289,
			  510,    0,    0,    0,    0,    0,    0,    0,    0, -274,
			    0,    0,    0,    0, -274,    0,  275,    0, -274, -274,
			    0,    0,    0,    0,  508,    0,    0,    0,    0,    0,
			    0,    0,    0,    0,    0,    0,  306,  305,  304,  303,
			  302,  301,  300,  299,  298,  297,  296,  295,  294,  293,
			  292,  291,  290,  289,  306,  305,  304,  303,  302,  301,
			  300,  299,  298,  297,  296,  295,  294,  293,  292,  291,
			  290,  289,  306,  305,  304,  303,  302,  301,  300,  299,

			  298,  297,  296,  295,  294,  293,  292,  291,  290,  289,
			    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
			  504,  306,  305,  304,  303,  302,  301,  300,  299,  298,
			  297,  296,  295,  294,  293,  292,  291,  290,  289,    0,
			    0,    0,    0,    0,    0,    0,    0,    0,    0,  431,
			  306,  305,  304,  303,  302,  301,  300,  299,  298,  297,
			  296,  295,  294,  293,  292,  291,  290,  289,    0,    0,
			    0,    0,    0,    0,    0,    0,    0,    0,  329,  306,
			  305,  304,  303,  302,  301,  300,  299,  298,  297,  296,
			  295,  294,  293,  292,  291,  290,  289,  235,  234,  233,

			  232,  231,  230,  229,  228,  227,  226,  225,  224,  223,
			  222,  221,  220,  219,  218,  305,  304,  303,  302,  301,
			  300,  299,  298,  297,  296,  295,  294,  293,  292,  291,
			  290,  289,  302,  301,  300,  299,  298,  297,  296,  295,
			  294,  293,  292,  291,  290,  289, yyDummy>>)
		end

	yycheck_template: SPECIAL [INTEGER] is
		once
			Result := yyfixed_array (<<
			    2,  124,   95,  278,  155,  280,  101,  178,    2,  275,
			   14,  190,  321,    6,  168,   17,    9,    6,  142,   28,
			    9,    6,   58,   17,    9,  179,  180,   58,    6,  170,
			  163,    9,    6,   35,  188,    0,   38,   39,   40,  153,
			   42,   35,   44,   36,   38,   39,   39,  142,   22,    4,
			   44,    6,   28,   67,    9,   26,   49,   59,   22,  451,
			  444,   39,  116,  372,  339,    0,   28,  121,  460,  210,
			   72,   49,   74,  457,    6,  124,    3,    4,   80,    6,
			  116,   66,    9,   99,   86,  116,    6,   65,   66,    9,
			   22,  110,  111,   64,   68,   97,   98,   99,  100,  116,

			  116,  252,    7,   38,   68,  122,  490,  116,  287,  384,
			  264,  503,  116,  127,  116,  117,  240,  501,  116,   62,
			  122,  114,  124,  256,  122,  114,  510,  129,  130,    6,
			  396,  523,    9,  274,  119,  276,   68,  251,   65,   66,
			   67,   27,  144,  121,  160,  240,   66,  163,  532,  104,
			  105,  167,   28,    6,  429,  425,    9,  432,  160,  543,
			  485,  163,   12,  433,  315,  167,  169,  492,  171,  172,
			  173,  174,  175,  176,  558,  329,  330,  104,  105,  182,
			    6,  565,  114,    9,  325,  569,  124,  571,  190,  459,
			  114,   63,  119,   17,  121,  119,  367,  522,  102,  103,

			   98,   22,  100,   63,   30,    6,  116,  477,    9,   81,
			  120,   35,   65,   26,   27,  386,  541,   18,   44,   40,
			   44,  237,  238,  239,   28,  379,  397,  116,    6,  499,
			   56,    9,  120,  122,  375,  237,  238,  239,   39,  380,
			  256,  145,  124,  259,  148,  127,  144,   68,   49,   24,
			   75,   76,   15,   16,  256,   30,  258,  259,   36,  430,
			  116,   39,  124,  115,  121,  127,  122,   92,   93,  121,
			  127,   49,  275,  427,    6,  127,  278,    9,  280,  124,
			  282,   56,  127,  115,  116,  287,  289,  290,  291,  292,
			  293,  294,  295,  296,  297,  298,  299,  300,  301,  302,

			  303,  304,  305,  306,  124,  307,  447,   39,  449,    3,
			    4,    5,    6,    7,    8,    9,  115,   49,  334,  321,
			   80,    0,  121,  116,  327,  118,   86,    6,  127,  332,
			   67,  119,  334,  121,  116,   28,  118,  339,    7,   33,
			   28,  482,   21,   22,    7,   24,   28,   24,   25,   31,
			   42,   30,  368,  120,  116,   32,  118,  123,  361,   38,
			   17,  364,    4,    5,   53,   59,  368,  121,   50,   51,
			  372,   48,  374,   55,    4,    5,  124,   56,   60,   29,
			    7,  124,  384,  377,   45,  508,  121,  390,  124,   68,
			  124,  120,   52,  396,  127,  488,  550,   28,  400,  104,

			  105,  106,  107,  108,  109,  110,  111,  120,  531,  120,
			  104,  105,  122,  416,   43,   28,   55,  419,   19,  542,
			  114,  544,  124,  425,  120,  115,  121,  429,   28,   50,
			  432,  433,   28,  435,   28,  114,  116,    4,  119,    4,
			  442,   28,  444,  121,  119,  448,    3,    4,    5,  451,
			    7,    8,  455,  456,   60,  457,   28,  459,  460,   28,
			   19,  463,  116,    6,    3,    4,    5,    6,    7,    8,
			    9,  116,   28,   28,   34,  477,   33,   31,   28,    3,
			    4,    5,    6,    7,    8,    9,   11,   68,  490,  117,
			   47,    7,  116,  496,   33,   47,  442,  499,  444,  501,

			  114,  503,   59,   21,   61,  117,  508,  115,  510,   33,
			  416,  457,  182,  542,  544,  549,  531,  463,  463,  435,
			   59,  523,  106,  107,  108,  109,  110,  111,  259,  531,
			  532,   66,  535,  535,   83,   59,  110,   79,   79,   79,
			  542,  543,  544,   71,  490,  548,  151,  104,  105,  552,
			  377,   38,   35,   39,   75,  501,  558,  560,   53,  562,
			  377,   -1,  508,  565,  510,  104,  105,  569,   -1,  571,
			   -1,   -1,    3,    4,    5,    6,    7,    8,    9,   -1,
			  104,  105,   13,   -1,   -1,  531,  532,   -1,   -1,   -1,
			  114,   -1,   -1,   -1,   -1,   -1,  542,  543,  544,   -1,

			   -1,   -1,   33,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
			   -1,   -1,  558,   -1,   -1,   -1,   -1,   -1,   -1,  565,
			   -1,   -1,   -1,  569,   56,  571,   57,   58,   59,   -1,
			   62,   -1,   -1,   -1,   65,   66,   67,   68,    3,    4,
			    5,    6,    7,    8,    9,   -1,   -1,   -1,   13,   -1,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
			   -1,   26,   -1,   -1,   -1,   -1,   -1,   -1,   33,   -1,
			  102,  103,   -1,  104,  105,   -1,   -1,   -1,   -1,   -1,
			  111,  112,  113,   -1,   -1,   -1,  117,   -1,  119,  121,
			  121,  123,   57,   -1,   59,  126,  127,   -1,   -1,   -1,

			   65,   66,   67,   68,    3,    4,    5,    6,    7,    8,
			    9,   -1,   -1,  145,   13,   -1,  148,   -1,   -1,   -1,
			   -1,   -1,   -1,    3,    4,    5,    6,    7,    8,    9,
			   -1,   -1,   -1,   13,   33,   -1,   -1,   -1,   -1,  104,
			  105,   -1,   -1,   -1,   -1,   -1,  111,  112,  113,   -1,
			   -1,   -1,  117,   33,  119,   -1,  121,   -1,   57,   -1,
			   59,  126,  127,   -1,   -1,   -1,   65,   66,   67,   68,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   57,   -1,   59,
			   -1,   -1,   -1,   -1,   -1,   65,   66,   67,   68,   97,
			   98,   99,  100,  101,  102,  103,  104,  105,  106,  107,

			  108,  109,  110,  111,   -1,  104,  105,   -1,   -1,   -1,
			   -1,   -1,  111,  112,  113,   -1,   -1,   -1,  117,   -1,
			  119,   -1,  121,   -1,  104,  105,  125,  126,  127,   -1,
			   -1,  111,  112,  113,   -1,   -1,   -1,  117,   -1,  119,
			   -1,  121,   -1,   -1,   -1,  125,  126,  127,    3,    4,
			    5,    6,    7,    8,    9,   -1,   -1,   -1,   13,   -1,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
			   -1,   26,   -1,   -1,   -1,   -1,   -1,   -1,   33,    3,
			    4,    5,    6,    7,    8,    9,   -1,   -1,   -1,   13,
			    3,    4,    5,    6,    7,    8,    9,   -1,   -1,   -1,

			   -1,   -1,   57,   -1,   59,   -1,   -1,   -1,   -1,   33,
			   65,   66,   67,   68,   -1,   -1,   -1,   -1,   -1,   -1,
			   33,    3,    4,    5,    6,    7,    8,    9,   -1,   -1,
			   -1,   13,   -1,   57,   58,   59,   -1,   -1,   -1,   -1,
			   -1,   65,   66,   67,   68,   -1,   59,   -1,   -1,  104,
			  105,   33,   -1,   -1,   -1,   -1,  111,  112,  113,   -1,
			   -1,   -1,  117,   -1,  119,    6,  121,   -1,    9,   10,
			   -1,  126,  127,   -1,   -1,   57,   -1,   59,   -1,   20,
			  104,  105,   23,   65,   66,   67,   68,  111,  112,  113,
			   -1,  104,  105,  117,   35,  119,   37,  121,   -1,   -1,

			   41,  114,  126,  127,    3,    4,    5,    6,    7,    8,
			    9,   -1,   -1,   54,   13,   -1,   -1,   -1,   -1,   -1,
			   -1,   -1,  104,  105,   65,   66,   67,   68,   -1,  111,
			  112,  113,  114,   -1,   33,  117,   46,  119,   -1,  121,
			   -1,   -1,   -1,   -1,  126,  127,   -1,   -1,   -1,   -1,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   57,   -1,
			   59,   -1,   -1,   -1,   -1,   -1,   65,   66,   67,   68,
			   -1,   -1,   -1,  114,   -1,   -1,   -1,   -1,  119,   -1,
			  121,   -1,  123,   -1,   94,   95,   96,   97,   98,   99,
			  100,  101,  102,  103,  104,  105,  106,  107,  108,  109,

			  110,  111,   -1,   -1,   -1,  104,  105,   -1,   -1,   -1,
			   -1,   -1,  111,  112,  113,   -1,   -1,   -1,  117,   -1,
			  119,    6,  121,   -1,    9,   10,   -1,  126,  127,   -1,
			   -1,   -1,   -1,   -1,   -1,   20,   -1,   -1,   23,   -1,
			   -1,   26,   27,   28,   29,   -1,   -1,   -1,   58,   -1,
			   35,   -1,   37,   -1,   -1,   -1,   41,   42,   -1,   -1,
			   -1,   -1,   -1,   -1,   -1,   -1,   58,   -1,   53,   54,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   62,   63,   64,
			   65,   66,   67,   68,   94,   95,   96,   97,   98,   99,
			  100,  101,  102,  103,  104,  105,  106,  107,  108,  109,

			  110,  111,   94,   95,   96,   97,   98,   99,  100,  101,
			  102,  103,  104,  105,  106,  107,  108,  109,  110,  111,
			   58,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  114,
			   -1,   -1,   -1,   -1,  119,   -1,  121,   -1,  123,  124,
			   -1,   -1,   -1,   -1,   64,   -1,   -1,   -1,   -1,   -1,
			   -1,   -1,   -1,   -1,   -1,   -1,   94,   95,   96,   97,
			   98,   99,  100,  101,  102,  103,  104,  105,  106,  107,
			  108,  109,  110,  111,   94,   95,   96,   97,   98,   99,
			  100,  101,  102,  103,  104,  105,  106,  107,  108,  109,
			  110,  111,   94,   95,   96,   97,   98,   99,  100,  101,

			  102,  103,  104,  105,  106,  107,  108,  109,  110,  111,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
			  122,   94,   95,   96,   97,   98,   99,  100,  101,  102,
			  103,  104,  105,  106,  107,  108,  109,  110,  111,   -1,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  122,
			   94,   95,   96,   97,   98,   99,  100,  101,  102,  103,
			  104,  105,  106,  107,  108,  109,  110,  111,   -1,   -1,
			   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  122,   94,
			   95,   96,   97,   98,   99,  100,  101,  102,  103,  104,
			  105,  106,  107,  108,  109,  110,  111,   75,   76,   77,

			   78,   79,   80,   81,   82,   83,   84,   85,   86,   87,
			   88,   89,   90,   91,   92,   95,   96,   97,   98,   99,
			  100,  101,  102,  103,  104,  105,  106,  107,  108,  109,
			  110,  111,   98,   99,  100,  101,  102,  103,  104,  105,
			  106,  107,  108,  109,  110,  111, yyDummy>>)
		end

feature {NONE} -- Semantic value stacks

	yyvs1: SPECIAL [ANY]
			-- Stack for semantic values of type ANY

	yyvsc1: INTEGER
			-- Capacity of semantic value stack `yyvs1'

	yyvsp1: INTEGER
			-- Top of semantic value stack `yyvs1'

	yyspecial_routines1: KL_SPECIAL_ROUTINES [ANY]
			-- Routines that ought to be in SPECIAL [ANY]

feature {NONE} -- Constants

	yyFinal: INTEGER is 576
			-- Termination state id

	yyFlag: INTEGER is -32768
			-- Most negative INTEGER

	yyNtbase: INTEGER is 128
			-- Number of tokens

	yyLast: INTEGER is 1445
			-- Upper bound of `yytable' and `yycheck'

	yyMax_token: INTEGER is 360
			-- Maximum token id
			-- (upper bound of `yytranslate'.)

	yyNsyms: INTEGER is 256
			-- Number of symbols
			-- (terminal and nonterminal)

feature -- User-defined features



feature {NONE} -- Initialization

	make is
			-- Create a new Eiffel parser.
		do
			make_eiffel_scanner
			make_parser_skeleton
		end

	execute is
			-- Parse Eiffel files `arguments (1..argument_count)'.
		local
			j, n: INTEGER
			a_filename: STRING
			a_file: KL_TEXT_INPUT_FILE
		do
			make
			n := Arguments.argument_count
			if n = 0 then
				std.error.put_string ("usage: eiffel_parser filename ...%N")
				Exceptions.die (1)
			else
				from j := 1 until j > n loop
					a_filename := Arguments.argument (j)
					create a_file.make (a_filename)
					a_file.open_read
					if a_file.is_open_read then
						reset
						set_input_buffer (new_file_buffer (a_file))
						parse
						a_file.close
					else
						std.error.put_string ("eiffel_parser: cannot read %'")
						std.error.put_string (a_filename)
						std.error.put_string ("%'%N")
					end
					j := j + 1
				end
			end
		end

	benchmark is
			-- Parse Eiffel file `argument (2)' `argument (1)' times.
		local
			j, n: INTEGER
			a_filename: STRING
			a_file: KL_TEXT_INPUT_FILE
		do
			make
			if
				Arguments.argument_count < 2 or else
				not STRING_.is_integer (Arguments.argument (1))
			then
				std.error.put_string ("usage: eiffel_parser nb filename%N")
				Exceptions.die (1)
			else
				n := Arguments.argument (1).to_integer
				a_filename := Arguments.argument (2)
				from j := 1 until j > n loop
					create a_file.make (a_filename)
					a_file.open_read
					if a_file.is_open_read then
						reset
						set_input_buffer (new_file_buffer (a_file))
						parse
						a_file.close
					else
						std.error.put_string ("eiffel_parser: cannot read %'")
						std.error.put_string (a_filename)
						std.error.put_string ("%'%N")
						Exceptions.die (1)
					end
					j := j + 1
				end
			end
		end

feature -- Error handling

	report_error (a_message: STRING) is
			-- Print error message.
		local
			f_buffer: YY_FILE_BUFFER
		do
			f_buffer ?= input_buffer
			if f_buffer /= Void then
				std.error.put_string (f_buffer.file.name)
				std.error.put_string (", line ")
			else
				std.error.put_string ("line ")
			end
			std.error.put_integer (eif_lineno)
			std.error.put_string (": ")
			std.error.put_string (a_message)
			std.error.put_character ('%N')
		end

end
