indexing

	description:

		"General finite-state automata"

	library: "Gobo Eiffel Lexical Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:09:45 $"
	revision: "$Revision: 1.7 $"

deferred class LX_AUTOMATON

inherit

	ANY -- Needed for SE 2.1b1.

feature -- Access

	start_state: LX_STATE is
			-- Automaton's start state
		deferred
		ensure
			start_state_not_void: Result /= Void
		end

end
