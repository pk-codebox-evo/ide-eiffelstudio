indexing

	description:

		"States of finite automata"

	library: "Gobo Eiffel Lexical Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:09:45 $"
	revision: "$Revision: 1.7 $"

deferred class LX_STATE

inherit

	ANY -- Needed for SE 2.1b1.

feature -- Status report

	is_accepting: BOOLEAN is
			-- Is current state an accepting state?
		deferred
		end

end
