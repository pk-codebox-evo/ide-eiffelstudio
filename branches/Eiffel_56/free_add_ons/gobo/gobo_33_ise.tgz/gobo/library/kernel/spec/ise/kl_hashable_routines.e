indexing

	description:

		"Routines that ought to be in class HASHABLE"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:50:16 $"
	revision: "$Revision: 1.3 $"

class KL_HASHABLE_ROUTINES

feature -- Access

	hash_value (an_any: ANY): INTEGER is
			-- Hash code value
		require
			an_any_not_void: an_any /= Void
		local
			hashable: HASHABLE
		do
			hashable ?= an_any
			if hashable /= Void then
				Result := hashable.hash_code
			else



				Result := generator.hash_code

			end
		ensure
			hash_value_positive: Result >= 0
		end

end
