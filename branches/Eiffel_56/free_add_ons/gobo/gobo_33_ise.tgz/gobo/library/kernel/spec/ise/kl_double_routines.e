indexing

	description:

		"Routines that ought to be in class DOUBLE"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2003, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/12/22 22:43:05 $"
	revision: "$Revision: 1.15 $"

class KL_DOUBLE_ROUTINES

inherit


	DOUBLE_MATH
		rename
			log as old_log,
			log10 as old_log10,
			exp as old_exp
		export
			{NONE} all
		end













	KL_SHARED_PLATFORM

feature -- Logarithms

	log (d: DOUBLE): DOUBLE is
			-- Natural logarithm of `d'
		require
			d_positive: d > 0.0
		do




			Result := old_log (d)




		end

	log2 (d: DOUBLE): DOUBLE is
			-- Base 2 logarithm of `d'
		require
			d_positive: d > 0.0









		do

			Result := log_2 (d)










		end

	log10 (d: DOUBLE): DOUBLE is
			-- Base 10 logarithm of `d'
		require
			d_positive: d > 0.0
		do




			Result := old_log10 (d)




		end

feature -- Exponent

	exp (d: DOUBLE): DOUBLE is
			-- Inverse of the natural logarithm
		do




			Result := old_exp (d)




		end

	nth_root (d, n: DOUBLE): DOUBLE is
			-- `n'-th root of `d'
		require



			divisible: (1.0).divisible (n)

		do

			Result := d ^ (1.0 / n)




		end

	floor_to_integer (d: DOUBLE): INTEGER is
			-- INTEGER floor
			-- (floor returns integer in ELKS, but a floating point value with SE2)
		require
			d_large_enough: d >= Platform.Minimum_integer
			d_small_enough: d < (Platform.Maximum_integer + 1.0)
		do
			Result := d.truncated_to_integer
			if d.floor /= Result then
				Result := Result - 1
			end
		ensure
			definition: Result = d.floor
		end

end
