indexing

	description:

		"Binary input files containing extended ASCII %
		%characters (8-bit code between 0 and 255)"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:09:43 $"
	revision: "$Revision: 1.21 $"

class KL_BINARY_INPUT_FILE

inherit

	KI_BINARY_INPUT_FILE
		undefine

			read_to_string,


			copy,

			read_to_buffer
		end

	KL_INPUT_FILE



































































creation

	make















































end
