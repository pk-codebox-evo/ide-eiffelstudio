indexing

	description:

		"Version of Gobo"

	copyright: "Copyright (c) 2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:09:43 $"
	revision: "$Revision: 1.2 $"

class KL_GOBO_VERSION

inherit

	ANY -- Needed for SE 2.1b1.

feature -- Constants

	Version_number: STRING is "3.3"

end
