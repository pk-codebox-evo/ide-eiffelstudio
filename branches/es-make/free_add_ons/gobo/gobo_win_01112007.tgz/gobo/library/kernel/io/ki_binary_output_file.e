indexing

	description:

		"Interface for binary output files containing extended ASCII %
		%characters (8-bit code between 0 and 255)"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:49:50 $"
	revision: "$Revision: 1.5 $"

deferred class KI_BINARY_OUTPUT_FILE

inherit

	KI_OUTPUT_FILE

end
