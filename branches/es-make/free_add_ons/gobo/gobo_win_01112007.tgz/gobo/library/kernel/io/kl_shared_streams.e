indexing

	description:

		"Shared input and output streams"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:49:51 $"
	revision: "$Revision: 1.5 $"

class KL_SHARED_STREAMS

feature -- Access

	null_output_stream: KL_NULL_TEXT_OUTPUT_STREAM is
			-- Null output stream
		once
			create Result.make ("null")
		ensure
			null_output_stream_not_void: Result /= Void
		end

end
