indexing

	description:

		"Routines that ought to be in class HASHABLE"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/02/03 15:50:34 $"
	revision: "$Revision: 1.4 $"

class KL_HASHABLE_ROUTINES

feature -- Access

	hash_value (an_any: ANY): INTEGER is
			-- Hash code value
		require
			an_any_not_void: an_any /= Void

		local
			hashable: HASHABLE
		do
			hashable ?= an_any
			if hashable /= Void then
				Result := hashable.hash_code
			else
				Result := an_any.generating_type.hash_code
			end




		ensure
			hash_value_positive: Result >= 0
		end

end
