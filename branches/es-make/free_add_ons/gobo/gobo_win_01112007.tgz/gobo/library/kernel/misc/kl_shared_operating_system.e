indexing

	description:

		"Shared operating system"

	pattern: "Singleton"
	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:50:16 $"
	revision: "$Revision: 1.5 $"

class KL_SHARED_OPERATING_SYSTEM

feature -- Acess

	operating_system: KL_OPERATING_SYSTEM is
			-- Underlying operating system
		once
			create Result
		ensure
			operating_system_not_void: Result /= Void
		end

end
