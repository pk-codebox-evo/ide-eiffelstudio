indexing

	description:

		"Version of Gobo"

	copyright: "Copyright (c) 2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/07/07 21:36:41 $"
	revision: "$Revision: 1.3 $"

class KL_GOBO_VERSION

inherit

	ANY -- Needed for SE 2.1b1.

feature -- Constants

	Version_number: STRING is "3.4"

end
