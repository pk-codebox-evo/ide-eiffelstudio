indexing

	description:

		"Warning: Dangerous variable trailing context in rule"

	library: "Gobo Eiffel Lexical Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/07/13 17:06:45 $"
	revision: "$Revision: 1.8 $"

class LX_DANGEROUS_TRAILING_CONTEXT_ERROR

inherit

	UT_ERROR

create

	make

feature {NONE} -- Initialization

	make (filename: STRING; line: INTEGER) is
			-- Create a new error reporting that a rule
			-- contains "dangerous" variable trailing context.
		require
			filename_not_void: filename /= Void
		do
			create parameters.make (1, 2)
			parameters.put (filename, 1)
			parameters.put (line.out, 2)
		end

feature -- Access

	default_template: STRING is
		"Warning, %"$1%", line $2: dangerous trailing context"
			-- Default template used to built the error message

	code: STRING is "LX0026"
			-- Error code

invariant

	-- dollar0: $0 = program name
	-- dollar1: $1 = filename
	-- dollar2: $2 = line number

end
