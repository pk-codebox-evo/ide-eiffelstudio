indexing

	description:

		"Epsilon transitions to automaton states"

	library: "Gobo Eiffel Lexical Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/07/13 17:06:45 $"
	revision: "$Revision: 1.7 $"

class LX_EPSILON_TRANSITION [G -> LX_STATE]

inherit

	LX_TRANSITION [G]

create

	make

end
