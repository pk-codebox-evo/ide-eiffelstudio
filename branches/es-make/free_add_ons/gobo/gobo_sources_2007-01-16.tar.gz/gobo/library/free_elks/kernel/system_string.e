indexing
	description: "Fake abstraction of a .NET SYSTEM_STRING in a non-.NET system"
	library: "Free implementation of ELKS library"
	copyright: "Copyright (c) 1986-2006, Eiffel Software and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2007/01/14 09:55:41 $"
	revision: "$Revision: 1.2 $"

deferred class
	SYSTEM_STRING

feature -- Access

	length: INTEGER is do end

invariant
	is_dotnet: {PLATFORM}.is_dotnet

end
