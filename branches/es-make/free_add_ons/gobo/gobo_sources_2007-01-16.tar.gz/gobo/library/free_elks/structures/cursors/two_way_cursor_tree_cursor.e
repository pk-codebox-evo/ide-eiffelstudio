indexing
	description: "Cursors for two-way-cursor trees"
	legal: "See notice at end of class."
	status: "See notice at end of class."
	names: two_way_tree, cursor;
	contents: generic;
	date: "$Date: 2007/01/14 09:55:50 $"
	revision: "$Revision: 1.2 $"

class
	TWO_WAY_CURSOR_TREE_CURSOR [G]

inherit
	RECURSIVE_TREE_CURSOR [G]
		redefine
			active
		end

create
	make

feature {TWO_WAY_CURSOR_TREE} -- Access

	active: TWO_WAY_TREE [G];
			-- Current node

indexing
	library:	"EiffelBase: Library of reusable components for Eiffel."
	copyright:	"Copyright (c) 1984-2006, Eiffel Software and others"
	license:	"Eiffel Forum License v2 (see http://www.eiffel.com/licensing/forum.txt)"
	source: "[
			 Eiffel Software
			 356 Storke Road, Goleta, CA 93117 USA
			 Telephone 805-685-1006, Fax 805-685-6869
			 Website http://www.eiffel.com
			 Customer support http://support.eiffel.com
		]"







end