indexing

	description: "[
		Basic mathematical constants.
		This class may be used as ancestor by classes needing its facilities.
		]"

	library: "Free implementation of ELKS library"
	copyright: "Copyright (c) 2005, Eiffel Software and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2007/01/14 09:56:06 $"
	revision: "$Revision: 1.2 $"

class
	MATH_CONST

feature -- Access

	Pi: DOUBLE is 3.14159265358979323846

	Sqrt2: DOUBLE is 1.41421356237309504880
			-- Square root of 2

	Euler: DOUBLE is 2.7182818284590452354;
			-- Logarithm base

end
