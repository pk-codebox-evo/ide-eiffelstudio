indexing

	description:

		"Unicode routines which apply to a specific version"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2006, Colin Adams and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2006/03/28 14:48:30 $"
	revision: "$Revision: 1.1 $"

deferred class UC_UNICODE_VERSIONING

feature -- Access

	major_version: INTEGER is
			-- Major version number of Unicode
		deferred
		ensure
			major_version_strictly_positive: Result > 0
		end
	
	minor_version: INTEGER is
			-- Minor version number of Unicode
		deferred
		ensure
			minor_version_non_negative: Result >= 0
			single_digit: Result < 10
		end
	
	update_version: INTEGER is
			-- Update version number of Unicode
		deferred
		ensure
			update_version_non_negative: Result >= 0
			single_digit: Result < 10
		end

end

