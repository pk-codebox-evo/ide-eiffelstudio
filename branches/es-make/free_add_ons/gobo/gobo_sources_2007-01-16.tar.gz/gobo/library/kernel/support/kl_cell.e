indexing

	description:

		"Cells containing an item"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/07/13 17:05:10 $"
	revision: "$Revision: 1.6 $"

class KL_CELL [G]

inherit

	ANY -- Needed for SE 2.1b1.

create

	make

feature -- Access

	item: G 
			-- Content of cell

feature -- Element change

	put, make (v: G) is
			-- Insert `v' in cell.
		do
			item := v
		ensure
			inserted: item = v
		end

end
