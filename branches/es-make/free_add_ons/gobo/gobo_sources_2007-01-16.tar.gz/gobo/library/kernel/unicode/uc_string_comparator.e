indexing

	description:

		"Comparators of strings that can be polymorphically unicode strings"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2006, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2006/02/26 10:26:52 $"
	revision: "$Revision: 1.1 $"

class UC_STRING_COMPARATOR

inherit

	KL_COMPARATOR [STRING]

	KL_IMPORTED_STRING_ROUTINES

feature -- Status report

	less_than (u, v: STRING): BOOLEAN is
			-- Is `u' considered less than `v'?
		do
			Result := STRING_.three_way_comparison (u, v) = -1
		end

end
