indexing

	description:

		"Database for simple mapping to lower case"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2006, Colin Adams and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2006/10/13 10:58:21 $"
	revision: "$Revision: 1.22 $"

class UC_CTYPE_LOWERCASE

inherit

	UC_V500_CTYPE_LOWERCASE

end
