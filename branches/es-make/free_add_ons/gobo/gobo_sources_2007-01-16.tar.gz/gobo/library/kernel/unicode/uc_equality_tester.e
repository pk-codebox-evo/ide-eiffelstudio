indexing

	description:

		"Equality testers between strings that can be polymorphically unicode strings"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2002-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/03/16 17:02:02 $"
	revision: "$Revision: 1.6 $"

class UC_EQUALITY_TESTER

obsolete

	"[040315] Use UC_STRING_EQUALITY_TESTER instead."

inherit

	UC_STRING_EQUALITY_TESTER

end
