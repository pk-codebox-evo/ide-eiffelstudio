indexing

	description:

		"Routines for cased variants of Unicode characters"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2005, Colin Adams and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2006/03/28 14:48:30 $"
	revision: "$Revision: 1.9 $"

class UC_CTYPE

inherit

	UC_V410_CTYPE

end
