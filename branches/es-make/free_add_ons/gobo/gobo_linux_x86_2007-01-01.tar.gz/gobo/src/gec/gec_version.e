indexing

	description:

		"Version of gec"

	copyright: "Copyright (c) 2005, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/10/28 12:19:24 $"
	revision: "$Revision: 1.1 $"

class GEC_VERSION

inherit

	KL_GOBO_VERSION

end
