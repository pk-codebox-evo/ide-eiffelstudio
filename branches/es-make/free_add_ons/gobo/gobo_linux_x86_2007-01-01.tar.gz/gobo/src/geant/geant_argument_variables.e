indexing

	description:

		"Argument variables for GEANT"

	library: "Gobo Eiffel Ant"
	copyright:"Copyright (c) 2005, Sven Ehrke and others"
	license:"Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/07/22 19:20:30 $"
	revision:"$Revision: 1.1 $"

class GEANT_ARGUMENT_VARIABLES

inherit

	GEANT_VARIABLES

create

	make

feature -- Status report

	has_numbered_keys: BOOLEAN is
			-- Do entries exist which indicate that Current contains only numbered entries?
		do
			Result := has ("1")
		ensure
			definition: Result implies has ("1")
		end

end
