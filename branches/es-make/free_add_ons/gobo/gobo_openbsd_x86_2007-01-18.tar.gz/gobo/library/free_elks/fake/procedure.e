indexing
	description: "[
		Objects representing delayed calls to a procedure.
		with some operands possibly still open.
		]"
	library: "Free implementation of ELKS library"
	copyright: "Copyright (c) 1986-2004, Eiffel Software and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2006/05/14 17:17:56 $"
	revision: "$Revision: 1.3 $"

class
	PROCEDURE [BASE_TYPE, OPEN_ARGS -> TUPLE create default_create end]

inherit
	ROUTINE [BASE_TYPE, OPEN_ARGS]

feature -- Calls

	call (args: OPEN_ARGS) is
			-- Call routine with operands `args'.
		external
			"built_in"
		end

end
