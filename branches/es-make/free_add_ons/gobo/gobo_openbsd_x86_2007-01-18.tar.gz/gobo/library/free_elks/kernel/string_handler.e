indexing
	description: "Objects that can access `set_count' from STRING"
	library: "Free implementation of ELKS library"
	copyright: "Copyright (c) 1986-2004, Eiffel Software and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/11/01 12:22:25 $"
	revision: "$Revision: 1.1 $"

class
	STRING_HANDLER

end
