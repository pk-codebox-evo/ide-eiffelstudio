indexing
	description: "Fake abstraction of a .NET NATIVE_ARRAY in a non-.NET system"
	library: "Free implementation of ELKS library"
	copyright: "Copyright (c) 2005, Eiffel Software and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/11/01 12:22:25 $"
	revision: "$Revision: 1.1 $"

class
	NATIVE_ARRAY [G]

create {NONE}

invariant
	is_dotnet: {PLATFORM}.is_dotnet

end
