indexing

	description:

		"Imported routines that ought to be in class DOUBLE"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2003, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:49:18 $"
	revision: "$Revision: 1.2 $"

class KL_IMPORTED_DOUBLE_ROUTINES

feature -- Access

	DOUBLE_: KL_DOUBLE_ROUTINES is
			-- Routines that ought to be in class DOUBLE
		once
			create Result
		ensure
			double_routines_not_void: Result /= Void
		end

end
