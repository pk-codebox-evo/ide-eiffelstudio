indexing

	description:

		"Make sure that we don't have name clashes with features %
		%from PLATFORM inherited from ANY in SE 1.2"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2006, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2006/04/22 09:42:11 $"
	revision: "$Revision: 1.1 $"

class KL_ANY

inherit

	ANY















end
