indexing

	description:

		"System clock example"

	copyright: "Copyright (c) 2001-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/07/13 17:03:50 $"
	revision: "$Revision: 1.7 $"

class CLOCK

inherit

	DT_SHARED_SYSTEM_CLOCK
	KL_SHARED_STANDARD_FILES

create

	execute

feature -- Execution

	execute is
			-- Print current date and time.
		do
			std.output.put_string ("Time Now: ")
			std.output.put_line (system_clock.time_now.precise_out)
			std.output.put_string ("Date Now: ")
			std.output.put_line (system_clock.date_now.out)
			std.output.put_string ("DateTime Now: ")
			std.output.put_line (system_clock.date_time_now.precise_out)
			std.output.put_string ("UTC Time Now: ")
			std.output.put_line (utc_system_clock.time_now.precise_out)
			std.output.put_string ("UTC Date Now: ")
			std.output.put_line (utc_system_clock.date_now.out)
			std.output.put_string ("UTC DateTime Now: ")
			std.output.put_line (utc_system_clock.date_time_now.precise_out)
		end

end
