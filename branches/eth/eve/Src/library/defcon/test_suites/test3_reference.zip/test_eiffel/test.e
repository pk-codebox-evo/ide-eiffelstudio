indexing
	description: "Project root class"

class
	TEST

create
	make

feature {NONE} -- Initialization

	make is
			-- Run application.
		do
			create random.make
			test_reference
		end

feature
	test_reference is
			-- Store, retrieve, update and delete a tree object.
		local
			root : TREE_NODE
			res_root, res_updated_root : TREE_NODE
		do
			-- create a binary tree
			root := make_tree(0)
			print_tree(root, 0)

			-- get class metadata of TREE_NODE
			-- Output:
			-- Type: RootCluster.Impl.TreeNode
			-- Base type: System.Object
			-- Interfaces: 	RootCluster.TreeNode,
			--				EiffelSoftware.Runtime.EIFFEL_TYPE_INFO,
			--				EiffelSoftware.Library.Base.Kernel.Any,
			-- IsValueType: False
			print_classmetadata(root)

			-- store and retrieve the tree, and then compare the retrieved one with the original one
			store_tree(root)
			res_root := retrieve_tree
			if (res_root /= Void) then
				print_tree(res_root, 0)
				io.put_string("The stored and retrieved trees are ")
				if (deep_equal(res_root, root)) then
					io.put_string("equal.")
				else
					io.put_string("not equal.")
				end
			end

			-- modify the tree and save the modification in the database,
			-- then retrieve the tree and compare the retrieved one with the one modified
			update_tree	-- set root.left.left.right.left.parent.id to 200
			res_updated_root := retrieve_tree
			root.left.left.right.left.parent.set_id(200);
			if (res_updated_root /= Void) then
				io.put_string("The tree is ")
				if (deep_equal(res_updated_root, root)) then
					io.put_string("updated in the database.")
				else
					io.put_string("not updated in the database.")
				end
			end

			-- delete the tree
			delete_tree
		end

	make_tree(level : INTEGER) : TREE_NODE is
			-- Make a binary tree.
		require
			level_not_negative : level >= 0
		local
			node : TREE_NODE
		do
			if (level > TREE_LEVEL) then
				Result := Void
			else
				if (level = 0) then
					create node.make_id (ROOT_ID)
				else
					create node.make_id (random.next(1,100))
				end
				node.set_left(make_tree(level+1))
				node.set_right(make_tree(level+1))
				Result := node
			end
		end

	print_tree(node : TREE_NODE; level : INTEGER) is
			-- Print the tree.
		require
			node_not_void : node /= Void
			level_not_negative : level >= 0
		local
			indent : STRING
			l : INTEGER
		do
			l := level
			create indent.make_empty
			from
			until l = 0
			loop
				indent := indent + "    "
				l := l-1
			end
			io.put_string(indent + node.id.out)
			io.put_new_line
			if (node.left /= Void) then
				print_tree(node.left, level+1)
			end
			if (node.right /= Void) then
				print_tree(node.right, level+1)
			end
		end


	store_tree(root : TREE_NODE) is
			-- Store the tree.
		require
			root_not_void: root /= Void
		local
			db : IOBJECT_CONTAINER
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test.yap");
			db.set(root)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	retrieve_tree : TREE_NODE is
			-- Return the root node of the tree stored in the database.
		local
			dr, resr : TREE_NODE
			config : ICONFIGURATION
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create dr.make_id(ROOT_ID)
			config := {DB_4O_FACTORY}.new_configuration
			-- test different methods for setting the activation depth
			config.object_class (dr).cascade_on_activate (True)  -- The whole tree is activated.
			--config.object_class (dr).object_field ("$$left").cascade_on_activate (True)  -- Default behavior, the tree is activated to the 5. level.
			--config.object_class (dr).object_field ("$$right").cascade_on_activate (True)
			--config.object_class (dr).minimum_activation_depth(6)  -- The whole tree is activated.
			--config.object_class(dr).maximum_activation_depth(3)  -- The tree is activated to the 3. level.
			--config.activation_depth(2)  -- The tree is activated to the 2. level.
			db := {DB_4O_FACTORY}.open_file(config, "test.yap")
			results := db.get(dr)
			if (results.has_next) then
				resr ?= results.next
				if (resr /= Void) then
					--db.deactivate (resr.left.left.left.left, 4) -- resr.left remains activated after the call
					Result := resr
				end
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	update_tree is
			-- Modify one node of the tree and then update the modification in the database.
		local
			dr, resr : TREE_NODE
			config : ICONFIGURATION
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create dr.make_id(ROOT_ID)
			config := {DB_4O_FACTORY}.new_configuration
			--config.object_class(dr).cascade_on_activate(True)
			config.object_class(dr).maximum_activation_depth(1)
			--config.update_depth(3)
			--config.object_class(dr).cascade_on_update (True)
			--config.object_class(dr).object_field("$$left").cascade_on_update (True)
			--config.object_class(dr).object_field("$$right").cascade_on_update (True)
			--config.object_class(dr).update_depth(3)
			db := {DB_4O_FACTORY}.open_file(config, "test.yap")
			results := db.get(dr)
			if (results.has_next) then
				resr ?= results.next
				if (resr /= Void) then
					-- modify the tree node
					-- 1. approach: correct when the nodes on the traversing path are already in memory, this is the case when cascade_on_activate=True
					--resr.left.left.right.left.parent.set_id(200)

					-- 2. approach: set maximum_activation_depth=1, then activate the tree nodes manually
					db.activate (resr.left, 1)
					db.activate (resr.left.left, 1)
					db.activate (resr.left.left.right, 1)
					db.activate (resr.left.left.right.left, 1)
					resr.left.left.right.left.parent.set_id(200)

					-- store the modification in the database
					-- 1. approach: update the whole tree starting from the root node, OK when the update depth is large enough, in this case, update_depth>=3
					--db.set (resr)

					-- 2. approach: dynamically set the update depth for root, in this case update_depth>=4 for root
					--db.ext.set(resr, 4)

					-- 3. approach: update only the modified node
					db.set(resr.left.left.right.left.parent)
				end
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	delete_tree is
			-- Delete the tree.
		local
			dr : TREE_NODE
			config : ICONFIGURATION
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create dr.make_id(ROOT_ID)
			config := {DB_4O_FACTORY}.new_configuration
			--config.object_class (dr).cascade_on_delete (True)
			config.object_class(dr).object_field ("$$left").cascade_on_delete (True)
			config.object_class(dr).object_field ("$$right").cascade_on_delete (True)
			db := {DB_4O_FACTORY}.open_file(config, "test.yap")
			results := db.get(dr)
			if (results.has_next) then
				db.delete(results.next)
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

feature
	print_classmetadata(obj : SYSTEM_OBJECT) is
			-- Output the class metadata of the type of obj.
		require
			obj_not_void : obj /= Void
		local
			objtype, basetype : SYSTEM_TYPE
			interfaces : NATIVE_ARRAY[SYSTEM_TYPE]
			i : INTEGER
		do
			objtype := obj.get_type
			basetype := objtype.base_type
			{SYSTEM_CONSOLE}.write_line("Type: " + objtype.to_string)
			{SYSTEM_CONSOLE}.write_line("Base type: " + basetype.to_string)
			interfaces := objtype.get_interfaces
			{SYSTEM_CONSOLE}.write("Interfaces: ")
			from i := interfaces.length - 1
			until i = -1
			loop
				{SYSTEM_CONSOLE}.write(interfaces.item(i).to_string + ", ")
				i := i-1
			end
			{SYSTEM_CONSOLE}.write_line("IsValueType: " + objtype.is_value_type.out)
			{SYSTEM_CONSOLE}.write_line
		end


feature {NONE}
	random : SYSTEM_RANDOM
	ROOT_ID : INTEGER is 123	-- The root of the tree has the ID 123, all the other child nodes have an ID between 1 and 100.
								-- The ROOT_ID constant is introduced for query convenience.
	TREE_LEVEL : INTEGER is 8

end
