indexing
	description: "Objects that represent nodes of a binary tree."
	author: "Ruihua Jin"
	date: "October 19, 2007"
	revision: "1.0"

class
	TREE_NODE

create
	default_create,
	make_id,
	make_id_parent,
	make

feature {NONE}
	make_id(i : INTEGER) is
			-- Initialization with an ID.
		do
			set_id(i)
		end

	make_id_parent(i : INTEGER; p : TREE_NODE) is
			-- Initialization with an ID and a parent node.
		do
			make_id(i)
			set_parent(p)
		end

	make(i : INTEGER; p : TREE_NODE; l : TREE_NODE; r : TREE_NODE) is
			-- Initialization with an ID, a parent node, left and right child nodes.
		do
			make_id_parent(i, p)
			set_left(l)
			set_right(r)
		end


feature
	set_parent(p : TREE_NODE) is
			-- Set the parent node of the current node.
		do
			parent := p
		end

	set_left(l : TREE_NODE) is
			-- Set the left child node of the current node.
		do
			left := l
			if (left /= Void) then
				left.set_parent (Current)
			end
		end

	set_right(r : TREE_NODE) is
			-- Set the right child node of the current node.
		do
			right := r
			if (right /= Void) then
				right.set_parent (Current)
			end
		end

	set_id(i : INTEGER) is
			-- Set the ID of the current node.
		do
			id := i
		end

feature
	parent : TREE_NODE
	left, right : TREE_NODE
	id : INTEGER

end
