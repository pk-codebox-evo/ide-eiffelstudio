indexing
	description: "Project root class"

class
	TEST

create
	make

feature {NONE} -- Initialization

	make is
			-- Run application.
		do
			test_predefined_expanded_class
			test_string
		end

feature
	test_predefined_expanded_class is
			-- Store instances of VALUE_TEST_CLASS and then retrieve instances of VALUE_TEST_CLASS.
		do
			store_values
			query_values
		end

	store_values is
			-- Store an instance of VALUE_TEST_CLASS.
		local
			v : VALUE_TEST_CLASS
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test.yap");
			create v.make
			db.set(v)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	query_values is
			-- Retrieve instances of VALUE_TEST_CLASS and
			-- check whether the stored field values are identical to the original one.
			-- Output: The stored VALUE_CLASS instance is equal to the original one. Query by computation succeeded.
		local
			dv, ret, v : VALUE_TEST_CLASS
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
			int32_halfmax : INTEGER_32
		do
			db := {DB_4O_FACTORY}.open_file("test.yap");
			create dv.default_create
			results := db.get(dv)
			if (results.has_next) then
				ret ?= results.next
				if (ret /= Void) then
					create v.make
					if (v.is_equal(ret)) then
						io.put_string("The stored VALUE_CLASS instance is equal to the original one.")
					else
						io.put_string("The stored VALUE_CLASS instance is not equal to the original one.")
					end
					io.put_new_line
					-- test for uniform access, query by computation
					int32_halfmax := ret.int32_halfmax
					if (int32_halfmax = v.int32_halfmax) then
						io.put_string("Query by computation succeeded.")
					else
						io.put_string("Query by computation failed.")
					end
				else
					io.put_string("No VALUE_CLASS instance retrieved.")
				end
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	test_string is
			-- Store instances of STRING_TEST_CLASS and then retrieve instances of STRING_TEST_CLASS.
		do
			store_string
			query_string
		end

	store_string is
			-- Store an instance of STRING_TEST_CLASS.
		local
			str : STRING_TEST_CLASS
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create str.make
			db := {DB_4O_FACTORY}.open_file("test.yap");
			db.set(str)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	query_string is
			-- Retrieve instances of STRING_TEST_CLASS and
			-- check whether the stored field values are identical to the original one.
			-- Output: The stored STRING_TEST_CLASS instance is equal to the original one.
		local
			dstr, ret, str : STRING_TEST_CLASS
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
			eq1, eq2, eq3 : BOOLEAN
		do
			create dstr.default_create
			db := {DB_4O_FACTORY}.open_file("test.yap");
			results := db.get(dstr)
			from
			until not results.has_next
			loop
				ret ?= results.next
				if (ret /= Void) then
					create str.make
					eq1 := str.str8.same_string(ret.str8)
					--eq2 := str.str32.same_string(ret.str32)
					eq3 := str.sysstr.equals(ret.sysstr)
					if (eq1 and eq3) then
						io.put_string("The stored STRING_TEST_CLASS instance is equal to the original one.")
					else
						io.put_string("The stored STRING_TEST_CLASS instance is not equal to the original one.")
					end
					io.put_new_line
				end
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

end
