indexing
	description: "Objects that contain fields of expanded types defined in EiffelBase"
	author: "Ruihua Jin"
	date: "October 16, 2007"
	revision: "1.0"

class
	VALUE_TEST_CLASS

create
	default_create,
	make

feature {NONE} -- Implementation
	make is
			-- Initialization
		do
			bool_true := True
			bool_false := False
			ch8 := 'a'
			ch32 := 'b'
			int16_min := {INTEGER_16}.min_value
			int16_max := {INTEGER_16}.max_value
			int32_min := {INTEGER_32}.min_value
			int32_max := {INTEGER_32}.max_value
			int64_min := {INTEGER_64}.min_value
			int64_max := {INTEGER_64}.max_value
			int8_min := {INTEGER_8}.min_value
			int8_max := {INTEGER_8}.max_value
			n16_min := {NATURAL_16}.min_value
			n16_max := {NATURAL_16}.max_value
			n32_min := {NATURAL_32}.min_value
			n32_max := {NATURAL_32}.max_value
			n64_min := {NATURAL_64}.min_value
			n64_max := {NATURAL_64}.max_value
			n8_min := {NATURAL_8}.min_value
			n8_max := {NATURAL_8}.max_value
			real32 := 2.356739503
			real64 := {MATH_CONST}.Pi
		end

feature
	int16_halfmax : INTEGER_16 is
			--
		do
			Result := int16_max // 2
		end

	int32_halfmax : INTEGER_32 is
			--
		do
			Result := int32_max // 2
		end

	int64_halfmax : INTEGER_64 is
			--
		do
			Result := int64_max // 2
		end

	int8_halfmax : INTEGER_8 is
			--
		do
			Result := int8_max // 2
		end

	n16_halfmax : NATURAL_16 is
			--
		do
			Result := n16_max // 2
		end

	n32_halfmax : NATURAL_32 is
			--
		do
			Result := n32_max // 2
		end

	n64_halfmax : NATURAL_64 is
			--
		do
			Result := n64_max // 2
		end

	n8_halfmax : NATURAL_8 is
			--
		do
			Result := n8_max // 2
		end


feature
	bool_true, bool_false : BOOLEAN
	ch8 : CHARACTER_8
	ch32 : CHARACTER_32
	int16_min, int16_max : INTEGER_16
	int32_min, int32_max : INTEGER_32
	int64_min, int64_max : INTEGER_64
	int8_min, int8_max : INTEGER_8
	n16_min, n16_max : NATURAL_16
	n32_min, n32_max : NATURAL_32
	n64_min, n64_max : NATURAL_64
	n8_min, n8_max : NATURAL_8
	real32 : REAL_32
	real64 : REAL_64

end
