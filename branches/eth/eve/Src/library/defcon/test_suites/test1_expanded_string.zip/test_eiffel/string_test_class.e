indexing
	description: "Objects that contain fields of type String_8 and SYSTEM_STRING"
	author: "Ruihua Jin"
	date: "October 16, 2007"
	revision: "1.0"

class
	STRING_TEST_CLASS

create
	default_create,
	make

feature {NONE}
	make is
			-- Initialization
		do
			str8 := "a STRING_8 instance"
			sysstr := "a SYSTEM_STRING instance"
			--str32 := "a STRING_32 instance"	-- makes queries for instances of STRING_TEST_CLASS fail.
		end

feature
	str8 : STRING_8
	sysstr : SYSTEM_STRING
	--str32 : STRING_32

end
