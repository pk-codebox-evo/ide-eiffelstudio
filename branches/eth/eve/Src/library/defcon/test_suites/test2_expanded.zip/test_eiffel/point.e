indexing
	description: "Objects that represent points in a two-dimensional space"
	author: "Ruihua Jin"
	date: "October 17, 2007"
	revision: "1.0"

expanded class
	POINT

create
	default_create,
	make

feature {NONE}
	make(a : INTEGER; b : INTEGER) is
			-- Initialization
		do
			x := a
			y := b
		end

feature
	x, y : INTEGER

feature
	set_x(a : INTEGER) is
			-- Set the value of x.
		do
			x := a
		end

	set_y(b : INTEGER) is
			-- Set the value of y.
		do
			y := b
		end

feature
	to_string : STRING is
			-- String representation of POINT
		do
			Result := "Point (" + x.out + ", " + y.out + ")"
		end

end
