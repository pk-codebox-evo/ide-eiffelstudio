indexing
	description: "Project root class"

class
	TEST

create
	make

feature {NONE} -- Initialization

	make is
			-- Run application.
		do
			test_expanded_class
			test_expanded_field
		end

feature
	test_expanded_class is
			-- Store an instance of POINT and then retrieve the instances of POINT.
		do
			store_point
			query_point
		end


	store_point is
			-- Examine the class metadata of POINT and then store an instance of POINT.
		local
			p : POINT
			r : SYSTEM_RANDOM
			px, py : INTEGER
			db : IOBJECT_CONTAINER
			closed : BOOLEAN
		do
			create r.make
			px := r.next(1, 50)
			py := r.next(1, 50)
			create p.make(px, py)

			-- get class metadata of POINT
			-- Output:
			-- Type: RootCluster.Point
			-- Base type: 	System.ValueType
			-- Interfaces: 	RootCluster.ReferencePoint,
			--				EiffelSoftware.Runtime.EIFFEL_TYPE_INFO,
 			--				EiffelSoftware.Library.Base.Kernel.Any,
 			-- IsValueType: True
			print_classmetadata(p)

			-- store p
			db := {DB_4O_FACTORY}.open_file("test.yap");
			db.set(p)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	query_point is
			-- Retrieve the instances of POINT from the database.
		local
			dp, resp : POINT
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test.yap");
			create dp.default_create
			results := db.get(dp)

			-- output the first POINT instance
			-- output: Point (3, 8)
			if (results.has_next) then
				resp ?= results.next	-- Warning: Target of assignment attempt is expanded. Make sure the target is of a reference type.
				if (resp /= Void) then
					io.put_string(resp.to_string)
				end
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	test_expanded_field is
			-- Store an instance of FIGURE and then retrieve the instances of FIGURE.
		do
			store_figure
			query_figure
		end


	store_figure is
			-- Examine the class metadata of FIGURE and then store an instance of FIGURE.
		local
			upperleftpnt : POINT
			rec : expanded RECTANGLE	-- Syntax Warning: Obsolete syntax used. Make an expanded version of the base class associated with this type.
			fig : FIGURE
			px, py, width, height : INTEGER
			r : SYSTEM_RANDOM
			db : IOBJECT_CONTAINER
			closed : BOOLEAN
		do
			create r.make
			px := r.next(1, 50)
			py := r.next(1, 50)
			create upperleftpnt.make(px, py)
			width := r.next(1,50)
			height := r.next(1,50)
			create rec.make(upperleftpnt, width, height)
			create fig.make(rec)

			-- get class metadata of expanded RECTANGLE
			-- Output:
			-- Type: 		RootCluster.ValueRectangle
			-- Base type: 	System.ValueType
			-- Interfaces: 	RootCluster.Rectangle,
			--				EiffelSoftware.Runtime.EIFFEL_TYPE_INFO,
			--				EiffelSoftware.Library.Base.Kernel.Any,
			-- IsValueType: True
			print_classmetadata(rec)

			-- get class metadata of FIGURE
			-- Output:
			-- Type: RootCluster.Impl.Figure
			-- Base type: 	System.Object
			-- Interfaces: 	RootCluster.Figure,
			--				EiffelSoftware.Runtime.EIFFEL_TYPE_INFO,
			--				EiffelSoftware.Library.Base.Kernel.Any,
			-- IsValueType: False
			print_classmetadata(fig)

			-- store fig
			db := {DB_4O_FACTORY}.open_file("test.yap");
			db.set(fig)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	query_figure is
			-- Retrieve the instances of FIGURE from the database.
		local
			dfig, resfig : FIGURE
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test.yap");
			create dfig.default_create
			results := db.get(dfig)

			-- output the first FIGURE instance
			-- output: Bound: Upperleft point: Point (5, 47), width=30, height=11
			if (results.has_next) then
				resfig ?= results.next
				if (resfig /= Void) then
					io.put_string(resfig.to_string)
				end
			end

			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

feature
	print_classmetadata(obj : SYSTEM_OBJECT) is
			-- Output the class metadata of the type of obj.
		local
			objtype, basetype : SYSTEM_TYPE
			interfaces : NATIVE_ARRAY[SYSTEM_TYPE]
			i : INTEGER
		do
			objtype := obj.get_type
			basetype := objtype.base_type
			{SYSTEM_CONSOLE}.write_line("Type: " + objtype.to_string)
			{SYSTEM_CONSOLE}.write_line("Base type: " + basetype.to_string)
			interfaces := objtype.get_interfaces
			{SYSTEM_CONSOLE}.write("Interfaces: ")
			from i := interfaces.length - 1
			until i = -1
			loop
				{SYSTEM_CONSOLE}.write(interfaces.item(i).to_string + ", ")
				i := i-1
			end
			{SYSTEM_CONSOLE}.write_line("IsValueType: " + objtype.is_value_type.out)
			{SYSTEM_CONSOLE}.write_line
		end

end
