indexing
	description: "Objects that represent figures in a two-dimensional space"
	author: "Ruihua Jin"
	date: "October 17, 2007"
	revision: "1.0"

class
	FIGURE

create
	default_create,
	make

feature {NONE}
	make(b : expanded RECTANGLE) is  -- Obsolete syntax
			-- Initialization
		require
			b_not_void: b /= Void
		do
			bound := b
		ensure
			bound_not_void: bound /= Void
		end

feature
	bound : expanded RECTANGLE  -- Obsolete syntax

feature
	move(dx : INTEGER; dy : INTEGER) is
			-- Move the figure by dx horizontally and dy vertically.
		do
			bound.move(dx, dy)
		end

feature
	to_string : STRING is
			-- String representation of FIGURE
		do
			Result := "Bound: " + bound.to_string
		end


end
