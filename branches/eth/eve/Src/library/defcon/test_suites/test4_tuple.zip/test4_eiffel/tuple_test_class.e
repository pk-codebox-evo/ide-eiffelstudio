indexing
	description: "Objects that contain several tuple examples"
	author: "Ruihua Jin"
	date: "$October 22, 2007$"
	revision: "$Revision 1.0$"

class
	TUPLE_TEST_CLASS

create
	default_create,
	make

feature
	make is
			-- Initialization.	
		do
			value_tuple := make_value_tuple
			expanded_tuple := make_expanded_tuple
			object_tuple := make_object_tuple
			string_tuple := make_string_tuple
			tuple_tuple := make_tuple_tuple
		end

	make_value_tuple : like value_tuple is
			-- Initialize value_tuple.
		do
			Result := [True, -123, 'a']
		end

	make_expanded_tuple : like expanded_tuple is
			-- Initialize expanded_tuple.
		local
			pnt, pnt2 : POINT
			rec : expanded RECTANGLE
		do
			create pnt.make(23, 68)
			create pnt2.make(54, 65)
			create rec.make(pnt2, 79, 20)
			Result := [pnt, rec]
		end

	make_object_tuple : like object_tuple is
			-- Initialize object_tuple.
		local
			pnt : POINT
			rec : RECTANGLE
			root : TREE_NODE
			random : SYSTEM_RANDOM
		do
			create pnt.make(67, 29)
			create rec.make(pnt, 92, 72)
			create random.make
			root := make_tree(0, random)
			Result := [rec, root]
		end

	make_tree(level : INTEGER; random : SYSTEM_RANDOM) : TREE_NODE is
			-- Make a binary tree.
		require
			level_not_negative : level >= 0
			random_not_void : random /= Void
		local
			node : TREE_NODE
		do
			if (level > TREE_LEVEL) then
				Result := Void
			else
				if (level = 0) then
					create node.make_id (ROOT_ID)
				else
					create node.make_id (random.next(1,100))
				end
				node.set_left(make_tree(level+1, random))
				node.set_right(make_tree(level+1, random))
				Result := node
			end
		end

	make_string_tuple : like string_tuple is
			-- Initialize string_tuple.
		do
			Result := ["a string", ("a system string").to_cil]
		end


	make_tuple_tuple : like tuple_tuple is
			-- Initialize tuple_tuple.
		local
			pnt, pnt2 : POINT
			rec : RECTANGLE
			str : STRING
			root : TREE_NODE
			random : SYSTEM_RANDOM
		do
			create pnt.make(48, 47)
			create pnt2.make(67, 27)
			create rec.make(pnt2, 78, 25)
			create random.make
			root := make_tree(0, random)
			str := "a string in tuple_tuple"
			Result := [[674, pnt, root], str]
		end

	is_equal_to(t : like Current) : BOOLEAN is
			-- Returns True if the current object is field-by-field equal to t,
			-- otherwise, returns False.
		require
			t_not_void : t /= Void
		local
			str1, str2 : STRING
			str3, str4 : SYSTEM_STRING
			tt1, tt2 : TUPLE
			tt1root, tt2root : TREE_NODE
			t1str, t2str : STRING
		do
			Result := value_tuple.is_equal(t.value_tuple)
						and expanded_tuple.is_equal(t.expanded_tuple)
						and deep_equal(object_tuple.item(1), t.object_tuple.item(1)) and deep_equal(object_tuple.item(2), t.object_tuple.item(2))
			-- compare the string tuples
			str1 ?= string_tuple.item(1)
			str2 ?= t.string_tuple.item (1)
			if (str1 /= Void and str2 /= Void) then
				Result := Result and str1.same_string (str2)
			else
				Result := False
			end
			str3 ?= string_tuple.item (2)
			str4 ?= t.string_tuple.item(2)
			if (str3 /= Void and str4 /= Void) then
				Result := Result and str3.equals(str4)
			else
				Result := False
			end

			-- compare the tuple_tuples
			tt1 ?= tuple_tuple.item(1)
			tt2 ?= t.tuple_tuple.item(1)
			if (tt1 /= Void and tt2 /= Void) then
				Result := Result and tt1.item(1).is_equal(tt2.item(1)) and tt1.item(2).is_equal(tt2.item(2))
				tt1root ?= tt1.item(3)
				tt2root ?= tt2.item(3)
				if (tt1root /= Void and tt2root /= Void) then
					Result := Result and deep_equal(tt1root, tt2root)
				else
					Result := False
				end
			else
				Result := False
			end
			t1str ?= tuple_tuple.item(2)
			t2str ?= t.tuple_tuple.item(2)
			if (t1str /= Void and t2str /= Void) then
				Result := Result and t1str.same_string(t2str)
			else
				Result := False
			end
		end



feature
	value_tuple : TUPLE[BOOLEAN, INTEGER, CHARACTER]
	expanded_tuple : TUPLE[POINT, expanded RECTANGLE]
	object_tuple : TUPLE[RECTANGLE, TREE_NODE]
	string_tuple : TUPLE[STRING, SYSTEM_STRING]
	tuple_tuple : TUPLE[TUPLE[INTEGER, POINT, TREE_NODE], STRING]

feature {NONE}
	ROOT_ID : INTEGER is 123
	TREE_LEVEL : INTEGER is 7
end
