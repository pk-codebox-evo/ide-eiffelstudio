indexing
	description: "Project root class"

class
	TEST

create
	make

feature {NONE} -- Initialization

	make is
			-- Run application.
		local
			t : TUPLE_TEST_CLASS
			retrieved_tuple_test : TUPLE_TEST_CLASS
		do
			create t.make
			store_tuple(t)
			retrieved_tuple_test := retrieve_tuple
			io.put_string ("The stored and the retrieved tuples are ")
			if (retrieved_tuple_test.is_equal_to(t)) then
				io.put_string("the same.")
			else
				io.put_string("different.")
			end
			io.put_new_line
			delete_tuple
		end

	store_tuple(t : TUPLE_TEST_CLASS) is
			-- Store t in the database.
		local
			db : IOBJECT_CONTAINER
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test.yap");
			db.set(t)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	retrieve_tuple : TUPLE_TEST_CLASS is
			-- Retrieve the first TUPLE_TEST_CLASS instance from the database.
		local
			t, res : TUPLE_TEST_CLASS
			node : TREE_NODE
			config : ICONFIGURATION
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create t.default_create
			create node.default_create
			config := {DB_4O_FACTORY}.new_configuration
			config.object_class (node).cascade_on_activate (True)
			db := {DB_4O_FACTORY}.open_file(config, "test.yap")
			results := db.get(t)
			if (results.has_next) then
				res ?= results.next
				if (res /= Void) then
					Result := res
				end
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	delete_tuple is
			-- Delete all the objects.
		local
			o : SYSTEM_OBJECT
			config : ICONFIGURATION
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create o
			db := {DB_4O_FACTORY}.open_file("test.yap")
			results := db.get(o)
			from
			until not results.has_next
			loop
				db.delete(results.next)
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end
end
