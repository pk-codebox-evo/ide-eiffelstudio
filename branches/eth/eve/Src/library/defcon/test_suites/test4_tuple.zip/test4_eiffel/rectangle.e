indexing
	description: "Objects that represent rectangles in a two-dimensional space"
	author: "Ruihua Jin"
	date: "October 22, 2007"
	revision: "1.0"

class
	RECTANGLE

create
	default_create,
	make

feature {NONE}
	make(p : POINT; w : INTEGER; h : INTEGER) is
			-- Initialization
		require
			p_not_void: p /= Void
			w_positive: w > 0
			h_positive: h > 0
		do
			upperleft_point := p
			width := w
			height := h
		ensure
			upperleftpnt_not_void: upperleft_point /= Void
			width_positive: width > 0
			height_positive: height > 0
		end

feature
	move(dx : INTEGER; dy : INTEGER) is
			-- Move the rectangle by dx horizontally and dy vertically.
		do
			upperleft_point.set_x(upperleft_point.x + dx)
			upperleft_point.set_y(upperleft_point.y + dy)
		end

feature
	to_string : STRING is
			-- String representation of RECTANGLE
		do
			Result := "Upperleft point: " + upperleft_point.to_string + ", width=" + width.out + ", height=" + height.out
		end

feature
	upperleft_point : POINT
	width, height : INTEGER


end
