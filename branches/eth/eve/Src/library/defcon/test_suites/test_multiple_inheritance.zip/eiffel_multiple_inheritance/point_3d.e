indexing
	description: "Objects that are points in 3-dimentional space"
	author: "Ruihua Jin"
	date: "$October 25, 2007$"
	revision: "$Revision 1.0$"

expanded class
	POINT_3D

inherit
	POINT
		rename
			distance_to as distance_to_point2d
		export
			{NONE} make_with_x_y
		redefine
			distance_to_point2d,
			to_string
		end

create
	default_create,
	make_with_x_y_z

feature {NONE}
	make_with_x_y_z(a : INTEGER; b : INTEGER; c : INTEGER) is
			-- Initialization.
		do
			set_x(a)
			set_y(b)
			set_z(c)
		end

feature
	set_z (c : INTEGER) is
			-- Set the value of z.
		do
			z := c
		end

	z : INTEGER

feature
	distance_to_point2d(p : POINT) : INTEGER is
			-- Returns the distance to point p.
		local
			m : DOUBLE_MATH
		do
			create m
			Result := m.sqrt((x-p.x)*(x-p.x) + (y-p.y)*(y-p.y) + z*z).rounded
		end

	distance_to_point3d(p : POINT_3D) : INTEGER is
			-- Returns the distance to point p.
		require
			p_not_void : p /= Void
		local
			m : DOUBLE_MATH
		do
			create m
			Result := m.sqrt((x-p.x)*(x-p.x) + (y-p.y)*(y-p.y) + (z-p.z)*(z-p.z)).rounded
		end

feature
	to_string : STRING is
			-- String representation of POINT_3D
		do
			Result := "Point (" + x.out + ", " + y.out + ", " + z.out + ")"
		end


end
