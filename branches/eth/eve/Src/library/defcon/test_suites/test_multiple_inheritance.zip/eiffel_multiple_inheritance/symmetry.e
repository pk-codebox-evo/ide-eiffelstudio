indexing
	description: "Objects that have a center"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

deferred class
	SYMMETRY

feature
	center : POINT is
			-- Returns the center of the geometry figure.
		deferred
		end
end
