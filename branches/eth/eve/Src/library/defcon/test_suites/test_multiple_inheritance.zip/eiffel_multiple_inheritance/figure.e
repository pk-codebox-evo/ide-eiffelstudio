indexing
	description: "Objects that are figures"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

deferred class
	FIGURE

feature
	draw is
			-- Output the figure.
		deferred
		end

feature
	stroke : ARRAY[POINT]

invariant
	--stroke_not_void : stroke /= Void
	--stroke_count_positive : stroke.count > 0

end
