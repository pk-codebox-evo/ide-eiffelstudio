indexing
	description: "Objects that represent points in a two-dimensional space"
	author: "Ruihua Jin"
	date: "October 22, 2007"
	revision: "1.0"

expanded class
	POINT

create
	default_create,
	make_with_x_y

feature {NONE}
	make_with_x_y(a : INTEGER; b : INTEGER) is
			-- Initialization
		do
			set_x(a)
			set_y(b)
		end

feature
	x, y : INTEGER

feature
	set_x(a : INTEGER) is
			-- Set the value of x.
		do
			x := a
		end

	set_y(b : INTEGER) is
			-- Set the value of y.
		do
			y := b
		end

feature
	distance_to(p : POINT) : INTEGER is
			-- Returns the distance to the point p.
		require
			p_not_void : p /= Void
		local
			m : DOUBLE_MATH
		do
			create m
			Result := m.sqrt((x-p.x)*(x-p.x) + (y-p.y)*(y-p.y)).rounded
		end


feature
	to_string : STRING is
			-- String representation of POINT
		do
			Result := "Point (" + x.out + ", " + y.out + ")"
		end

	output is
			-- Output the string representation of the current POINT instance to the console.
		do
			io.put_string(to_string)
		end


end
