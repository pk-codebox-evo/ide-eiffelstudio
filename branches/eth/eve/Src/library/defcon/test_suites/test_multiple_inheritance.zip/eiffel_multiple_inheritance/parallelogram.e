indexing
	description: "Objects that are parallelograms"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

class
	PARALLELOGRAM

inherit
	POLYGON
		rename
			make_with_vertices as make_with_4_vertices
		redefine
			make_with_4_vertices
		end

	SYMMETRY
		redefine
			center  -- turn an argumentless function to an attribute
		end

create
	default_create,
	make_with_4_vertices

feature {NONE}
	make_with_4_vertices(v : ARRAY[POINT]) is
			-- Initialization.
		require else
			v_not_void : v /= Void
			v_count_equals_4 : v.count = 4
		local
			i : INTEGER
			x1, y1, x3, y3 : INTEGER
		do
			Precursor(v)
			i := vertices.lower
			x1 := vertices.item(i).x
			y1 := vertices.item(i).y
			x3 := vertices.item(i+2).x
			y3 := vertices.item(i+2).y
			create center.make_with_x_y((x1+x3)//2, (y1+y3)//2)
			height1 := 50  -- TODO
			height2 := 20
		end

feature
	center : POINT
	height1 : INTEGER
	height2 : INTEGER

invariant
	--height1_positive : height1 > 0
	--height2_positive : height2 > 0
	--vertices_count_equals_4 : vertices.count = 4
	--center_not_void : center /= Void

end
