indexing
	description: "Objects that are rhombi"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

class
	RHOMBUS

inherit
	PARALLELOGRAM
		redefine
			make_with_4_vertices
		end

create
	default_create,
	make_with_4_vertices

feature
	make_with_4_vertices(v : ARRAY[POINT]) is
			-- Initialization.
		do
			Precursor(v)
			side_length := vertices.item(vertices.lower).distance_to(vertices.item(vertices.lower+1))
		end

feature
	side_length : INTEGER

end
