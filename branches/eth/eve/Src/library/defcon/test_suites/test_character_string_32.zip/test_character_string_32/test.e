indexing
	description: "Project root class"

class
	TEST

create
	make

feature {NONE} -- Initialization

	make is
			-- Run application.
		local
			retrieved_character_32 : TEST_CHARACTER_32
			retrieved_string_32 : TEST_STRING_32
		do
			store_character_32
			retrieved_character_32 := retrieve_character_32
			store_string_32
			retrieved_string_32 := retrieve_string_32
		end

feature {NONE}
	store_character_32 is
			-- Store one instance of TEST_CHARACTER_32 in the file "test_character_32.yap".
		local
			a_char32 : TEST_CHARACTER_32
			db : IOBJECT_CONTAINER
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test_character_32.yap")
			create a_char32.make
			db.set(a_char32)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	retrieve_character_32 : TEST_CHARACTER_32 is
			-- Return one instance of TEST_CHARACTER_32 stored in the file "test_character_32.yap".
		local
			default_testchar : TEST_CHARACTER_32
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create default_testchar.default_create
			db := {DB_4O_FACTORY}.open_file("test_character_32.yap")
			results := db.get(default_testchar)
			if (results.has_next) then
				Result ?= results.next
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	store_string_32 is
			-- Store one instance of TEST_STRING_32 in the file "test_string_32.yap".
		local
			a_str32 : TEST_STRING_32
			db : IOBJECT_CONTAINER
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test_string_32.yap")
			create a_str32.make
			db.set(a_str32)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	retrieve_string_32 : TEST_STRING_32 is
			-- Return one instance of TEST_STRING_32 stored in the file "test_string_32.yap".
		local
			default_teststr : TEST_STRING_32
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			create default_teststr.default_create
			db := {DB_4O_FACTORY}.open_file("test_string_32.yap")
			results := db.get(default_teststr)
			if (results.has_next) then
				Result ?= results.next
			end
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

end
