indexing
	description: "Objects that contain one attribute of type STRING_32"
	author: "Ruihua Jin"
	date: "$November 2, 2007$"
	revision: "$Revision 1.0$"

class
	TEST_STRING_32

create
	default_create,
	make

feature
	make is
			-- Initialization
		do
			a_string_32 := "a string_32"
		end

feature
	a_string_32 : STRING_32

end
