indexing
	description: "Objects that contain an attribute of type CHARACTER_32"
	author: "Ruihua Jin"
	date: "$November 2, 2007$"
	revision: "$Revision 1.0$"

class
	TEST_CHARACTER_32

create
	default_create,
	make

feature
	make is
			-- Initialization
		do
			a_character := 'a'
		end

feature
	a_character : CHARACTER_32

end
