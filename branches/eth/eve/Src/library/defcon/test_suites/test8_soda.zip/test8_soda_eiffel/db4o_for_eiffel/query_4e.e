indexing
	description: "db4o query wrapper to handle string and field name translation"
	author: "Carl Rosenberger"
	date: "$Date: 2005/08/15 15:51:07 $"
	revision: "$Revision: 1.3 $"

class
	QUERY_4E

create
	make, make_extent, make_from_query

feature -- Initialization

	query : IQUERY
	executed : BOOLEAN

	make (oc : IOBJECT_CONTAINER) is
		do
			make_from_query(oc.query)
		end

	make_extent(oc : IOBJECT_CONTAINER ; extent : SYSTEM_TYPE) is
		local
			c : ICONSTRAINT
		do
			make(oc)
			c := constrain (extent)
		end

	make_from_query (q : IQUERY) is
		do
			executed := false
			query := q
		end

feature	-- Use

	order_descending: QUERY_4E is
		require
			executed = false
		do
			query := query.order_ascending
			Result := Current
		end

	order_ascending: QUERY_4E is
		require
			executed = false
		do
			query := query.order_ascending
			Result := Current
		end

	execute: IOBJECT_SET is
		require
			executed = false
		do
			executed := true
			Result := query.execute
		end

	descend (field_name: STRING): QUERY_4E is
		require
			executed = false
		local
			sub_node : IQUERY
			sub_node_wrapper : QUERY_4E
		do
			field_name.prepend ("$$")
			sub_node := query.descend(field_name)
			create sub_node_wrapper.make_from_query(sub_node)
			Result := sub_node_wrapper
		end


	constraints: ICONSTRAINTS is
		require
			executed = false
		do
			Result := query.constraints
		end


	constrain (constraint: SYSTEM_OBJECT) : ICONSTRAINT is
		require
			executed = false
		do
			Result := query.constrain (constraint)
		end

end
