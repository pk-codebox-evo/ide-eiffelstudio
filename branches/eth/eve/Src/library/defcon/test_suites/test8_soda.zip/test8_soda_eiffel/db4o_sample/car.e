indexing
	description: "A simple class to store in db4o"
	author: "Carl Rosenberger"
	date: "$Date: 2005/08/14 14:57:34 $"
	revision: "$Revision: 1.1 $"

class
	CAR

create
	make_generic

feature -- Persistent

	systemname: SYSTEM_STRING
	eiffelname: STRING

feature {NONE} -- Initialisation

	make_generic is
		do
		end

	make (a_model_name: STRING) is
    	do
			systemname := a_model_name
			eiffelname := a_model_name
    	end

feature -- Printing

	print_out is
    	do
			io.put_string (generating_type)
			io.put_character (':')
			io.put_new_line
			io.put_string ("systemname is ")
			io.put_string (systemname)
			io.put_new_line
			io.put_string ("eiffelname is ")
			io.put_string (eiffelname)
			io.put_new_line
    	end

end
