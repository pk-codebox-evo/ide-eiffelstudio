indexing
	description: "BMW"
	date: "$Date$"
	revision: "$Revision$"

class
	BMW

inherit
	CAR

create	
	make, make_generic

end
