indexing
	description: "Translator to store any STRING as a SYSTEM_STRING in db4o"
	author: "Carl Rosenberger"
	date: "$Date: 2005/08/15 12:00:33 $"
	revision: "$Revision: 1.2 $"

class
	STRING_TRANSLATOR_4E

inherit
	IOBJECT_CONSTRUCTOR

create
	make

feature

	system_string_class: CLASS_

    make (clazz: CLASS_) is
    	do
    		system_string_class := clazz
    	end

	stored_class: SYSTEM_TYPE is
		do
			RESULT := system_string_class.get_type
		end

	on_instantiate (container: IOBJECT_CONTAINER; stored_object: SYSTEM_OBJECT): SYSTEM_OBJECT is
		local
			sys_str : SYSTEM_STRING
			str : STRING
		do
			sys_str ?= stored_object
			str := sys_str
			RESULT := str
		end

	on_store (container: IOBJECT_CONTAINER; application_object: SYSTEM_OBJECT): SYSTEM_OBJECT is
		local
			sys_str : SYSTEM_STRING
			str : STRING
		do
			str ?= application_object
			sys_str := str
			RESULT := sys_str
		end

	on_activate (container: IOBJECT_CONTAINER; application_object: SYSTEM_OBJECT; stored_object: SYSTEM_OBJECT) is
		do
		end
end
