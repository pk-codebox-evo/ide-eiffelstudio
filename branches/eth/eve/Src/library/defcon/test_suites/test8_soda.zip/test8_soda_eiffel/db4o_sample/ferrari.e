indexing
	description: "FERRARI"
	date: "$Date$"
	revision: "$Revision$"

class
	FERRARI

inherit
	CAR

create
	make, make_generic

end
