indexing
	description: "My very first test of db4o with Eiffel"
	author: "Carl Rosenberger"
	date: "$Date: 2005/08/15 15:51:07 $"
	revision: "$Revision: 1.2 $"

class
	APPLICATION

create
	make

feature -- Initialization

	database_file : STRING

	init is
		do
			database_file := "eiffel.yap"
			install_db4o_eiffel_configuration
	  	end

feature -- db4o database control

	db : IOBJECT_CONTAINER

  	install_db4o_eiffel_configuration is
	  	local
			eiffel_configuration : CONFIGURATION_4E
		do
			create eiffel_configuration.make
	  	end

	open_database is
		do
			db := {DB_4O_FACTORY}.open_file(database_file)
		end

	close_database is
		local
			close_result: BOOLEAN
		do
			close_result := db.close
		end

feature -- Run

	make is
		do
			init

			open_database
			store_two_cars
			close_database

			open_database
			print_all_stored_cars
			query_by_example
			soda_query_for_car_name
			close_database

		end

feature -- Tests

	store_two_cars is
		local
			my_car: CAR
		do
			create {FERRARI} my_car.make ("F430")
			db.set(my_car)

			create {FERRARI} my_car.make ("F450")
			db.set(my_car)

			create {BMW} my_car.make ("Serie 5")
			db.set(my_car)

			create {BMW} my_car.make ("Serie 7")
			db.set(my_car)
		end

	print_all_stored_cars is
		local
			my_car: CAR
			query: QUERY_4E
		do
			io.put_string ("***** All stored cars of exactly the type CAR *****")
			io.put_new_line
			create my_car.make_generic
			print_car_objectset (db.get (my_car))

			io.put_string ("***** All stored cars *****")
			io.put_new_line
			create query.make_extent (db, {CAR})
			print_car_objectset (query.execute)
		end

	query_by_example is
		local
			ferrari: CAR
		do
			io.put_string ("***** All Ferrari cars by example *****")
			io.put_new_line
			create {FERRARI} ferrari.make_generic
			print_car_objectset(db.get (ferrari))
		end

	soda_query_for_car_name is
		local
			query : QUERY_4E
			c : ICONSTRAINT
		do
				-- Manu's comment: Code below matches all cars although
				-- it should only find the F450 model ones.
			io.put_string ("***** All Ferrari F450 cars S.O.D.A. syntax (try 1) *****")
			io.put_new_line
			create query.make_extent(db, {CAR})
			c := query.descend("eiffelname").constrain("F450")
			print_car_objectset(query.execute)

				-- Manu's comment: Code below prints all FERRARI instances
				-- with a "F450" model.
			io.put_string ("***** All Ferrari F450 cars S.O.D.A. syntax (try 2) *****")
			io.put_new_line
			create query.make_extent(db, {FERRARI})
			c := query.descend("eiffelname").constrain("F450")
			print_car_objectset(query.execute)

				-- Manu's comment: Code below prints nothing
			io.put_string ("***** All Ferrari F450 cars S.O.D.A. syntax (try 3) *****")
			io.put_new_line
			create query.make_extent(db, {BMW})
			c := query.descend("eiffelname").constrain("F450")
			print_car_objectset(query.execute)
		end

	print_car_objectset (objectset : IOBJECT_SET) is
		local
			my_car: CAR
		do
			from
			until
				not objectset.has_next
			loop
				my_car ?= objectset.next
				if my_car /= Void then
					my_car.print_out
				end
			end

		end


end
