indexing
	description: "Objects that are squares"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

expanded class
	SQUARE

inherit
	RECTANGLE
		export
			{NONE} width, height
		undefine
			make_with_4_vertices
		end

	RHOMBUS
		export
			{NONE} height1, height2
		select
			height1, height2
		end

create
	default_create,
	make_with_4_vertices

end
