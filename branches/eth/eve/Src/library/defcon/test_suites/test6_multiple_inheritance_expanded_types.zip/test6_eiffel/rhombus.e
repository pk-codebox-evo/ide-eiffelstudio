indexing
	description: "Objects that are rhombi"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

expanded class
	RHOMBUS

inherit
	PARALLELOGRAM
		redefine
			make_with_4_vertices
		end

create
	default_create,
	make_with_4_vertices

feature
	make_with_4_vertices(v : ARRAY[POINT]) is
			-- Initialization.
		require else
			v_not_void : v /= Void
			v_count_equals_4 : v.count = 4
		do
			make_parallelogram(v)  -- Precursor(v)
			side_length := vertices.item(vertices.lower).distance_to(vertices.item(vertices.lower+1))
		end

	make_parallelogram(v : ARRAY[POINT]) is
			--
		require
			v_not_void : v /= Void
			v_count_equals_4 : v.count = 4
		local
			i : INTEGER
			x1, y1, x3, y3 : INTEGER
		do
			vertices := v
			i := vertices.lower
			x1 := vertices.item(i).x
			y1 := vertices.item(i).y
			x3 := vertices.item(i+2).x
			y3 := vertices.item(i+2).y
			create center.make_with_x_y((x1+x3)//2, (y1+y3)//2)
			height1 := 50
			height2 := 20
		end


feature
	side_length : INTEGER

end
