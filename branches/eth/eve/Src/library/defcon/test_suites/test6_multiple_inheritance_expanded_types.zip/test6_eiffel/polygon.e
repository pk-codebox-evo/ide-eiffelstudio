indexing
	description: "Objects that are polygons"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

expanded class
	POLYGON

inherit
	FIGURE
		rename
			stroke as vertices
		end

create
	default_create,
	make_with_vertices

feature
	make_with_vertices(v : ARRAY[POINT]) is
			-- Initialization.
		require
			v_not_void : v /= Void
			v_count_greater_than_two : v.count > 2
		do
			vertices := v
		end

	draw is
			-- Output the figure.
		local
			i : INTEGER
		do
			io.put_string ("Polygon: [vertices: ")
			from i := vertices.lower
			until i > vertices.upper
			loop
				io.put_string("[" + vertices.item(i).x.out + "," + vertices.item(i).y.out + "],")
				i := i+1
			end
			io.put_string ("]")
			io.put_new_line
		end

invariant
	--vertices_not_void : vertices /= Void
	--vertices_count_greater_than_two : vertices.count > 2

end
