indexing
	description: "Project root class"

class
	TEST

create
	make

feature {NONE} -- Initialization

	make is
			-- Run application.
		local
			sq, default_sq : SQUARE
			rec, default_rec : RECTANGLE
			rh, default_rh : RHOMBUS
			par, default_par : PARALLELOGRAM
			pol, default_pol : POLYGON
			results : SYSTEM_ARRAY
		do
			create sq.make_with_4_vertices (make_vertices(4))
			store(sq)
			create default_sq.default_create
			results := retrieve(default_sq)   -- all direct instances of SQUARE returned

			create rec.make_with_4_vertices(make_vertices(4))
			store(rec)
			create default_rec.default_create
			results := retrieve(default_rec)  -- all direct instances of RECTANGLE returned

			create rh.make_with_4_vertices (make_vertices(4))
			store(rh)
			create default_rh.default_create
			results := retrieve(default_rh)   -- all direct instances of RHOMBUS returned

			create par.make_with_4_vertices (make_vertices(4))
			store(par)
			create default_par.default_create
			results := retrieve(default_par)   -- all direct instances of PARALLELOGRAM returned

			create pol.make_with_vertices (make_vertices(7))
			store(pol)
			create default_pol.default_create
			results := retrieve(default_pol)   -- all direct instances of POLYGON returned
		end

feature
	store(obj : ANY) is
			-- Store obj in the database.
		require
			obj_not_void : obj /= Void
		local
			db : IOBJECT_CONTAINER
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test.yap");
			db.set(obj)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

	retrieve(default_obj : ANY) : SYSTEM_ARRAY is
			-- Retrieve the objects from the database.
		require
			default_obj_not_void : default_obj /= Void
		local
			obj : SYSTEM_OBJECT
			config : ICONFIGURATION
			db : IOBJECT_CONTAINER
			results : IOBJECT_SET
			closed : BOOLEAN
		do
			db := {DB_4O_FACTORY}.open_file("test.yap")
			results := db.get(default_obj)
			obj := default_obj
			Result := {SYSTEM_ARRAY}.create_instance(obj.get_type, results.count)
			results.copy_to (Result, 0)
			closed := db.close
		rescue
			if (db /= Void) then
				closed := db.close
			end
		end

feature {NONE}
	make_vertices(count : INTEGER) : ARRAY[POINT] is
			-- Returns an ARRAY of POINT instances with the length of count.
		require
			count_positive : count > 0
		local
			i : INTEGER
			random : SYSTEM_RANDOM
			p : POINT
		do
			create random.make
			create Result.make (0, count-1)
			from i := 0
			until i > count-1
			loop
				create p.make_with_x_y (random.next(1,100), random.next(1,100))
				Result.put(p, i)
				i := i+1
			end
		end
end
