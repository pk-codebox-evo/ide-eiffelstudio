indexing
	description: "Objects that are rectangles"
	author: "Ruihua Jin"
	date: "$October 24, 2007$"
	revision: "$Revision 1.0$"

expanded class
	RECTANGLE

inherit
	PARALLELOGRAM
		rename
			height1 as width,
			height2 as height
		end

create
	default_create,
	make_with_4_vertices

end
