indexing

	description:

		"Values that are accessible through keys"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:09:44 $"
	revision: "$Revision: 1.2 $"

deferred class KL_VALUES [G, K]

inherit

	ANY -- Needed for SE 2.1b1.

feature -- Access

	value (k: K): G is
			-- Item associated with `k';
			-- Return default value if no such item
		require
			k_not_void: k /= Void 
		deferred
		end

end
