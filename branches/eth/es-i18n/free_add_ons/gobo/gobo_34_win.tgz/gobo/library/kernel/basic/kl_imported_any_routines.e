indexing

	description:

		"Imported routines that ought to be in class ANY"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2005, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/02/05 14:57:13 $"
	revision: "$Revision: 1.1 $"

class KL_IMPORTED_ANY_ROUTINES

feature -- Access

	ANY_: KL_ANY_ROUTINES is
			-- Routines that ought to be in class ANY
		once
			create Result
		ensure
			any_routines_not_void: Result /= Void
		end

end
