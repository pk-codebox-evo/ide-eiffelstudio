indexing

	description:

		"EiffelTime DATE_VALUE class interface"

	library: "Gobo Eiffel Time Library"
	copyright: "Copyright (c) 2000, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:53:54 $"
	revision: "$Revision: 1.4 $"

deferred class DATE_VALUE

inherit

	DT_DATE_VALUE

	DATE_CONSTANTS
		undefine
			out
		end

end
