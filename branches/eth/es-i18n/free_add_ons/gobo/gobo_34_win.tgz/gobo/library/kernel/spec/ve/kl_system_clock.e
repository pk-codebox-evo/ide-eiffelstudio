indexing

	description:

		"System clocks (precision to the millisecond)"

	remark:

		"With SmartEiffel under Windows the millisecond part may be stuck to zero."

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/02/27 16:55:52 $"
	revision: "$Revision: 1.14 $"

class KL_SYSTEM_CLOCK

inherit

	KI_SYSTEM_CLOCK











	TIMESTAMP
		rename
			set_local_time as old_set_local_time
		export
			{NONE} all
		undefine
			out, is_equal
		end


creation

	make

feature {NONE} -- Initialization

	make is
			-- Create a new system clock.
		do

			set (1970, 1, 1, 0, 0, 0.0)

		end




























feature -- Setting

	set_local_time is
			-- Set clock to current local time.




		do
















			old_set_local_time











		end

	set_utc_time is
			-- Set clock to current UTC time.




		do
















			set_to_now











		end








end
