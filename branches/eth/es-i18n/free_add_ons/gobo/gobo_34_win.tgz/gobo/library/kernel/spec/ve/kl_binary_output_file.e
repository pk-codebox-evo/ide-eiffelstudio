indexing

	description:

		"Binary output files containing extended ASCII %
		%characters (8-bit code between 0 and 255)"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/02/18 22:20:31 $"
	revision: "$Revision: 1.21 $"

class KL_BINARY_OUTPUT_FILE

inherit

	KI_BINARY_OUTPUT_FILE

		undefine
			copy
		end


	KL_OUTPUT_FILE























































creation

	make














































end
