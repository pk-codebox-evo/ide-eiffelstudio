indexing

	description:

		"System clocks (precision to the millisecond)"

	remark:

		"With SmartEiffel under Windows the millisecond part may be stuck to zero."

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001-2004, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/02/27 16:55:52 $"
	revision: "$Revision: 1.14 $"

class KL_SYSTEM_CLOCK

inherit

	KI_SYSTEM_CLOCK


	C_DATE
		rename
			millisecond_now as millisecond
		undefine
			default_create
		end













creation

	make

feature {NONE} -- Initialization

	make is
			-- Create a new system clock.
		do



		end


feature -- Access

	year: INTEGER
			-- Year

	month: INTEGER
			-- Month

	day: INTEGER
			-- Day

	hour: INTEGER
			-- Hour

	minute: INTEGER
			-- Minute

	second: INTEGER
			-- Second







feature -- Setting

	set_local_time is
			-- Set clock to current local time.




		do



















			is_utc := False
			update
			year := year_now
			month := month_now
			day := day_now
			hour := hour_now
			minute := minute_now
			second := second_now

		end

	set_utc_time is
			-- Set clock to current UTC time.




		do



















			is_utc := True
			update
			year := year_now
			month := month_now
			day := day_now
			hour := hour_now
			minute := minute_now
			second := second_now

		end








end
