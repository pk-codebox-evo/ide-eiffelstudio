indexing

	description:

		"Lexical analyzer description overriders"

	library: "Gobo Eiffel Lexical Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:09:46 $"
	revision: "$Revision: 1.5 $"

deferred class LX_DESCRIPTION_OVERRIDER

inherit

	ANY -- Needed for SE 2.1b1.

feature -- Basic operations

	override_description (a_description: LX_DESCRIPTION) is
			-- Override values specified in `a_description'.
		require
			a_description_not_void: a_description /= Void
		deferred
		end

end
