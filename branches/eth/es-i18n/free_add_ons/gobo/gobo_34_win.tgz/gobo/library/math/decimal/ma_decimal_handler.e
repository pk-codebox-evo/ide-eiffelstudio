indexing

	description:

		"Objects that have access to the internals of MA_DECIMAL"

	library: "Gobo Eiffel Decimal Arithmetic Library"
	copyright: "Copyright (c) 2005, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/06/30 08:44:59 $"
	revision: "$Revision: 1.1 $"

class MA_DECIMAL_HANDLER

end
