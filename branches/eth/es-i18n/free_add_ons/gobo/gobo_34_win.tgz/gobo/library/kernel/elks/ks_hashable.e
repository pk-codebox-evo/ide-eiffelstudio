indexing

	description:

		"Portable interface for class HASHABLE"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2001, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:08:37 $"
	revision: "$Revision: 1.5 $"

deferred class KS_HASHABLE

inherit

	ANY -- Needed for SE 2.1b1

feature -- Access

	hash_code: INTEGER is
			-- Hash code value
			-- (ELKS 95 HASHABLE)
		deferred
		ensure
			good_hash_value: Result >= 0
		end

end
