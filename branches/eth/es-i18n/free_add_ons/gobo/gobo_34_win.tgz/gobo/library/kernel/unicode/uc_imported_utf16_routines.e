indexing

	description:

		"Imported UTF-16 encoding routines"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2002, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:51:05 $"
	revision: "$Revision: 1.3 $"

class UC_IMPORTED_UTF16_ROUTINES

feature -- Access

	utf16: UC_UTF16_ROUTINES is
			-- UTF-16 encoding routines
		once
			create Result
		ensure
			utf16_not_void: Result /= Void
		end

end
