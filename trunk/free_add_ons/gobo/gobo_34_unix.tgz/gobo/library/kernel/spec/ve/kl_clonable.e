indexing

	description:

		"Clonable objects"

	library: "Gobo Eiffel Kernel Library"
	copyright: "Copyright (c) 2005, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2005/06/04 19:10:27 $"
	revision: "$Revision: 1.1 $"

class KL_CLONABLE

inherit

	ANY

	KL_IMPORTED_ANY_ROUTINES
		export {NONE} all end

feature -- Duplication

	cloned_object: like Current is
			-- Clone of current object
		do

			Result := clone (Current)



		ensure
			cloned_not_void: Result /= Void
			same_type: ANY_.same_types (Result, Current)
			is_equal: Result.is_equal (Current)
		end

end
