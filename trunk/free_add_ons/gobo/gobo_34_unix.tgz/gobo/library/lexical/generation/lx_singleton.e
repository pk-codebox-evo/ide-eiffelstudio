indexing

	description:

		"Info about DFA states with only one out-transition"

	library: "Gobo Eiffel Lexical Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2004/11/14 15:09:46 $"
	revision: "$Revision: 1.7 $"

class LX_SINGLETON

inherit

	ANY -- Needed for SE 2.1b1.

creation

	make

feature {NONE} -- Initialization

	make (id, def, symb, targ: INTEGER) is
			-- Create a new single out-transition state info.
		do
			state_id := id
			default_id := def
			symbol := symb
			target_id := targ
		ensure
			state_id_set: state_id = id
			default_id_set: default_id = def
			symbol_set: symbol = symb
			target_id_set: target_id = targ
		end

feature -- Access

	state_id: INTEGER
			-- State id

	symbol: INTEGER
			-- Out-transition label

	target_id: INTEGER
			-- Id of out-transtion destination state

	default_id: INTEGER
			-- Default base entry

end
