indexing

	description:

		"EiffelBase UNBUNDED class interface"

	library: "Gobo Eiffel Structure Library"
	copyright: "Copyright (c) 1999, Eric Bezault and others"
	license: "Eiffel Forum License v2 (see forum.txt)"
	date: "$Date: 2003/02/07 12:53:39 $"
	revision: "$Revision: 1.4 $"

deferred class UNBOUNDED [G]

inherit

	CONTAINER [G]

feature -- Status report

	empty: BOOLEAN is
			-- Is structure empty?
		do
			Result := (count = 0)
		end

	full: BOOLEAN is
			-- Is structure filled to capacity?
		deferred
		end

invariant

	empty_definition: empty = (count = 0)
	non_negative_count: count >= 0

end
